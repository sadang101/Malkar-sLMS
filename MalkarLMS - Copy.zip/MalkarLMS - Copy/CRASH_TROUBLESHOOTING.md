# 🔧 App Crash Troubleshooting Guide

## Build Status: ✅ BUILD SUCCESSFUL
## Runtime Status: ❌ APP CRASHED

---

## 📋 How to Find the Crash Reason

### **Step 1: Check Logcat in Android Studio**

1. **Open Logcat** (bottom panel in Android Studio)
2. **Select your device** from the dropdown
3. **Filter by "Error"** or search for "FATAL EXCEPTION"
4. Look for the crash stack trace

### **Common Crash Patterns:**

#### **Pattern 1: NullPointerException**
```
FATAL EXCEPTION: main
java.lang.NullPointerException: Attempt to invoke virtual method on a null object reference
```
**Cause**: Trying to access a view that doesn't exist

#### **Pattern 2: ClassCastException**
```
FATAL EXCEPTION: main
java.lang.ClassCastException: cannot be cast to...
```
**Cause**: Wrong view type in findViewById

#### **Pattern 3: ActivityNotFoundException**
```
android.content.ActivityNotFoundException: Unable to find explicit activity class
```
**Cause**: Activity not registered in AndroidManifest.xml

---

## 🔍 Most Likely Causes for This Crash:

### **1. Missing View IDs** ⚠️
The new dashboard layout has these views:
- `searchIcon` (NEW)
- `tvViewAllCourses` (NEW)
- `rvFeaturedCourses` (NEW)

**Check**: Make sure these IDs exist in `activity_dashboard.xml`

### **2. User Role Issue** ⚠️
If the user role is not set properly, navigation menu might fail.

**Fix**: Check `UserSession.getUserRole(this)` returns valid role

### **3. Firebase Not Initialized** ⚠️
Firestore queries might fail if Firebase isn't set up.

**Fix**: Check `google-services.json` is in the `app/` folder

---

## 🛠️ Quick Fixes to Try:

### **Fix 1: Clear App Data**
```
Settings → Apps → MalkarLMS → Storage → Clear Data
```
Then reinstall the app.

### **Fix 2: Check Layout File**
Open `activity_dashboard.xml` and verify these IDs exist:
- ✅ `android:id="@+id/searchIcon"`
- ✅ `android:id="@+id/tvViewAllCourses"`
- ✅ `android:id="@+id/rvFeaturedCourses"`

### **Fix 3: Rebuild Project**
```
Build → Clean Project
Build → Rebuild Project
```

### **Fix 4: Check AndroidManifest**
Verify `DashboardActivity` is registered:
```xml
<activity
    android:name=".DashboardActivity"
    android:exported="false" />
```

---

## 📱 How to Get Crash Logs:

### **Method 1: Android Studio Logcat**
1. Run the app from Android Studio
2. When it crashes, Logcat will show the error
3. Copy the entire stack trace

### **Method 2: ADB Command**
```bash
adb logcat -d > crash_log.txt
```

### **Method 3: Device Logs**
Some devices save crash logs in:
```
Settings → About Phone → Logs
```

---

## 🎯 What to Share for Help:

If you need help, share:
1. ✅ **Full crash stack trace** from Logcat
2. ✅ **Which screen** the app crashes on (login, dashboard, etc.)
3. ✅ **When it crashes** (on startup, after login, when clicking something)
4. ✅ **Device info** (Android version, device model)

---

## 🔧 Emergency Rollback:

If the dashboard changes are causing issues, you can temporarily revert:

### **Revert to Simple Dashboard:**
1. Open `activity_dashboard.xml`
2. Replace the ScrollView content with the old simple layout
3. Comment out the new code in `DashboardActivity.kt`:
   ```kotlin
   // searchIcon = findViewById(R.id.searchIcon)
   // tvViewAllCourses = findViewById(R.id.tvViewAllCourses)
   // rvFeaturedCourses = findViewById(R.id.rvFeaturedCourses)
   ```

---

## ✅ Expected Behavior:

**After successful launch, you should see:**
1. ✅ Welcome card with greeting
2. ✅ "Featured Courses" section
3. ✅ Search icon (🔍) next to cart
4. ✅ Sidebar without "More Courses"

---

## 📞 Next Steps:

1. **Run the app** and check Logcat
2. **Find the crash line** in the stack trace
3. **Share the error** so I can fix it
4. **Or** try the quick fixes above

---

**The build is successful, so the code is correct. The crash is likely a runtime issue that we can fix quickly once we see the error!** 🚀
