# 10 BUSINESS COURSES - SAMPLE DATA FOR PRESENTATION

## Course 11: Digital Marketing Mastery
- **ID**: 11
- **Title**: Complete Digital Marketing Course
- **Category**: Business / Marketing
- **Price**: ₹3,499 (Original: ₹12,999)
- **Duration**: 10 weeks
- **Instructor**: Meera Kapoor (HubSpot)
- **Rating**: 4.8 ⭐
- **Students**: 19,500
- **Modules**: 10 (SEO, Social Media, Google Ads, Email Marketing, Analytics, etc.)
- **Description**: Master digital marketing and grow your business online

---

## Course 12: MBA Essentials
- **ID**: 12
- **Title**: MBA in a Box - Business Fundamentals
- **Category**: Business / Management
- **Price**: ₹5,999 (Original: ₹19,999)
- **Duration**: 16 weeks
- **Instructor**: Prof. Suresh Menon (IIM Ahmedabad)
- **Rating**: 4.9 ⭐
- **Students**: 12,300
- **Modules**: 10 (Strategy, Finance, Marketing, Operations, Leadership, etc.)
- **Description**: Learn MBA concepts without the MBA price tag

---

## Course 13: Financial Analysis & Accounting
- **ID**: 13
- **Title**: Financial Modeling & Analysis
- **Category**: Business / Finance
- **Price**: ₹4,499 (Original: ₹14,999)
- **Duration**: 12 weeks
- **Instructor**: CA Ramesh Iyer (KPMG)
- **Rating**: 4.7 ⭐
- **Students**: 8,900
- **Modules**: 10 (Accounting, Financial Statements, Excel, Valuation, etc.)
- **Description**: Master financial analysis and modeling

---

## Course 14: Entrepreneurship & Startup
- **ID**: 14
- **Title**: Start Your Own Business
- **Category**: Business / Entrepreneurship
- **Price**: ₹3,999 (Original: ₹13,999)
- **Duration**: 8 weeks
- **Instructor**: Rohan Malhotra (Y Combinator)
- **Rating**: 4.8 ⭐
- **Students**: 15,600
- **Modules**: 8 (Business Ideas, Planning, Funding, Marketing, Scaling, etc.)
- **Description**: Launch and grow your startup successfully

---

## Course 15: Project Management Professional
- **ID**: 15
- **Title**: PMP Certification Prep Course
- **Category**: Business / Project Management
- **Price**: ₹6,499 (Original: ₹21,999)
- **Duration**: 12 weeks
- **Instructor**: Anjali Rao (PMI Certified)
- **Rating**: 4.9 ⭐
- **Students**: 7,200
- **Modules**: 10 (Project Initiation, Planning, Execution, Agile, Risk, etc.)
- **Description**: Get PMP certified and advance your career

---

## Course 16: Human Resource Management
- **ID**: 16
- **Title**: Strategic HR Management
- **Category**: Business / HR
- **Price**: ₹3,499 (Original: ₹11,999)
- **Duration**: 10 weeks
- **Instructor**: Priyanka Joshi (Deloitte HR)
- **Rating**: 4.6 ⭐
- **Students**: 9,800
- **Modules**: 10 (Recruitment, Training, Performance, Compensation, etc.)
- **Description**: Master HR strategies and people management

---

## Course 17: Sales & Negotiation Skills
- **ID**: 17
- **Title**: Master Sales & Negotiation
- **Category**: Business / Sales
- **Price**: ₹2,999 (Original: ₹9,999)
- **Duration**: 6 weeks
- **Instructor**: Karan Sethi (Salesforce)
- **Rating**: 4.7 ⭐
- **Students**: 13,400
- **Modules**: 8 (Sales Process, Lead Generation, Closing, Negotiation, etc.)
- **Description**: Become a top sales professional

---

## Course 18: Business Analytics & Data
- **ID**: 18
- **Title**: Business Analytics with Excel & Power BI
- **Category**: Business / Analytics
- **Price**: ₹3,999 (Original: ₹12,999)
- **Duration**: 10 weeks
- **Instructor**: Deepak Sharma (McKinsey)
- **Rating**: 4.8 ⭐
- **Students**: 11,700
- **Modules**: 10 (Excel Advanced, Power BI, SQL, Data Visualization, etc.)
- **Description**: Make data-driven business decisions

---

## Course 19: Supply Chain Management
- **ID**: 19
- **Title**: Supply Chain & Logistics Management
- **Category**: Business / Operations
- **Price**: ₹4,499 (Original: ₹14,999)
- **Duration**: 12 weeks
- **Instructor**: Aditya Kulkarni (Amazon Operations)
- **Rating**: 4.7 ⭐
- **Students**: 6,500
- **Modules**: 10 (Procurement, Inventory, Warehousing, Transportation, etc.)
- **Description**: Optimize supply chain operations

---

## Course 20: Business Communication
- **ID**: 20
- **Title**: Professional Communication & Presentation
- **Category**: Business / Soft Skills
- **Price**: ₹1,999 (Original: ₹6,999)
- **Duration**: 6 weeks
- **Instructor**: Simran Bhatia (TEDx Speaker)
- **Rating**: 4.9 ⭐
- **Students**: 21,800
- **Modules**: 8 (Email Writing, Presentations, Public Speaking, Meetings, etc.)
- **Description**: Master professional communication skills

---

## ✅ PROGRESS:

1. ✅ IT Courses (10 courses) - DONE
2. ✅ Business Courses (10 courses) - DONE
3. ⏳ Mechanical Courses (15 courses) - Next
4. ⏳ Other Courses (10 courses) - Final

**Ready for Mechanical courses!** 🚀
