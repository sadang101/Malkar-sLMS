# How to Set MLMS.png as App Icon

## ✅ Quick Method (Recommended - Using Android Studio)

### Step 1: Open Image Asset Studio
1. In Android Studio, right-click on `app` folder in Project view
2. Select **New → Image Asset**
3. Or go to **File → New → Image Asset**

### Step 2: Configure the Icon
1. **Icon Type**: Select "Launcher Icons (Adaptive and Legacy)"
2. **Name**: Keep as `ic_launcher`
3. **Foreground Layer**:
   - **Source Asset Type**: Select "Image"
   - **Path**: Click the folder icon and browse to:
     ```
     C:\Users\Sarang\AndroidStudioProjects\MalkarLMS\MLMS.png
     ```
4. **Background Layer**:
   - **Source Asset Type**: Select "Color"
   - **Color**: Choose black `#000000` (to match your logo background)
   
5. **Options**:
   - ✅ Check "Trim" if you want to remove extra padding
   - ✅ Check "Generate Legacy Icon" (for older Android versions)
   - ✅ Check "Generate Round Icon"

### Step 3: Preview and Generate
1. Preview the icon in different sizes on the right panel
2. Click **Next**
3. Review the files that will be generated
4. Click **Finish**

### Step 4: Build and Run
1. Sync Gradle: **File → Sync Project with Gradle Files**
2. Build the app: **Build → Rebuild Project**
3. Run on device/emulator

---

## 📱 Alternative Method (Manual - If Image Asset Studio doesn't work)

I can help you create the icon files manually. Just let me know!

---

## 🎨 Your Logo Details

**File**: `MLMS.png` (59 KB)
**Design**: Gold "M" with "MALKAR'SLMS" text on black background
**Style**: Professional, elegant, premium look
**Colors**: Gold (#D4AF37 approx) on Black (#000000)

---

## ✅ Verification

After setting the icon, you should see:
- Your MLMS logo on the home screen
- Your MLMS logo in the app drawer
- Your MLMS logo in recent apps
- Your MLMS logo in the Play Store (when published)

---

## 🔧 Troubleshooting

**Issue**: Icon not updating after installation
**Solution**: 
1. Uninstall the old app completely
2. Clear Android Studio cache: **File → Invalidate Caches → Invalidate and Restart**
3. Rebuild and reinstall

**Issue**: Icon looks pixelated
**Solution**: 
1. Make sure "Trim" is unchecked if your logo has intentional padding
2. Adjust the "Resize" slider in Image Asset Studio

---

**Ready to set your professional MLMS logo as the app icon!** 🎉
