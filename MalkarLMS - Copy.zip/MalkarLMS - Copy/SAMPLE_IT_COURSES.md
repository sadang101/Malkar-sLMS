# 10 IT COURSES - SAMPLE DATA FOR PRESENTATION

## How to Add to Firebase:

Go to Firebase Console → Firestore Database → Add these courses to the "courses" collection.

---

## Course 1: Complete Python Programming
- **ID**: 1
- **Title**: Complete Python Programming Masterclass
- **Category**: IT / Programming
- **Price**: ₹2,999 (Original: ₹9,999)
- **Duration**: 12 weeks
- **Instructor**: Dr. Rajesh Kumar (Google)
- **Rating**: 4.8 ⭐
- **Students**: 15,420
- **Modules**: 10 (Python Basics, OOP, Django, APIs, Deployment, etc.)
- **Description**: Master Python from basics to advanced with Django web development

---

## Course 2: Full Stack Web Development
- **ID**: 2
- **Title**: Full Stack Web Development Bootcamp
- **Category**: IT / Web Development
- **Price**: ₹4,499 (Original: ₹14,999)
- **Duration**: 16 weeks
- **Instructor**: Priya Sharma (Microsoft)
- **Rating**: 4.9 ⭐
- **Students**: 22,350
- **Modules**: 10 (HTML/CSS, JavaScript, React, Node.js, MongoDB, etc.)
- **Description**: Become a full-stack developer with MERN stack

---

## Course 3: Data Science & Machine Learning
- **ID**: 3
- **Title**: Data Science & ML with Python
- **Category**: IT / Data Science
- **Price**: ₹3,999 (Original: ₹12,999)
- **Duration**: 14 weeks
- **Instructor**: Dr. Amit Patel (Amazon)
- **Rating**: 4.7 ⭐
- **Students**: 18,900
- **Modules**: 10 (NumPy, Pandas, ML Algorithms, Deep Learning, NLP, etc.)
- **Description**: Learn data analysis, ML algorithms, and AI

---

## Course 4: Android App Development
- **ID**: 4
- **Title**: Android Development with Kotlin
- **Category**: IT / Mobile Development
- **Price**: ₹3,499 (Original: ₹11,999)
- **Duration**: 12 weeks
- **Instructor**: Vikram Singh (Flipkart)
- **Rating**: 4.6 ⭐
- **Students**: 12,450
- **Modules**: 10 (Kotlin, UI Design, Firebase, Play Store Publishing, etc.)
- **Description**: Build professional Android apps with Kotlin

---

## Course 5: Cloud Computing with AWS
- **ID**: 5
- **Title**: AWS Cloud Computing Masterclass
- **Category**: IT / Cloud Computing
- **Price**: ₹4,999 (Original: ₹15,999)
- **Duration**: 10 weeks
- **Instructor**: Neha Gupta (TCS)
- **Rating**: 4.8 ⭐
- **Students**: 9,800
- **Modules**: 10 (EC2, S3, Lambda, RDS, Kubernetes, etc.)
- **Description**: Master AWS and deploy scalable cloud applications

---

## Course 6: Cybersecurity & Ethical Hacking
- **ID**: 6
- **Title**: Cybersecurity Complete Course
- **Category**: IT / Cybersecurity
- **Price**: ₹5,499 (Original: ₹17,999)
- **Duration**: 14 weeks
- **Instructor**: Arjun Mehta (Deloitte)
- **Rating**: 4.9 ⭐
- **Students**: 8,500
- **Modules**: 10 (Network Security, Penetration Testing, Ethical Hacking, etc.)
- **Description**: Learn ethical hacking and cybersecurity

---

## Course 7: DevOps Engineering
- **ID**: 7
- **Title**: DevOps Complete Bootcamp
- **Category**: IT / DevOps
- **Price**: ₹4,499 (Original: ₹14,999)
- **Duration**: 12 weeks
- **Instructor**: Sanjay Reddy (Infosys)
- **Rating**: 4.7 ⭐
- **Students**: 11,200
- **Modules**: 10 (Docker, Kubernetes, Jenkins, CI/CD, Terraform, etc.)
- **Description**: Master DevOps tools and automation

---

## Course 8: Artificial Intelligence
- **ID**: 8
- **Title**: AI & Deep Learning Advanced
- **Category**: IT / Artificial Intelligence
- **Price**: ₹5,999 (Original: ₹19,999)
- **Duration**: 16 weeks
- **Instructor**: Dr. Kavita Iyer (IIT Bombay)
- **Rating**: 4.9 ⭐
- **Students**: 7,600
- **Modules**: 10 (Neural Networks, CNN, RNN, NLP, Computer Vision, etc.)
- **Description**: Build cutting-edge AI applications

---

## Course 9: Blockchain Development
- **ID**: 9
- **Title**: Blockchain & Cryptocurrency Dev
- **Category**: IT / Blockchain
- **Price**: ₹6,499 (Original: ₹21,999)
- **Duration**: 12 weeks
- **Instructor**: Rahul Verma (Polygon)
- **Rating**: 4.6 ⭐
- **Students**: 5,400
- **Modules**: 10 (Blockchain, Ethereum, Solidity, Smart Contracts, DeFi, etc.)
- **Description**: Build decentralized applications

---

## Course 10: UI/UX Design
- **ID**: 10
- **Title**: Complete UI/UX Design Course
- **Category**: IT / Design
- **Price**: ₹2,499 (Original: ₹8,999)
- **Duration**: 8 weeks
- **Instructor**: Ananya Desai (Adobe)
- **Rating**: 4.8 ⭐
- **Students**: 14,200
- **Modules**: 8 (Design Principles, Figma, Prototyping, User Research, etc.)
- **Description**: Master UI/UX design with industry tools

---

## 📝 NEXT STEPS:

1. ✅ IT Courses Created (10 courses)
2. ⏳ Business Courses (10 courses) - Next
3. ⏳ Mechanical Courses (15 courses) - After that
4. ⏳ Other Courses (10 courses) - Final

**Ready to add Business courses next!** Let me know when you're ready! 🚀
