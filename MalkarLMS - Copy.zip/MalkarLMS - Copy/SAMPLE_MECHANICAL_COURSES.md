# 15 MECHANICAL ENGINEERING COURSES - SAMPLE DATA

## Course 21: AutoCAD for Engineers
- **ID**: 21
- **Title**: Complete AutoCAD Mechanical Design
- **Category**: Mechanical / CAD
- **Price**: ₹3,499 (Original: ₹11,999)
- **Duration**: 10 weeks
- **Instructor**: Er. Vijay Patil (Tata Motors)
- **Rating**: 4.7 ⭐
- **Students**: 14,200
- **Modules**: 10 (2D Drawing, 3D Modeling, Assemblies, Annotations, etc.)

---

## Course 22: SolidWorks Mastery
- **ID**: 22
- **Title**: SolidWorks Complete Course
- **Category**: Mechanical / CAD
- **Price**: ₹4,499 (Original: ₹14,999)
- **Duration**: 12 weeks
- **Instructor**: Er. Ravi Kumar (Mahindra)
- **Rating**: 4.8 ⭐
- **Students**: 11,500
- **Modules**: 10 (Part Design, Assembly, Simulation, Sheet Metal, etc.)

---

## Course 23: ANSYS Simulation
- **ID**: 23
- **Title**: ANSYS Finite Element Analysis
- **Category**: Mechanical / Simulation
- **Price**: ₹5,999 (Original: ₹19,999)
- **Duration**: 14 weeks
- **Instructor**: Dr. Sunil Rao (IIT Delhi)
- **Rating**: 4.9 ⭐
- **Students**: 6,800
- **Modules**: 10 (FEA Basics, Structural, Thermal, CFD, Optimization, etc.)

---

## Course 24: Thermodynamics & Heat Transfer
- **ID**: 24
- **Title**: Advanced Thermodynamics
- **Category**: Mechanical / Core
- **Price**: ₹2,999 (Original: ₹9,999)
- **Duration**: 10 weeks
- **Instructor**: Prof. Ashok Desai (BITS Pilani)
- **Rating**: 4.6 ⭐
- **Students**: 9,300
- **Modules**: 10 (Laws of Thermodynamics, Cycles, Heat Transfer, etc.)

---

## Course 25: Manufacturing Processes
- **ID**: 25
- **Title**: Modern Manufacturing Technology
- **Category**: Mechanical / Manufacturing
- **Price**: ₹3,999 (Original: ₹12,999)
- **Duration**: 12 weeks
- **Instructor**: Er. Prakash Jain (Bosch)
- **Rating**: 4.7 ⭐
- **Students**: 10,600
- **Modules**: 10 (Casting, Machining, Welding, CNC, Additive, etc.)

---

## Course 26: Fluid Mechanics
- **ID**: 26
- **Title**: Fluid Mechanics & Hydraulics
- **Category**: Mechanical / Core
- **Price**: ₹2,999 (Original: ₹9,999)
- **Duration**: 10 weeks
- **Instructor**: Dr. Ramesh Nair (NIT Trichy)
- **Rating**: 4.5 ⭐
- **Students**: 8,700
- **Modules**: 10 (Fluid Properties, Flow, Pumps, Turbines, CFD, etc.)

---

## Course 27: Machine Design
- **ID**: 27
- **Title**: Mechanical Machine Design
- **Category**: Mechanical / Design
- **Price**: ₹4,499 (Original: ₹14,999)
- **Duration**: 14 weeks
- **Instructor**: Er. Mohan Singh (L&T)
- **Rating**: 4.8 ⭐
- **Students**: 7,900
- **Modules**: 10 (Design Process, Gears, Bearings, Shafts, Springs, etc.)

---

## Course 28: Robotics & Automation
- **ID**: 28
- **Title**: Industrial Robotics & Automation
- **Category**: Mechanical / Robotics
- **Price**: ₹5,499 (Original: ₹17,999)
- **Duration**: 12 weeks
- **Instructor**: Dr. Karthik Reddy (ABB Robotics)
- **Rating**: 4.9 ⭐
- **Students**: 5,400
- **Modules**: 10 (Robot Kinematics, Programming, PLC, Sensors, etc.)

---

## Course 29: Automotive Engineering
- **ID**: 29
- **Title**: Automotive Design & Technology
- **Category**: Mechanical / Automotive
- **Price**: ₹4,999 (Original: ₹16,999)
- **Duration**: 14 weeks
- **Instructor**: Er. Sandeep Mehta (Maruti Suzuki)
- **Rating**: 4.7 ⭐
- **Students**: 12,100
- **Modules**: 10 (Engine, Transmission, Chassis, EV Technology, etc.)

---

## Course 30: HVAC Systems
- **ID**: 30
- **Title**: HVAC Design & Analysis
- **Category**: Mechanical / HVAC
- **Price**: ₹3,499 (Original: ₹11,999)
- **Duration**: 10 weeks
- **Instructor**: Er. Rajiv Gupta (Blue Star)
- **Rating**: 4.6 ⭐
- **Students**: 6,200
- **Modules**: 8 (AC Systems, Refrigeration, Load Calculation, Design, etc.)

---

## Course 31: Materials Science
- **ID**: 31
- **Title**: Engineering Materials & Metallurgy
- **Category**: Mechanical / Materials
- **Price**: ₹2,999 (Original: ₹9,999)
- **Duration**: 10 weeks
- **Instructor**: Dr. Priya Iyer (BARC)
- **Rating**: 4.5 ⭐
- **Students**: 7,800
- **Modules**: 10 (Material Properties, Metals, Polymers, Composites, etc.)

---

## Course 32: CNC Programming
- **ID**: 32
- **Title**: CNC Machining & Programming
- **Category**: Mechanical / Manufacturing
- **Price**: ₹3,999 (Original: ₹12,999)
- **Duration**: 8 weeks
- **Instructor**: Er. Anil Kumar (Siemens)
- **Rating**: 4.8 ⭐
- **Students**: 9,500
- **Modules**: 8 (CNC Basics, G-Code, M-Code, CAM, Operations, etc.)

---

## Course 33: Renewable Energy Systems
- **ID**: 33
- **Title**: Renewable Energy Engineering
- **Category**: Mechanical / Energy
- **Price**: ₹4,499 (Original: ₹14,999)
- **Duration**: 12 weeks
- **Instructor**: Dr. Sunita Rao (MNRE)
- **Rating**: 4.7 ⭐
- **Students**: 5,900
- **Modules**: 10 (Solar, Wind, Hydro, Biomass, Energy Storage, etc.)

---

## Course 34: Mechanical Vibrations
- **ID**: 34
- **Title**: Vibration Analysis & Control
- **Category**: Mechanical / Core
- **Price**: ₹3,499 (Original: ₹11,999)
- **Duration**: 10 weeks
- **Instructor**: Prof. Dinesh Shah (IIT Bombay)
- **Rating**: 4.6 ⭐
- **Students**: 4,700
- **Modules**: 10 (Free Vibration, Forced, Damping, Modal Analysis, etc.)

---

## Course 35: Industrial Engineering
- **ID**: 35
- **Title**: Industrial Engineering & Operations
- **Category**: Mechanical / Industrial
- **Price**: ₹3,999 (Original: ₹12,999)
- **Duration**: 12 weeks
- **Instructor**: Er. Neha Verma (Reliance)
- **Rating**: 4.7 ⭐
- **Students**: 8,300
- **Modules**: 10 (Production Planning, Quality, Lean, Six Sigma, etc.)

---

## ✅ PROGRESS:

1. ✅ IT Courses (10 courses) - DONE
2. ✅ Business Courses (10 courses) - DONE
3. ✅ Mechanical Courses (15 courses) - DONE
4. ⏳ Other Courses (10 courses) - Final step!

**Almost done! Let's create the final 10 "Other" courses!** 🎯
