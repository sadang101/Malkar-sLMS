# 10 OTHER COURSES - DIVERSE CATEGORIES

## Course 36: Graphic Design
- **ID**: 36
- **Title**: Complete Graphic Design Masterclass
- **Category**: Design / Creative
- **Price**: ₹2,999 (Original: ₹9,999)
- **Duration**: 10 weeks
- **Instructor**: Riya Malhotra (Adobe Certified)
- **Rating**: 4.8 ⭐
- **Students**: 16,700
- **Modules**: 10 (Photoshop, Illustrator, InDesign, Branding, etc.)

---

## Course 37: Photography & Videography
- **ID**: 37
- **Title**: Professional Photography Course
- **Category**: Creative / Photography
- **Price**: ₹3,499 (Original: ₹11,999)
- **Duration**: 8 weeks
- **Instructor**: Arjun Kapoor (National Geographic)
- **Rating**: 4.9 ⭐
- **Students**: 12,400
- **Modules**: 8 (Camera Basics, Composition, Lighting, Editing, etc.)

---

## Course 38: Content Writing
- **ID**: 38
- **Title**: Content Writing & Copywriting
- **Category**: Writing / Content
- **Price**: ₹1,999 (Original: ₹6,999)
- **Duration**: 6 weeks
- **Instructor**: Sneha Reddy (Forbes Contributor)
- **Rating**: 4.7 ⭐
- **Students**: 18,900
- **Modules**: 8 (SEO Writing, Blogging, Copywriting, Social Media, etc.)

---

## Course 39: Spoken English
- **ID**: 39
- **Title**: Master English Communication
- **Category**: Language / English
- **Price**: ₹1,499 (Original: ₹4,999)
- **Duration**: 8 weeks
- **Instructor**: Prof. Sarah Williams (British Council)
- **Rating**: 4.8 ⭐
- **Students**: 24,500
- **Modules**: 8 (Grammar, Vocabulary, Pronunciation, Conversation, etc.)

---

## Course 40: Personal Finance
- **ID**: 40
- **Title**: Personal Finance & Investment
- **Category**: Finance / Personal
- **Price**: ₹2,499 (Original: ₹7,999)
- **Duration**: 6 weeks
- **Instructor**: CA Amit Jain (Zerodha)
- **Rating**: 4.9 ⭐
- **Students**: 22,100
- **Modules**: 8 (Budgeting, Stocks, Mutual Funds, Tax Planning, etc.)

---

## Course 41: Yoga & Wellness
- **ID**: 41
- **Title**: Complete Yoga Teacher Training
- **Category**: Health / Wellness
- **Price**: ₹3,999 (Original: ₹12,999)
- **Duration**: 12 weeks
- **Instructor**: Guru Anand Sharma (Yoga Alliance)
- **Rating**: 4.8 ⭐
- **Students**: 9,800
- **Modules**: 10 (Asanas, Pranayama, Meditation, Anatomy, Teaching, etc.)

---

## Course 42: Music Production
- **ID**: 42
- **Title**: Electronic Music Production
- **Category**: Music / Production
- **Price**: ₹4,499 (Original: ₹14,999)
- **Duration**: 10 weeks
- **Instructor**: DJ Rohan (Berklee Graduate)
- **Rating**: 4.7 ⭐
- **Students**: 7,600
- **Modules**: 10 (FL Studio, Ableton, Mixing, Mastering, Sound Design, etc.)

---

## Course 43: Interior Design
- **ID**: 43
- **Title**: Interior Design Complete Course
- **Category**: Design / Interior
- **Price**: ₹3,999 (Original: ₹12,999)
- **Duration**: 12 weeks
- **Instructor**: Ar. Priya Desai (IIID Member)
- **Rating**: 4.6 ⭐
- **Students**: 8,900
- **Modules**: 10 (Space Planning, Color Theory, 3D Design, Materials, etc.)

---

## Course 44: Civil Engineering Basics
- **ID**: 44
- **Title**: Civil Engineering Fundamentals
- **Category**: Engineering / Civil
- **Price**: ₹3,499 (Original: ₹11,999)
- **Duration**: 12 weeks
- **Instructor**: Er. Suresh Pillai (L&T Construction)
- **Rating**: 4.7 ⭐
- **Students**: 11,200
- **Modules**: 10 (Structures, Surveying, Concrete, Estimation, AutoCAD, etc.)

---

## Course 45: Electrical Engineering
- **ID**: 45
- **Title**: Electrical Systems & Power
- **Category**: Engineering / Electrical
- **Price**: ₹3,999 (Original: ₹12,999)
- **Duration**: 14 weeks
- **Instructor**: Er. Ramesh Kumar (BHEL)
- **Rating**: 4.8 ⭐
- **Students**: 9,400
- **Modules**: 10 (Circuits, Machines, Power Systems, Control, PLC, etc.)

---

## 🎉 ALL COURSES COMPLETE!

### ✅ FINAL COUNT:
1. ✅ IT Courses: 10 courses (IDs 1-10)
2. ✅ Business Courses: 10 courses (IDs 11-20)
3. ✅ Mechanical Courses: 15 courses (IDs 21-35)
4. ✅ Other Courses: 10 courses (IDs 36-45)

**TOTAL: 45 PROFESSIONAL COURSES** 🚀

---

## 📝 HOW TO ADD TO FIREBASE:

### Option 1: Firebase Console (Manual)
1. Go to Firebase Console
2. Open Firestore Database
3. Create "courses" collection
4. Add each course as a document with these fields:
   - id, title, category, price, duration, instructor, rating, students, modules, description

### Option 2: Import Script (Recommended)
I can create a script to bulk import all 45 courses to Firebase!

**Ready to add these to your app!** 🎯
