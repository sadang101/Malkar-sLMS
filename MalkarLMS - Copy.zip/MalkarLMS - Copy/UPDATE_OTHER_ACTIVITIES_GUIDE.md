# Guide: Updating Other Activities with New Course Design

## Overview
This guide shows how to update other activities (SearchActivity, MoreCoursesActivity, etc.) to use the new enhanced course card design with all the additional information.

---

## Step 1: Update Course Creation in Activities

### SearchActivity.kt

**Location**: `getAllSampleCourses()` method

**Current Code** (Example):
```kotlin
Course(1, "Complete Python Programming", "Master Python", "12 weeks", "₹2,999", "", "Dr. Rajesh Kumar", 4.8f, 15420, 0, "IT", "Beginner")
```

**Updated Code** (Add new fields):
```kotlin
Course(
    id = 1,
    title = "Complete Python Programming Masterclass",
    description = "Master Python from basics to advanced with Django web development",
    duration = "12 weeks",
    price = "₹2,999",
    imageUrl = "",
    instructor = "Dr. Rajesh Kumar",
    rating = 4.8f,
    studentsEnrolled = 15420,
    enrollmentCount = 0,
    category = "Programming",
    level = "Beginner",
    difficulty = "",
    isEnrolled = false,
    createdAt = System.currentTimeMillis(),
    language = "English",              // NEW
    modulesCount = 8,                   // NEW
    lecturesCount = 120,                // NEW
    certificateAvailable = true,        // NEW
    lastUpdated = "Updated Nov 2024",   // NEW
    tags = listOf("Python", "Django", "Web Development"),  // NEW
    prerequisites = "Basic computer knowledge",             // NEW
    learningOutcomes = listOf(          // NEW
        "Master Python programming",
        "Build Django applications"
    )
)
```

---

### MoreCoursesActivity.kt

**Location**: `getSampleCourses()` method

**Find and Replace Pattern**:

**OLD**:
```kotlin
Course(1, "Digital Marketing", "Learn marketing", "10 weeks", "₹1000", "", "Meera Kapoor", 4.8f, 19500, 0, "Business", "Beginner")
```

**NEW**:
```kotlin
Course(
    id = 1,
    title = "Digital Marketing Mastery",
    description = "Learn modern digital marketing strategies and grow your business",
    duration = "10 weeks",
    price = "₹1,000",
    imageUrl = "",
    instructor = "Meera Kapoor",
    rating = 4.8f,
    studentsEnrolled = 19500,
    enrollmentCount = 0,
    category = "Marketing",
    level = "Beginner",
    difficulty = "",
    isEnrolled = false,
    createdAt = System.currentTimeMillis(),
    language = "English",
    modulesCount = 7,
    lecturesCount = 95,
    certificateAvailable = true,
    lastUpdated = "Updated Nov 2024",
    tags = listOf("SEO", "Social Media", "Content Marketing"),
    prerequisites = "None",
    learningOutcomes = listOf(
        "Master SEO techniques",
        "Run social media campaigns",
        "Analyze marketing metrics"
    )
)
```

---

## Step 2: Update Firebase Firestore Queries

### MyCoursesActivity.kt

**Location**: Firebase query in `loadEnrolledCourses()`

**Current Code**:
```kotlin
val course = Course(
    id = doc.getLong("id")?.toInt() ?: 0,
    title = doc.getString("title") ?: "Untitled Course",
    description = doc.getString("description") ?: "",
    duration = doc.getString("duration") ?: "",
    price = doc.getString("price") ?: "₹0"
)
```

**Updated Code** (Add new field retrievals):
```kotlin
val course = Course(
    id = doc.getLong("id")?.toInt() ?: 0,
    title = doc.getString("title") ?: "Untitled Course",
    description = doc.getString("description") ?: "",
    duration = doc.getString("duration") ?: "",
    price = doc.getString("price") ?: "₹0",
    imageUrl = doc.getString("imageUrl") ?: "",
    instructor = doc.getString("instructor") ?: "Expert Instructor",
    rating = doc.getDouble("rating")?.toFloat() ?: 0.0f,
    studentsEnrolled = doc.getLong("studentsEnrolled")?.toInt() ?: 0,
    enrollmentCount = doc.getLong("enrollmentCount")?.toInt() ?: 0,
    category = doc.getString("category") ?: "General",
    level = doc.getString("level") ?: "Beginner",
    difficulty = doc.getString("difficulty") ?: "",
    isEnrolled = true,
    createdAt = doc.getLong("createdAt") ?: System.currentTimeMillis(),
    // NEW FIELDS
    language = doc.getString("language") ?: "English",
    modulesCount = doc.getLong("modulesCount")?.toInt() ?: 0,
    lecturesCount = doc.getLong("lecturesCount")?.toInt() ?: 0,
    certificateAvailable = doc.getBoolean("certificateAvailable") ?: true,
    lastUpdated = doc.getString("lastUpdated") ?: "",
    tags = (doc.get("tags") as? List<*>)?.mapNotNull { it as? String } ?: emptyList(),
    prerequisites = doc.getString("prerequisites") ?: "",
    learningOutcomes = (doc.get("learningOutcomes") as? List<*>)?.mapNotNull { it as? String } ?: emptyList()
)
```

---

## Step 3: Update Firebase Firestore Database

### Add New Fields to Existing Courses

**Firebase Console Steps**:
1. Go to Firebase Console → Firestore Database
2. Navigate to `courses` collection
3. For each course document, add these fields:

```javascript
{
  // Existing fields...
  "title": "Complete Python Programming",
  "description": "Master Python...",
  "duration": "12 weeks",
  "price": "₹2,999",
  "instructor": "Dr. Rajesh Kumar",
  "rating": 4.8,
  "studentsEnrolled": 15420,
  "category": "Programming",
  "level": "Beginner",
  
  // NEW FIELDS TO ADD:
  "language": "English",
  "modulesCount": 8,
  "lecturesCount": 120,
  "certificateAvailable": true,
  "lastUpdated": "Updated Nov 2024",
  "tags": ["Python", "Django", "Web Development", "Backend"],
  "prerequisites": "Basic computer knowledge",
  "learningOutcomes": [
    "Master Python programming fundamentals",
    "Build web applications with Django",
    "Work with databases and APIs",
    "Deploy production-ready applications"
  ]
}
```

### Bulk Update Script (Optional)

Create a Cloud Function or admin script:

```javascript
const admin = require('firebase-admin');
admin.initializeApp();
const db = admin.firestore();

async function updateCourses() {
  const coursesRef = db.collection('courses');
  const snapshot = await coursesRef.get();
  
  const batch = db.batch();
  
  snapshot.forEach(doc => {
    batch.update(doc.ref, {
      language: 'English',
      modulesCount: 8,
      lecturesCount: 100,
      certificateAvailable: true,
      lastUpdated: 'Updated Nov 2024',
      tags: [],
      prerequisites: '',
      learningOutcomes: []
    });
  });
  
  await batch.commit();
  console.log('Updated all courses!');
}

updateCourses();
```

---

## Step 4: Update Course Creation Activity

### CourseCreationActivity.kt

Add new input fields for instructors to enter:

**Add to layout (activity_course_creation.xml)**:
```xml
<!-- Language Selection -->
<com.google.android.material.textfield.TextInputLayout
    android:layout_width="match_parent"
    android:layout_height="wrap_content"
    android:hint="Language"
    style="@style/Widget.MaterialComponents.TextInputLayout.OutlinedBox.ExposedDropdownMenu">
    
    <AutoCompleteTextView
        android:id="@+id/etLanguage"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:inputType="none" />
</com.google.android.material.textfield.TextInputLayout>

<!-- Modules Count -->
<com.google.android.material.textfield.TextInputLayout
    android:layout_width="match_parent"
    android:layout_height="wrap_content"
    android:hint="Number of Modules">
    
    <com.google.android.material.textfield.TextInputEditText
        android:id="@+id/etModulesCount"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:inputType="number" />
</com.google.android.material.textfield.TextInputLayout>

<!-- Lectures Count -->
<com.google.android.material.textfield.TextInputLayout
    android:layout_width="match_parent"
    android:layout_height="wrap_content"
    android:hint="Number of Lectures">
    
    <com.google.android.material.textfield.TextInputEditText
        android:id="@+id/etLecturesCount"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:inputType="number" />
</com.google.android.material.textfield.TextInputLayout>

<!-- Certificate Checkbox -->
<com.google.android.material.checkbox.MaterialCheckBox
    android:id="@+id/cbCertificate"
    android:layout_width="match_parent"
    android:layout_height="wrap_content"
    android:text="Certificate Available"
    android:checked="true" />

<!-- Prerequisites -->
<com.google.android.material.textfield.TextInputLayout
    android:layout_width="match_parent"
    android:layout_height="wrap_content"
    android:hint="Prerequisites">
    
    <com.google.android.material.textfield.TextInputEditText
        android:id="@+id/etPrerequisites"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:inputType="textMultiLine"
        android:minLines="2" />
</com.google.android.material.textfield.TextInputLayout>
```

**Update Kotlin code**:
```kotlin
private fun saveCourse() {
    val courseData = hashMapOf(
        // Existing fields...
        "title" to etTitle.text.toString(),
        "description" to etDescription.text.toString(),
        "duration" to etDuration.text.toString(),
        "price" to etPrice.text.toString(),
        
        // NEW FIELDS
        "language" to etLanguage.text.toString(),
        "modulesCount" to etModulesCount.text.toString().toIntOrNull() ?: 0,
        "lecturesCount" to etLecturesCount.text.toString().toIntOrNull() ?: 0,
        "certificateAvailable" to cbCertificate.isChecked,
        "lastUpdated" to SimpleDateFormat("MMM yyyy", Locale.getDefault()).format(Date()),
        "prerequisites" to etPrerequisites.text.toString(),
        "tags" to emptyList<String>(), // Can add tag input later
        "learningOutcomes" to emptyList<String>() // Can add outcomes input later
    )
    
    firestore.collection("courses")
        .add(courseData)
        .addOnSuccessListener { /* Success */ }
        .addOnFailureListener { /* Error */ }
}
```

---

## Step 5: Update Other Adapters (If Any)

### StudentCoursesAdapter.kt, InstructorCoursesAdapter.kt

If you have custom adapters for different views, update them similarly to `CourseAdapter.kt`:

1. Add new ViewHolder fields
2. Update `onBindViewHolder()` to bind new data
3. Ensure layout XML matches `item_course_card.xml`

---

## Step 6: Testing Checklist

### Visual Testing
- [ ] All course cards display correctly
- [ ] Level badges show correct colors
- [ ] Category badges display properly
- [ ] Info grid aligns correctly
- [ ] Price badge is prominent
- [ ] Certificate badge shows/hides correctly

### Data Testing
- [ ] All new fields populate correctly
- [ ] Default values work when fields are missing
- [ ] Firebase queries return complete data
- [ ] Course creation saves all fields
- [ ] Search and filter work with new fields

### Edge Cases
- [ ] Long course titles (2+ lines)
- [ ] Long descriptions
- [ ] Zero modules/lectures (shows default text)
- [ ] Missing certificate (badge hidden)
- [ ] Different levels (Beginner/Intermediate/Advanced)
- [ ] Various categories

### Device Testing
- [ ] Small screens (5")
- [ ] Medium screens (6")
- [ ] Large screens (7"+)
- [ ] Tablets
- [ ] Different Android versions

---

## Step 7: Rollout Strategy

### Phase 1: Dashboard (✅ COMPLETED)
- Updated `DashboardActivity.kt`
- New course card design live
- All new fields implemented

### Phase 2: Search & Browse
- Update `SearchActivity.kt`
- Update `MoreCoursesActivity.kt`
- Ensure consistent design

### Phase 3: User Courses
- Update `MyCoursesActivity.kt`
- Update Firebase queries
- Test with real user data

### Phase 4: Instructor Views
- Update `InstructorCoursesActivity.kt`
- Update course creation form
- Add new field inputs

### Phase 5: Database Migration
- Update existing Firestore documents
- Add new fields to all courses
- Verify data integrity

### Phase 6: Production
- Deploy to production
- Monitor analytics
- Gather user feedback

---

## Common Issues & Solutions

### Issue 1: Layout Not Updating
**Solution**: Clean and rebuild project
```bash
.\gradlew clean
.\gradlew assembleDebug
```

### Issue 2: Missing View IDs
**Solution**: Ensure XML layout has all required IDs:
- `tvLevel`
- `tvCategory`
- `tvLevelInfo`
- `tvLanguage`
- `tvModulesLectures`
- `tvCertificate`

### Issue 3: Null Pointer Exceptions
**Solution**: Use safe calls and default values:
```kotlin
holder.languageTextView.text = course.language.ifEmpty { "English" }
```

### Issue 4: Firebase Data Not Loading
**Solution**: Check Firestore security rules:
```javascript
match /courses/{courseId} {
  allow read: if true;
  allow write: if request.auth != null;
}
```

---

## Performance Optimization

### RecyclerView Optimization
```kotlin
// In adapter initialization
init {
    setHasStableIds(true)
}

override fun getItemId(position: Int): Long {
    return courses[position].id.toLong()
}
```

### Image Loading (Future Enhancement)
```kotlin
// When adding course images
Glide.with(context)
    .load(course.imageUrl)
    .placeholder(R.drawable.course_placeholder)
    .into(holder.courseImageView)
```

---

## Conclusion

Following this guide will ensure consistent implementation of the new course card design across all activities in your app. The enhanced design provides:

- **Better user experience** with more information
- **Professional appearance** that builds trust
- **Consistent design language** across the app
- **Scalable architecture** for future enhancements

Remember to test thoroughly after each update and gather user feedback to continuously improve the design.
