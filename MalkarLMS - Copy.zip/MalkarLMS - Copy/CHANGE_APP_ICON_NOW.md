# 🎨 Change App Icon to MLMS Logo - Step by Step

## Current Status
❌ App showing default green Android icon  
✅ MLMS.png logo file ready at project root

---

## 📱 **FOLLOW THESE EXACT STEPS IN ANDROID STUDIO:**

### Step 1: Open Image Asset Studio
1. In Android Studio, look at the left side **Project panel**
2. Find and **right-click** on the **`app`** folder (not `app/src`, just `app`)
3. From the menu, select: **New → Image Asset**
   
   *Can't find it?* Try: **File → New → Image Asset** from the top menu

---

### Step 2: Configure Your Icon

You'll see a window with options. Fill them EXACTLY like this:

#### **Icon Type Section:**
- Select: **"Launcher Icons (Adaptive and Legacy)"**

#### **Foreground Layer Tab:**
1. **Name**: Leave as `ic_launcher`
2. **Asset Type**: Click dropdown and select **"Image"**
3. **Path**: Click the **📁 folder icon** next to the path field
4. Navigate to and select:
   ```
   C:\Users\Sarang\AndroidStudioProjects\MalkarLMS\MLMS.png
   ```
5. **Resize**: Set to **100%** (or adjust if needed)
6. **Trim**: ✅ Check this box (removes extra padding)

#### **Background Layer Tab:**
1. Click the **"Background Layer"** tab at the top
2. **Asset Type**: Select **"Color"**
3. **Color**: Click the color box and enter: `#000000` (black)
   - Or use the color picker to select pure black

#### **Options Section:**
- ✅ **Generate Legacy Icon**: CHECK THIS
- ✅ **Generate Round Icon**: CHECK THIS

---

### Step 3: Preview
- Look at the right side panel
- You should see your MLMS logo in different sizes
- Make sure it looks good in all previews

---

### Step 4: Generate
1. Click **"Next"** button at the bottom
2. You'll see a list of files that will be created/replaced
3. Click **"Finish"**

---

### Step 5: Clean and Rebuild
1. **Uninstall the old app** from your device/emulator first (important!)
2. In Android Studio:
   - **Build → Clean Project**
   - Wait for it to finish
   - **Build → Rebuild Project**
3. **Run the app** on your device

---

## ✅ **Expected Result**

After these steps, you should see:
- 🎨 Your gold MLMS logo on black background
- 📱 Icon on home screen
- 📱 Icon in app drawer
- 📱 Icon in recent apps

---

## 🔧 **Troubleshooting**

### Problem: Icon still showing green Android
**Solution:**
1. Completely **uninstall** the app from your device
2. In Android Studio: **File → Invalidate Caches → Invalidate and Restart**
3. After restart, **Build → Clean Project**
4. Then **Build → Rebuild Project**
5. Install fresh

### Problem: Can't find "Image Asset" option
**Solution:**
1. Make sure you right-click on the **`app`** folder (top level)
2. Or use menu: **File → New → Image Asset**
3. If still not there, update Android Studio to latest version

### Problem: Icon looks stretched or weird
**Solution:**
1. Redo the process
2. In **Foreground Layer**, adjust the **Resize** slider
3. Try values between 80% - 100%

---

## 📸 **What You Should See in Image Asset Studio**

The window should have:
- Left side: Configuration options
- Right side: Preview of your icon in different sizes
- Bottom: Next/Finish buttons

---

## ⚡ **Quick Alternative (If Image Asset doesn't work)**

If you can't access Image Asset Studio, I can create the icon files manually for you. Just let me know!

---

**Let me know if you need help with any step!** 🚀
