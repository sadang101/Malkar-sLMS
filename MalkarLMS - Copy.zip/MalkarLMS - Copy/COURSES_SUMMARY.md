# 🎓 45 COURSES CREATED FOR YOUR PRESENTATION

## ✅ COMPLETE LIST:

### 📱 IT Courses (10):
1. Python Programming
2. Full Stack Web Development
3. Data Science & ML
4. Android Development
5. Cloud Computing (AWS)
6. Cybersecurity
7. DevOps Engineering
8. Artificial Intelligence
9. Blockchain Development
10. UI/UX Design

### 💼 Business Courses (10):
11. Digital Marketing
12. MBA Essentials
13. Financial Analysis
14. Entrepreneurship
15. Project Management (PMP)
16. HR Management
17. Sales & Negotiation
18. Business Analytics
19. Supply Chain Management
20. Business Communication

### ⚙️ Mechanical Courses (15):
21. AutoCAD
22. SolidWorks
23. ANSYS Simulation
24. Thermodynamics
25. Manufacturing Processes
26. Fluid Mechanics
27. Machine Design
28. Robotics & Automation
29. Automotive Engineering
30. HVAC Systems
31. Materials Science
32. CNC Programming
33. Renewable Energy
34. Mechanical Vibrations
35. Industrial Engineering

### 🎨 Other Courses (10):
36. Graphic Design
37. Photography
38. Content Writing
39. Spoken English
40. Personal Finance
41. Yoga & Wellness
42. Music Production
43. Interior Design
44. Civil Engineering
45. Electrical Engineering

---

## 🚀 HOW TO ADD TO FIREBASE:

1. Open Firebase Console
2. Go to Firestore Database
3. Create "courses" collection
4. Add documents with these fields:
   - id, title, category, price, duration, instructor, rating, students

**All details are in the 4 markdown files I created!**

Your app will now show courses on the dashboard! 🎉
