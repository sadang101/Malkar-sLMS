package com.malkarlms.app

import android.app.Application
import android.content.Context
import android.util.Log
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class MalkarLMSApplication : Application() {
    
    override fun onCreate() {
        super.onCreate()
        
        // Apply saved language
        applyLanguage()
        
        // Set up global exception handler to prevent crashes
        setupGlobalExceptionHandler()
        
        try {
            // Initialize Firebase
            FirebaseApp.initializeApp(this)
            
            // Enable Firestore offline persistence
            val firestore = FirebaseFirestore.getInstance()
            firestore.firestoreSettings = com.google.firebase.firestore.FirebaseFirestoreSettings.Builder()
                .setPersistenceEnabled(true)
                .setCacheSizeBytes(com.google.firebase.firestore.FirebaseFirestoreSettings.CACHE_SIZE_UNLIMITED)
                .build()
            
            Log.d("MalkarLMSApp", "✅ Firebase initialized successfully")
            
        } catch (e: Exception) {
            Log.e("MalkarLMSApp", "❌ Firebase initialization failed", e)
        }
    }
    
    private fun setupGlobalExceptionHandler() {
        val defaultHandler = Thread.getDefaultUncaughtExceptionHandler()
        
        Thread.setDefaultUncaughtExceptionHandler { thread, exception ->
            Log.e("MalkarLMSApp", "💥 Uncaught exception in thread ${thread.name}", exception)
            
            // Log the crash details
            Log.e("MalkarLMSApp", "Exception type: ${exception.javaClass.simpleName}")
            Log.e("MalkarLMSApp", "Exception message: ${exception.message}")
            Log.e("MalkarLMSApp", "Stack trace: ${exception.stackTraceToString()}")
            
            // Call the default handler to maintain normal crash behavior
            defaultHandler?.uncaughtException(thread, exception)
        }
    }
    
    private fun applyLanguage() {
        val languageCode = LocaleHelper.getLanguage(this)
        LocaleHelper.setLocale(this, languageCode)
        Log.d("MalkarLMSApp", "✅ Language applied: $languageCode")
    }
    
    override fun attachBaseContext(base: Context) {
        val languageCode = LocaleHelper.getLanguage(base)
        val context = LocaleHelper.setLocale(base, languageCode)
        super.attachBaseContext(context)
    }
}
