// This file has been removed to avoid duplicate declarations.
// FileUtils, FileType, and UploadStatus are now defined in CourseFile.kt
