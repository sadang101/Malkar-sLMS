package com.malkarlms.app

import android.content.Context
import android.util.Log
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

object FirebaseConfigChecker {
    
    fun checkConfiguration(context: Context): ConfigurationResult {
        val issues = mutableListOf<String>()
        var isValid = true
        
        try {
            // Check if Firebase is initialized
            val firebaseApp = FirebaseApp.getInstance()
            Log.d("FirebaseChecker", "✅ Firebase App initialized: ${firebaseApp.name}")
            
            // Check Firebase Auth
            val auth = FirebaseAuth.getInstance()
            if (auth.app == null) {
                issues.add("❌ Firebase Auth not properly initialized")
                isValid = false
            } else {
                Log.d("FirebaseChecker", "✅ Firebase Auth initialized")
            }
            
            // Check Firestore
            val firestore = FirebaseFirestore.getInstance()
            if (firestore.app == null) {
                issues.add("❌ Firestore not properly initialized")
                isValid = false
            } else {
                Log.d("FirebaseChecker", "✅ Firestore initialized")
            }
            
            // Check google-services.json configuration
            val packageName = context.packageName
            Log.d("FirebaseChecker", "App package name: $packageName")
            
            // Check if the package name matches what's expected
            if (packageName != "com.malkarlms.app") {
                issues.add("⚠️ Package name mismatch: Expected 'com.malkarlms.app', got '$packageName'")
            }
            
        } catch (e: Exception) {
            Log.e("FirebaseChecker", "❌ Firebase configuration error", e)
            issues.add("❌ Firebase initialization failed: ${e.message}")
            isValid = false
        }
        
        return ConfigurationResult(isValid, issues)
    }
    
    data class ConfigurationResult(
        val isValid: Boolean,
        val issues: List<String>
    )
}
