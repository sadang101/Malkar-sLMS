package com.malkarlms.app

import android.Manifest
import android.content.ContentResolver
import android.content.Intent
import android.content.pm.PackageManager
import android.database.Cursor
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.util.Log
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
// import com.google.firebase.storage.FirebaseStorage // Will add later for file upload
import java.util.*

class CourseCreationActivity : AppCompatActivity() {
    
    private lateinit var toolbar: Toolbar
    private lateinit var etCourseTitle: EditText
    private lateinit var etCourseDescription: EditText
    private lateinit var etDetailedDescription: EditText
    private lateinit var etCourseDuration: EditText
    private lateinit var etCoursePrice: EditText
    private lateinit var spinnerCategory: Spinner
    private lateinit var spinnerDifficulty: Spinner
    private lateinit var etPrerequisites: EditText
    private lateinit var etLearningOutcomes: EditText
    private lateinit var btnSaveDraft: Button
    private lateinit var btnPublishCourse: Button
    private lateinit var progressBar: ProgressBar
    
    // File management components
    private lateinit var btnAddVideo: Button
    private lateinit var btnAddDocument: Button
    private lateinit var btnAddImage: Button
    private lateinit var recyclerViewFiles: RecyclerView
    private lateinit var layoutEmptyFiles: LinearLayout
    private lateinit var filesAdapter: CourseFilesAdapter
    private val courseFiles = mutableListOf<CourseFile>()
    
    private lateinit var firestore: FirebaseFirestore
    private lateinit var auth: FirebaseAuth
    // private lateinit var storage: FirebaseStorage // Will add later for file upload
    
    // Permission request codes
    private val PERMISSION_REQUEST_CODE = 100
    
    // Permission launcher for modern Android
    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val allGranted = permissions.values.all { it }
        if (allGranted) {
            Toast.makeText(this, "Permissions granted! You can now select files.", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "Some permissions were denied. File access may be limited.", Toast.LENGTH_LONG).show()
        }
    }
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_course_creation)
        
        initFirebase()
        initViews()
        setupToolbar()
        setupSpinners()
        setupClickListeners()
    }
    
    private fun initFirebase() {
        firestore = FirebaseFirestore.getInstance()
        auth = FirebaseAuth.getInstance()
        // storage = FirebaseStorage.getInstance() // Will add later for file upload
    }
    
    private fun initViews() {
        toolbar = findViewById(R.id.toolbar)
        etCourseTitle = findViewById(R.id.etCourseTitle)
        etCourseDescription = findViewById(R.id.etCourseDescription)
        etDetailedDescription = findViewById(R.id.etDetailedDescription)
        etCourseDuration = findViewById(R.id.etCourseDuration)
        etCoursePrice = findViewById(R.id.etCoursePrice)
        spinnerCategory = findViewById(R.id.spinnerCategory)
        spinnerDifficulty = findViewById(R.id.spinnerDifficulty)
        etPrerequisites = findViewById(R.id.etPrerequisites)
        etLearningOutcomes = findViewById(R.id.etLearningOutcomes)
        btnSaveDraft = findViewById(R.id.btnSaveDraft)
        btnPublishCourse = findViewById(R.id.btnPublishCourse)
        progressBar = findViewById(R.id.progressBar)
        
        // File management views
        btnAddVideo = findViewById(R.id.btnAddVideo)
        btnAddDocument = findViewById(R.id.btnAddDocument)
        btnAddImage = findViewById(R.id.btnAddImage)
        recyclerViewFiles = findViewById(R.id.recyclerViewFiles)
        layoutEmptyFiles = findViewById(R.id.layoutEmptyFiles)
        
        setupFilesRecyclerView()
    }
    
    private fun setupToolbar() {
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "Create New Course"
    }
    
    private fun setupSpinners() {
        // Category Spinner
        val categories = arrayOf(
            "Select Category",
            "Technology",
            "Business",
            "Design",
            "Marketing",
            "Personal Development",
            "Health & Fitness",
            "Language",
            "Music",
            "Photography"
        )
        
        val categoryAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, categories)
        categoryAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerCategory.adapter = categoryAdapter
        
        // Difficulty Spinner
        val difficulties = arrayOf("Select Difficulty", "Beginner", "Intermediate", "Advanced", "Expert")
        val difficultyAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, difficulties)
        difficultyAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerDifficulty.adapter = difficultyAdapter
    }
    
    private fun setupClickListeners() {
        btnSaveDraft.setOnClickListener {
            saveCourse(isDraft = true)
        }
        
        btnPublishCourse.setOnClickListener {
            saveCourse(isDraft = false)
        }
        
        // File picker buttons
        btnAddVideo.setOnClickListener {
            if (checkAndRequestPermissions()) {
                openFilePicker("video/*")
            }
        }
        
        btnAddDocument.setOnClickListener {
            if (checkAndRequestPermissions()) {
                openFilePicker("application/*,text/*")
            }
        }
        
        btnAddImage.setOnClickListener {
            if (checkAndRequestPermissions()) {
                openFilePicker("image/*")
            }
        }
    }
    
    private fun saveCourse(isDraft: Boolean) {
        if (!validateInputs()) return
        
        showLoading(true)
        
        val currentUser = auth.currentUser
        if (currentUser == null) {
            showLoading(false)
            Toast.makeText(this, "Please login to create courses", Toast.LENGTH_SHORT).show()
            return
        }
        
        val courseData = hashMapOf(
            "title" to etCourseTitle.text.toString().trim(),
            "description" to etCourseDescription.text.toString().trim(),
            "detailedDescription" to etDetailedDescription.text.toString().trim(),
            "duration" to etCourseDuration.text.toString().trim(),
            "price" to etCoursePrice.text.toString().trim(),
            "category" to spinnerCategory.selectedItem.toString(),
            "difficulty" to spinnerDifficulty.selectedItem.toString(),
            "prerequisites" to etPrerequisites.text.toString().trim(),
            "learningOutcomes" to etLearningOutcomes.text.toString().trim(),
            "instructorId" to currentUser.uid,
            "instructorName" to (currentUser.displayName ?: currentUser.email ?: "Unknown Instructor"),
            "instructorEmail" to currentUser.email,
            "isDraft" to isDraft,
            "isPublished" to !isDraft,
            "createdAt" to System.currentTimeMillis(),
            "updatedAt" to System.currentTimeMillis(),
            "enrollmentCount" to 0,
            "rating" to 0.0,
            "reviewCount" to 0,
            "totalEarnings" to 0.0,
            "views" to 0
        )
        
        Log.d("CourseCreation", "Saving course data: $courseData")
        
        firestore.collection("courses")
            .add(courseData)
            .addOnSuccessListener { documentReference ->
                showLoading(false)
                val message = if (isDraft) "Course saved as draft!" else "Course published successfully!"
                Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
                
                Log.d("CourseCreation", "✅ Course created successfully with ID: ${documentReference.id}")
                Log.d("CourseCreation", "Course title: ${courseData["title"]}")
                Log.d("CourseCreation", "Instructor ID: ${courseData["instructorId"]}")
                
                // Navigate back to instructor dashboard
                val intent = Intent(this, InstructorDashboardActivity::class.java)
                intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
                startActivity(intent)
                finish()
            }
            .addOnFailureListener { e ->
                showLoading(false)
                Log.w("CourseCreation", "Error creating course", e)
                Toast.makeText(this, "Failed to create course: ${e.message}", Toast.LENGTH_LONG).show()
            }
    }
    
    private fun validateInputs(): Boolean {
        val validationError = FirebaseHelper.validateCourseData(
            title = etCourseTitle.text.toString().trim(),
            description = etCourseDescription.text.toString().trim(),
            duration = etCourseDuration.text.toString().trim(),
            price = etCoursePrice.text.toString().trim(),
            category = spinnerCategory.selectedItem.toString(),
            difficulty = spinnerDifficulty.selectedItem.toString()
        )
        
        if (validationError != null) {
            Toast.makeText(this, validationError, Toast.LENGTH_SHORT).show()
            
            // Focus on the first error field
            when {
                etCourseTitle.text.toString().trim().isEmpty() -> {
                    etCourseTitle.error = validationError
                    etCourseTitle.requestFocus()
                }
                etCourseDescription.text.toString().trim().isEmpty() -> {
                    etCourseDescription.error = validationError
                    etCourseDescription.requestFocus()
                }
                etCourseDuration.text.toString().trim().isEmpty() -> {
                    etCourseDuration.error = validationError
                    etCourseDuration.requestFocus()
                }
                etCoursePrice.text.toString().trim().isEmpty() -> {
                    etCoursePrice.error = validationError
                    etCoursePrice.requestFocus()
                }
            }
            return false
        }
        
        return true
    }
    
    private fun showLoading(show: Boolean) {
        progressBar.visibility = if (show) android.view.View.VISIBLE else android.view.View.GONE
        btnSaveDraft.isEnabled = !show
        btnPublishCourse.isEnabled = !show
    }
    
    private fun setupFilesRecyclerView() {
        filesAdapter = CourseFilesAdapter(courseFiles) { file ->
            removeFile(file)
        }
        recyclerViewFiles.layoutManager = LinearLayoutManager(this)
        recyclerViewFiles.adapter = filesAdapter
        updateFilesVisibility()
    }
    
    private fun updateFilesVisibility() {
        if (courseFiles.isEmpty()) {
            recyclerViewFiles.visibility = View.GONE
            layoutEmptyFiles.visibility = View.VISIBLE
        } else {
            recyclerViewFiles.visibility = View.VISIBLE
            layoutEmptyFiles.visibility = View.GONE
        }
    }
    
    // File picker launcher
    private val filePickerLauncher = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let { handleSelectedFile(it) }
    }
    
    // Using the multiple permissions launcher defined above
    
    private fun openFilePicker(mimeType: String) {
        // Check permissions using the new system
        if (!checkAndRequestPermissions()) {
            return
        }
        
        try {
            val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
                type = mimeType
                addCategory(Intent.CATEGORY_OPENABLE)
                putExtra(Intent.EXTRA_ALLOW_MULTIPLE, false)
            }
            filePickerLauncher.launch(mimeType)
        } catch (e: Exception) {
            Log.e("FilePicker", "Error opening file picker", e)
            Toast.makeText(this, "Error opening file picker: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }
    
    private fun handleSelectedFile(uri: Uri) {
        try {
            val fileInfo = getFileInfo(uri)
            if (fileInfo != null) {
                // Validate file type and size
                if (!FileUtils.isValidFileType(fileInfo.mimeType)) {
                    Toast.makeText(this, "Unsupported file type: ${fileInfo.mimeType}", Toast.LENGTH_LONG).show()
                    return
                }
                
                // Check file size (limit to 100MB)
                val maxSize = 100 * 1024 * 1024 // 100MB
                if (fileInfo.size > maxSize) {
                    Toast.makeText(this, "File too large. Maximum size is 100MB", Toast.LENGTH_LONG).show()
                    return
                }
                
                val courseFile = CourseFile(
                    id = UUID.randomUUID().toString(),
                    name = fileInfo.name,
                    type = FileUtils.getFileTypeFromMimeType(fileInfo.mimeType),
                    uri = uri,
                    size = fileInfo.size,
                    mimeType = fileInfo.mimeType ?: "",
                    uploadStatus = UploadStatus.PENDING
                )
                
                addFile(courseFile)
                Toast.makeText(this, "File added: ${fileInfo.name}", Toast.LENGTH_SHORT).show()
            }
        } catch (e: Exception) {
            Log.e("FileHandler", "Error handling selected file", e)
            Toast.makeText(this, "Error processing file: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }
    
    private fun getFileInfo(uri: Uri): FileInfo? {
        return try {
            val contentResolver = contentResolver
            val cursor: Cursor? = contentResolver.query(uri, null, null, null, null)
            
            cursor?.use {
                if (it.moveToFirst()) {
                    val nameIndex = it.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    val sizeIndex = it.getColumnIndex(OpenableColumns.SIZE)
                    
                    val name = if (nameIndex >= 0) it.getString(nameIndex) else "Unknown"
                    val size = if (sizeIndex >= 0) it.getLong(sizeIndex) else 0L
                    val mimeType = contentResolver.getType(uri)
                    
                    FileInfo(name, size, mimeType)
                } else null
            }
        } catch (e: Exception) {
            Log.e("FileInfo", "Error getting file info", e)
            null
        }
    }
    
    private fun addFile(file: CourseFile) {
        courseFiles.add(file)
        filesAdapter.notifyItemInserted(courseFiles.size - 1)
        updateFilesVisibility()
    }
    
    private fun removeFile(file: CourseFile) {
        AlertDialog.Builder(this)
            .setTitle("Remove File")
            .setMessage("Are you sure you want to remove ${file.name}?")
            .setPositiveButton("Remove") { _, _ ->
                val position = courseFiles.indexOf(file)
                if (position != -1) {
                    courseFiles.removeAt(position)
                    filesAdapter.notifyItemRemoved(position)
                    updateFilesVisibility()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
    
    // Data class for file information
    private data class FileInfo(
        val name: String,
        val size: Long,
        val mimeType: String?
    )
    
    /**
     * Check and request necessary permissions for file access
     */
    private fun checkAndRequestPermissions(): Boolean {
        val permissionsNeeded = getRequiredPermissions()
        val permissionsToRequest = permissionsNeeded.filter { permission ->
            ContextCompat.checkSelfPermission(this, permission) != PackageManager.PERMISSION_GRANTED
        }
        
        return if (permissionsToRequest.isNotEmpty()) {
            // Show explanation if needed
            if (permissionsToRequest.any { ActivityCompat.shouldShowRequestPermissionRationale(this, it) }) {
                showPermissionExplanation(permissionsToRequest)
            } else {
                // Request permissions directly
                permissionLauncher.launch(permissionsToRequest.toTypedArray())
            }
            false
        } else {
            // All permissions already granted
            true
        }
    }
    
    /**
     * Get required permissions based on Android version
     */
    private fun getRequiredPermissions(): List<String> {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            // Android 13+ (API 33+) - Use granular media permissions
            listOf(
                Manifest.permission.READ_MEDIA_IMAGES,
                Manifest.permission.READ_MEDIA_VIDEO,
                Manifest.permission.READ_MEDIA_AUDIO
            )
        } else {
            // Android 12 and below - Use READ_EXTERNAL_STORAGE
            listOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
    }
    
    /**
     * Show explanation dialog for permissions
     */
    private fun showPermissionExplanation(permissions: List<String>) {
        val message = buildString {
            append("This app needs the following permissions to function properly:\\n\\n")
            if (permissions.contains(Manifest.permission.READ_EXTERNAL_STORAGE)) {
                append("• Storage Access: To read and upload course files\\n")
            }
            if (permissions.contains(Manifest.permission.READ_MEDIA_IMAGES)) {
                append("• Image Access: To upload course images and thumbnails\\n")
            }
            if (permissions.contains(Manifest.permission.READ_MEDIA_VIDEO)) {
                append("• Video Access: To upload course videos\\n")
            }
            if (permissions.contains(Manifest.permission.READ_MEDIA_AUDIO)) {
                append("• Audio Access: To upload course audio files\\n")
            }
            append("\\nPlease grant these permissions to continue.")
        }
        
        AlertDialog.Builder(this)
            .setTitle("Permissions Required")
            .setMessage(message)
            .setPositiveButton("Grant Permissions") { _, _ ->
                permissionLauncher.launch(permissions.toTypedArray())
            }
            .setNegativeButton("Cancel") { dialog, _ ->
                dialog.dismiss()
                Toast.makeText(this, "Permissions are required to select files", Toast.LENGTH_LONG).show()
            }
            .setCancelable(false)
            .show()
    }
    
    override fun onSupportNavigateUp(): Boolean {
        onBackPressedDispatcher.onBackPressed()
        return true
    }
}
