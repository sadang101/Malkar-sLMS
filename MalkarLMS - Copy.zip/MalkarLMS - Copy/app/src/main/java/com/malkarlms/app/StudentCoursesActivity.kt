package com.malkarlms.app

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query

class StudentCoursesActivity : AppCompatActivity() {
    
    private lateinit var toolbar: Toolbar
    private lateinit var recyclerViewCourses: RecyclerView
    private lateinit var tvEmptyState: TextView
    
    private lateinit var firestore: FirebaseFirestore
    private lateinit var auth: FirebaseAuth
    private lateinit var studentCoursesAdapter: StudentCoursesAdapter
    private val enrolledCourses = mutableListOf<StudentCourse>()
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        try {
            setContentView(R.layout.activity_student_courses)
            
            initFirebase()
            initViews()
            setupToolbar()
            setupRecyclerView()
            loadEnrolledCourses()
        } catch (e: Exception) {
            Log.e("StudentCourses", "Error in onCreate: ${e.message}", e)
            Toast.makeText(this, "Error loading courses: ${e.message}", Toast.LENGTH_LONG).show()
            finish()
        }
    }
    
    private fun initFirebase() {
        firestore = FirebaseFirestore.getInstance()
        auth = FirebaseAuth.getInstance()
    }
    
    private fun initViews() {
        toolbar = findViewById(R.id.toolbar)
        recyclerViewCourses = findViewById(R.id.recyclerViewCourses)
        tvEmptyState = findViewById(R.id.tvEmptyState)
    }
    
    private fun setupToolbar() {
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "My Courses"
    }
    
    private fun setupRecyclerView() {
        try {
            studentCoursesAdapter = StudentCoursesAdapter(enrolledCourses) { course ->
                onCourseClicked(course)
            }
            recyclerViewCourses.apply {
                layoutManager = LinearLayoutManager(this@StudentCoursesActivity)
                adapter = studentCoursesAdapter
            }
            Log.d("StudentCourses", "RecyclerView setup completed")
        } catch (e: Exception) {
            Log.e("StudentCourses", "Error setting up RecyclerView: ${e.message}", e)
            Toast.makeText(this, "Error setting up course list", Toast.LENGTH_SHORT).show()
        }
    }
    
    private fun loadEnrolledCourses() {
        val currentUser = auth.currentUser
        if (currentUser == null) {
            Log.w("StudentCourses", "User not logged in")
            Toast.makeText(this, "Please login first", Toast.LENGTH_SHORT).show()
            finish()
            return
        }
        
        Log.d("StudentCourses", "Loading enrolled courses for user: ${currentUser.uid}")
        
        // Load enrollments for this student
        firestore.collection("enrollments")
            .whereEqualTo("studentId", currentUser.uid)
            .orderBy("enrolledAt", Query.Direction.DESCENDING)
            .get()
            .addOnSuccessListener { enrollmentDocs ->
                enrolledCourses.clear()
                
                Log.d("StudentCourses", "Found ${enrollmentDocs.size()} enrollments")
                
                if (enrollmentDocs.isEmpty()) {
                    updateUI()
                    return@addOnSuccessListener
                }
                
                // For each enrollment, get the course details
                var processedCount = 0
                val totalEnrollments = enrollmentDocs.size()
                
                for (enrollmentDoc in enrollmentDocs) {
                    val enrollmentData = enrollmentDoc.data
                    val courseId = enrollmentData["courseId"] as? String
                    
                    if (courseId != null) {
                        // Get course details
                        firestore.collection("courses")
                            .document(courseId)
                            .get()
                            .addOnSuccessListener { courseDoc ->
                                processedCount++
                                
                                if (courseDoc.exists()) {
                                    val courseData = courseDoc.data
                                    val studentCourse = StudentCourse(
                                        id = courseDoc.id,
                                        title = courseData?.get("title") as? String ?: "Unknown Course",
                                        description = courseData?.get("description") as? String ?: "",
                                        instructor = courseData?.get("instructorName") as? String ?: "Unknown Instructor",
                                        duration = courseData?.get("duration") as? String ?: "",
                                        category = courseData?.get("category") as? String ?: "",
                                        difficulty = courseData?.get("difficulty") as? String ?: "Beginner",
                                        progress = (enrollmentData["progress"] as? Long)?.toInt() ?: 0,
                                        enrolledAt = enrollmentData["enrolledAt"] as? Long ?: System.currentTimeMillis(),
                                        lastAccessedAt = enrollmentData["lastAccessedAt"] as? Long ?: 0L,
                                        isCompleted = enrollmentData["isCompleted"] as? Boolean ?: false
                                    )
                                    enrolledCourses.add(studentCourse)
                                    
                                    Log.d("StudentCourses", "Added enrolled course: ${studentCourse.title}")
                                }
                                
                                // Update UI when all courses are processed
                                if (processedCount == totalEnrollments) {
                                    updateUI()
                                    studentCoursesAdapter.notifyDataSetChanged()
                                }
                            }
                            .addOnFailureListener { e ->
                                processedCount++
                                Log.e("StudentCourses", "Error loading course $courseId: ${e.message}", e)
                                
                                if (processedCount == totalEnrollments) {
                                    updateUI()
                                    studentCoursesAdapter.notifyDataSetChanged()
                                }
                            }
                    } else {
                        processedCount++
                        if (processedCount == totalEnrollments) {
                            updateUI()
                            studentCoursesAdapter.notifyDataSetChanged()
                        }
                    }
                }
            }
            .addOnFailureListener { e ->
                Log.e("StudentCourses", "Error loading enrollments: ${e.message}", e)
                Toast.makeText(this, "Error loading enrolled courses: ${e.message}", Toast.LENGTH_LONG).show()
                updateUI()
            }
    }
    
    private fun updateUI() {
        if (enrolledCourses.isEmpty()) {
            recyclerViewCourses.visibility = View.GONE
            tvEmptyState.visibility = View.VISIBLE
        } else {
            recyclerViewCourses.visibility = View.VISIBLE
            tvEmptyState.visibility = View.GONE
        }
    }
    
    private fun onCourseClicked(course: StudentCourse) {
        // For now, navigate to course details until CoursePlayerActivity is implemented
        val intent = Intent(this, CourseDetailsActivity::class.java)
        intent.putExtra("COURSE_ID", course.id.hashCode())
        intent.putExtra("COURSE_TITLE", course.title)
        intent.putExtra("COURSE_DESCRIPTION", course.description)
        intent.putExtra("COURSE_DURATION", course.duration)
        intent.putExtra("COURSE_PRICE", "Enrolled")
        startActivity(intent)
    }
    
    override fun onResume() {
        super.onResume()
        loadEnrolledCourses() // Refresh when returning to this activity
    }
    
    override fun onSupportNavigateUp(): Boolean {
        onBackPressedDispatcher.onBackPressed()
        return true
    }
}

// Data class for student enrolled course
data class StudentCourse(
    val id: String,
    val title: String,
    val description: String,
    val instructor: String,
    val duration: String,
    val category: String,
    val difficulty: String,
    val progress: Int, // Progress percentage (0-100)
    val enrolledAt: Long,
    val lastAccessedAt: Long,
    val isCompleted: Boolean
)
