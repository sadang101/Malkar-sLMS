package com.malkarlms.app

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class CourseDetailsActivity : AppCompatActivity() {
    
    private lateinit var tvCourseTitle: TextView
    private lateinit var tvCourseDescription: TextView
    private lateinit var tvCourseDuration: TextView
    private lateinit var tvCourseLevel: TextView
    private lateinit var tvCoursePrice: TextView
    private lateinit var tvDetailedDescription: TextView
    private lateinit var tvInstructor: TextView
    private lateinit var tvRating: TextView
    private lateinit var tvStudents: TextView
    private lateinit var btnAddToCart: Button
    private lateinit var btnBuyNow: Button
    private lateinit var recyclerViewRecommended: RecyclerView
    
    private lateinit var auth: FirebaseAuth
    private lateinit var firestore: FirebaseFirestore
    private var isInstructor = false
    private var courseDocumentId: String? = null
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_course_details)
        
        // Initialize Firebase
        auth = FirebaseAuth.getInstance()
        firestore = FirebaseFirestore.getInstance()
        
        setupToolbar()
        initViews()
        checkIfInstructor()
        loadCourseData()
        setupClickListeners()
        setupRecommendations()
    }
    
    private fun setupToolbar() {
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "Course Details"
    }
    
    private fun initViews() {
        tvCourseTitle = findViewById(R.id.tvCourseTitle)
        tvCourseDescription = findViewById(R.id.tvCourseDescription)
        tvCourseDuration = findViewById(R.id.tvCourseDuration)
        tvCourseLevel = findViewById(R.id.tvCourseLevel)
        tvCoursePrice = findViewById(R.id.tvCoursePrice)
        tvDetailedDescription = findViewById(R.id.tvDetailedDescription)
        tvInstructor = findViewById(R.id.tvInstructor)
        tvRating = findViewById(R.id.tvRating)
        tvStudents = findViewById(R.id.tvStudents)
        btnAddToCart = findViewById(R.id.btnAddToCart)
        btnBuyNow = findViewById(R.id.btnBuyNow)
        recyclerViewRecommended = findViewById(R.id.recyclerViewRecommended)
    }
    
    private fun checkIfInstructor() {
        val currentUser = auth.currentUser
        val courseId = intent.getIntExtra("COURSE_ID", 0)
        
        if (currentUser == null || courseId == 0) {
            setupStudentButtons()
            return
        }
        
        // Query Firebase to check if this user is the instructor
        firestore.collection("courses")
            .whereEqualTo("instructorId", currentUser.uid)
            .get()
            .addOnSuccessListener { documents ->
                for (document in documents) {
                    val docCourseId = document.id.hashCode()
                    if (docCourseId == courseId) {
                        isInstructor = true
                        courseDocumentId = document.id
                        setupInstructorButtons()
                        return@addOnSuccessListener
                    }
                }
                // If not found, user is a student - check enrollment status
                checkEnrollmentStatus()
            }
            .addOnFailureListener { e ->
                Log.e("CourseDetails", "Error checking instructor status: ${e.message}", e)
                setupStudentButtons() // Default to student view
            }
    }
    
    private fun checkEnrollmentStatus() {
        val currentUser = auth.currentUser
        if (currentUser == null) {
            setupStudentButtons()
            return
        }
        
        val courseId = intent.getIntExtra("COURSE_ID", 0).toString()
        
        // Check if user is already enrolled
        firestore.collection("enrollments")
            .whereEqualTo("studentId", currentUser.uid)
            .whereEqualTo("courseId", courseId)
            .get()
            .addOnSuccessListener { documents ->
                if (!documents.isEmpty) {
                    // User is enrolled - show enrolled state
                    setupEnrolledButtons()
                } else {
                    // User is not enrolled - show normal buttons
                    setupStudentButtons()
                }
            }
            .addOnFailureListener { e ->
                Log.e("CourseDetails", "Error checking enrollment: ${e.message}", e)
                setupStudentButtons()
            }
    }
    
    private fun setupEnrolledButtons() {
        // Show that user is already enrolled
        btnAddToCart.text = "Enrolled"
        btnAddToCart.isEnabled = false
        btnAddToCart.backgroundTintList = android.content.res.ColorStateList.valueOf(
            android.graphics.Color.parseColor("#4CAF50")
        )
        
        btnBuyNow.text = "Continue Learning"
        btnBuyNow.isEnabled = true
        btnBuyNow.backgroundTintList = android.content.res.ColorStateList.valueOf(
            getColor(R.color.primary)
        )
    }
    
    private fun setupInstructorButtons() {
        // Change buttons for instructor
        btnAddToCart.text = "Edit Course"
        btnBuyNow.text = "Manage Course"
        
        // Update button colors
        btnAddToCart.backgroundTintList = android.content.res.ColorStateList.valueOf(
            getColor(R.color.secondary)
        )
        btnBuyNow.backgroundTintList = android.content.res.ColorStateList.valueOf(
            getColor(R.color.primary)
        )
    }
    
    private fun setupStudentButtons() {
        // Keep original student buttons
        btnAddToCart.text = "Add to Cart"
        btnBuyNow.text = "Buy Now"
        
        // Update add to cart button based on cart status
        val courseId = intent.getIntExtra("COURSE_ID", 0)
        updateAddToCartButton(courseId)
    }
    
    private fun loadCourseData() {
        val courseTitle = intent.getStringExtra("COURSE_TITLE") ?: "Course"
        val courseDescription = intent.getStringExtra("COURSE_DESCRIPTION") ?: ""
        val courseDuration = intent.getStringExtra("COURSE_DURATION") ?: ""
        val coursePrice = intent.getStringExtra("COURSE_PRICE") ?: ""
        val instructor = intent.getStringExtra("COURSE_INSTRUCTOR") ?: "Expert Instructor"
        val rating = intent.getFloatExtra("COURSE_RATING", 4.5f)
        val students = intent.getIntExtra("COURSE_STUDENTS", 0)
        
        tvCourseTitle.text = courseTitle
        tvCourseDescription.text = courseDescription
        tvCourseDuration.text = courseDuration
        tvCourseLevel.text = intent.getStringExtra("COURSE_LEVEL") ?: "Beginner"
        tvCoursePrice.text = coursePrice
        tvInstructor.text = instructor
        tvRating.text = rating.toString()
        tvStudents.text = "${formatNumber(students)} students"
        
        // Set detailed description based on course
        tvDetailedDescription.text = getDetailedDescription(courseTitle)
        
        // Update add to cart button based on cart status
        val courseId = intent.getIntExtra("COURSE_ID", 0)
        updateAddToCartButton(courseId)
    }
    
    private fun formatNumber(num: Int): String {
        return when {
            num >= 1000 -> String.format("%.1fk", num / 1000.0).replace(".0k", "k")
            else -> num.toString()
        }
    }
    
    private fun getDetailedDescription(courseTitle: String): String {
        return when (courseTitle) {
            "Digital Marketing" -> """
                📈 Master Digital Marketing Strategies
                
                What you'll learn:
                • Social Media Marketing (Facebook, Instagram, LinkedIn)
                • Google Ads & Search Engine Marketing
                • Email Marketing Campaigns
                • Content Marketing & SEO
                • Analytics & Performance Tracking
                • Influencer Marketing
                
                Course Includes:
                ✓ 50+ Video Lessons
                ✓ Real-world Projects
                ✓ Certificate of Completion
                ✓ Lifetime Access
                ✓ 24/7 Support
                
                Perfect for beginners and professionals looking to enhance their digital marketing skills.
            """.trimIndent()
            
            "MBA Essentials" -> """
                🎓 Complete MBA Foundation Course
                
                What you'll learn:
                • Business Strategy & Planning
                • Financial Management & Analysis
                • Marketing Management
                • Operations & Supply Chain
                • Leadership & Team Management
                • Project Management
                
                Course Includes:
                ✓ 80+ Comprehensive Modules
                ✓ Case Studies from Top Companies
                ✓ MBA Certificate
                ✓ Career Guidance
                ✓ Industry Expert Sessions
                
                Designed for aspiring managers and business leaders.
            """.trimIndent()
            
            "Web Development" -> """
                💻 Full-Stack Web Development
                
                What you'll learn:
                • HTML5, CSS3, JavaScript
                • React.js & Node.js
                • Database Management (MongoDB, MySQL)
                • API Development & Integration
                • Responsive Web Design
                • Deployment & Hosting
                
                Course Includes:
                ✓ 100+ Coding Exercises
                ✓ 5 Real Projects
                ✓ Developer Certificate
                ✓ Job Placement Assistance
                ✓ Code Review Sessions
                
                From beginner to job-ready web developer.
            """.trimIndent()
            
            "Data Science" -> """
                📊 Complete Data Science Program
                
                What you'll learn:
                • Python Programming for Data Science
                • Statistics & Probability
                • Machine Learning Algorithms
                • Data Visualization (Matplotlib, Seaborn)
                • SQL & Database Management
                • Big Data & Analytics
                
                Course Includes:
                ✓ 120+ Hours of Content
                ✓ Real Data Projects
                ✓ Industry Certification
                ✓ Jupyter Notebooks
                ✓ Mentorship Program
                
                Transform your career with data science skills.
            """.trimIndent()
            
            "Graphic Design" -> """
                🎨 Professional Graphic Design Course
                
                What you'll learn:
                • Adobe Photoshop, Illustrator, InDesign
                • Logo Design & Branding
                • Print & Digital Design
                • Typography & Color Theory
                • UI/UX Design Basics
                • Portfolio Development
                
                Course Includes:
                ✓ 60+ Design Projects
                ✓ Adobe Software Access
                ✓ Design Certificate
                ✓ Portfolio Review
                ✓ Freelancing Guidance
                
                Create stunning designs for any medium.
            """.trimIndent()
            
            else -> "Comprehensive course covering all essential topics with hands-on projects and expert guidance."
        }
    }
    
    private fun setupClickListeners() {
        btnAddToCart.setOnClickListener {
            if (isInstructor) {
                // Edit Course functionality
                editCourse()
            } else {
                // Student: Add to Cart
                val course = Course(
                    id = intent.getIntExtra("COURSE_ID", 0),
                    title = intent.getStringExtra("COURSE_TITLE") ?: "Course",
                    description = intent.getStringExtra("COURSE_DESCRIPTION") ?: "",
                    duration = intent.getStringExtra("COURSE_DURATION") ?: "",
                    price = intent.getStringExtra("COURSE_PRICE") ?: ""
                )
                
                if (CartManager.isInCart(course.id)) {
                    Toast.makeText(this, "${course.title} is already in cart!", Toast.LENGTH_SHORT).show()
                } else {
                    CartManager.addToCart(course)
                    Toast.makeText(this, "${course.title} added to cart!", Toast.LENGTH_SHORT).show()
                    updateAddToCartButton(course.id)
                }
            }
        }
        
        btnBuyNow.setOnClickListener {
            if (isInstructor) {
                // Manage Course functionality
                manageCourse()
            } else if (btnBuyNow.text == "Continue Learning") {
                // User is already enrolled - navigate to course learning page
                val courseId = intent.getIntExtra("COURSE_ID", 0)
                val courseTitle = intent.getStringExtra("COURSE_TITLE") ?: "Course"
                val learningIntent = Intent(this, CourseLearningActivity::class.java)
                learningIntent.putExtra("COURSE_ID", courseId)
                learningIntent.putExtra("COURSE_TITLE", courseTitle)
                startActivity(learningIntent)
            } else {
                // Student: Navigate to Checkout
                navigateToCheckout()
            }
        }
    }
    
    private fun updateAddToCartButton(courseId: Int) {
        if (CartManager.isInCart(courseId)) {
            btnAddToCart.text = "Already in Cart"
            btnAddToCart.isEnabled = false
            btnAddToCart.backgroundTintList = android.content.res.ColorStateList.valueOf(
                android.graphics.Color.GRAY
            )
        } else {
            btnAddToCart.text = "Add to Cart"
            btnAddToCart.isEnabled = true
            btnAddToCart.backgroundTintList = android.content.res.ColorStateList.valueOf(
                android.graphics.Color.parseColor("#FF6200EE")
            )
        }
    }
    
    private fun setupRecommendations() {
        val currentCourseId = intent.getIntExtra("COURSE_ID", 0)
        val allCourses = getAllCourses()
        val recommendedCourses = allCourses.filter { it.id != currentCourseId }.take(3)
        
        val recommendationAdapter = CourseAdapter(recommendedCourses) { course ->
            val intent = Intent(this, CourseDetailsActivity::class.java)
            intent.putExtra("COURSE_ID", course.id)
            intent.putExtra("COURSE_TITLE", course.title)
            intent.putExtra("COURSE_DESCRIPTION", course.description)
            intent.putExtra("COURSE_DURATION", course.duration)
            intent.putExtra("COURSE_PRICE", course.price)
            startActivity(intent)
        }
        
        recyclerViewRecommended.apply {
            layoutManager = LinearLayoutManager(this@CourseDetailsActivity, LinearLayoutManager.HORIZONTAL, false)
            adapter = recommendationAdapter
        }
    }
    
    private fun getAllCourses(): List<Course> {
        return listOf(
            Course(1, "Digital Marketing", "Learn modern digital marketing strategies", "8 weeks", "₹1000"),
            Course(2, "MBA Essentials", "Master business administration fundamentals", "12 weeks", "₹1500"),
            Course(3, "Web Development", "Full-stack web development", "16 weeks", "₹1200"),
            Course(4, "Data Science", "Analytics and machine learning", "20 weeks", "₹1500"),
            Course(5, "Graphic Design", "Creative design principles", "10 weeks", "₹1000")
        )
    }
    
    private fun navigateToCheckout() {
        val intent = Intent(this, CheckoutActivity::class.java)
        intent.putExtra("IS_SINGLE_COURSE", true)
        intent.putExtra("COURSE_ID", getIntent().getIntExtra("COURSE_ID", 0))
        intent.putExtra("COURSE_TITLE", getIntent().getStringExtra("COURSE_TITLE"))
        intent.putExtra("COURSE_DESCRIPTION", getIntent().getStringExtra("COURSE_DESCRIPTION"))
        intent.putExtra("COURSE_DURATION", getIntent().getStringExtra("COURSE_DURATION"))
        intent.putExtra("COURSE_PRICE", getIntent().getStringExtra("COURSE_PRICE"))
        intent.putExtra("COURSE_INSTRUCTOR", getIntent().getStringExtra("COURSE_INSTRUCTOR"))
        intent.putExtra("COURSE_RATING", getIntent().getFloatExtra("COURSE_RATING", 4.5f))
        intent.putExtra("COURSE_STUDENTS", getIntent().getIntExtra("COURSE_STUDENTS", 0))
        intent.putExtra("COURSE_LEVEL", getIntent().getStringExtra("COURSE_LEVEL"))
        intent.putExtra("COURSE_CATEGORY", getIntent().getStringExtra("COURSE_CATEGORY"))
        intent.putExtra("COURSE_LANGUAGE", getIntent().getStringExtra("COURSE_LANGUAGE"))
        intent.putExtra("COURSE_MODULES", getIntent().getIntExtra("COURSE_MODULES", 0))
        intent.putExtra("COURSE_LECTURES", getIntent().getIntExtra("COURSE_LECTURES", 0))
        intent.putExtra("COURSE_CERTIFICATE", getIntent().getBooleanExtra("COURSE_CERTIFICATE", true))
        intent.putExtra("COURSE_PREREQUISITES", getIntent().getStringExtra("COURSE_PREREQUISITES"))
        intent.putStringArrayListExtra("COURSE_OUTCOMES", getIntent().getStringArrayListExtra("COURSE_OUTCOMES"))
        startActivity(intent)
    }
    
    // Removed enrollInCourse() - Now using CheckoutActivity for enrollment
    
    private fun editCourse() {
        if (courseDocumentId == null) {
            Toast.makeText(this, "Course information not available", Toast.LENGTH_SHORT).show()
            return
        }
        
        // Navigate to course creation activity in edit mode
        val intent = Intent(this, CourseCreationActivity::class.java)
        intent.putExtra("EDIT_MODE", true)
        intent.putExtra("COURSE_DOCUMENT_ID", courseDocumentId)
        intent.putExtra("COURSE_TITLE", intent.getStringExtra("COURSE_TITLE"))
        intent.putExtra("COURSE_DESCRIPTION", intent.getStringExtra("COURSE_DESCRIPTION"))
        intent.putExtra("COURSE_DURATION", intent.getStringExtra("COURSE_DURATION"))
        intent.putExtra("COURSE_PRICE", intent.getStringExtra("COURSE_PRICE"))
        startActivity(intent)
    }
    
    private fun manageCourse() {
        if (courseDocumentId == null) {
            Toast.makeText(this, "Course information not available", Toast.LENGTH_SHORT).show()
            return
        }
        
        // Show course management options
        val options = arrayOf(
            "View Course Analytics",
            "Manage Students",
            "Update Course Content",
            "Course Settings"
        )
        
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("Manage Course")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> showCourseAnalytics()
                    1 -> showEnrolledStudents()
                    2 -> updateCourseContent()
                    3 -> showCourseSettings()
                }
            }
            .show()
    }
    
    private fun showCourseAnalytics() {
        // Navigate to analytics for this specific course
        val intent = Intent(this, AnalyticsActivity::class.java)
        intent.putExtra("COURSE_ID", courseDocumentId)
        intent.putExtra("COURSE_TITLE", intent.getStringExtra("COURSE_TITLE"))
        startActivity(intent)
    }
    
    private fun showEnrolledStudents() {
        // Show enrolled students for this course
        firestore.collection("enrollments")
            .whereEqualTo("courseId", courseDocumentId)
            .get()
            .addOnSuccessListener { documents ->
                val studentCount = documents.size()
                Toast.makeText(this, "Total enrolled students: $studentCount", Toast.LENGTH_LONG).show()
                
                // TODO: Create a proper student management activity
                if (studentCount > 0) {
                    val studentInfo = StringBuilder("Enrolled Students:\n\n")
                    for (document in documents) {
                        val enrollmentData = document.data
                        val enrolledAt = enrollmentData["enrolledAt"] as? Long ?: 0L
                        val progress = enrollmentData["progress"] as? Long ?: 0L
                        studentInfo.append("Student ID: ${enrollmentData["studentId"]}\n")
                        studentInfo.append("Progress: ${progress}%\n")
                        studentInfo.append("Enrolled: ${java.text.SimpleDateFormat("MMM dd, yyyy", java.util.Locale.getDefault()).format(java.util.Date(enrolledAt))}\n\n")
                    }
                    
                    androidx.appcompat.app.AlertDialog.Builder(this)
                        .setTitle("Enrolled Students")
                        .setMessage(studentInfo.toString())
                        .setPositiveButton("OK", null)
                        .show()
                }
            }
            .addOnFailureListener { e ->
                Toast.makeText(this, "Error loading student data: ${e.message}", Toast.LENGTH_LONG).show()
            }
    }
    
    private fun updateCourseContent() {
        Toast.makeText(this, "Course content management coming soon!", Toast.LENGTH_SHORT).show()
        // TODO: Implement course content management (videos, documents, etc.)
    }
    
    private fun showCourseSettings() {
        val options = arrayOf(
            "Publish/Unpublish Course",
            "Change Course Price",
            "Delete Course"
        )
        
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("Course Settings")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> toggleCoursePublication()
                    1 -> changeCoursePrice()
                    2 -> deleteCourse()
                }
            }
            .show()
    }
    
    private fun toggleCoursePublication() {
        // TODO: Implement publish/unpublish functionality
        Toast.makeText(this, "Publication toggle coming soon!", Toast.LENGTH_SHORT).show()
    }
    
    private fun changeCoursePrice() {
        // TODO: Implement price change functionality
        Toast.makeText(this, "Price change coming soon!", Toast.LENGTH_SHORT).show()
    }
    
    private fun deleteCourse() {
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("Delete Course")
            .setMessage("Are you sure you want to delete this course? This action cannot be undone.")
            .setPositiveButton("Delete") { _, _ ->
                // TODO: Implement course deletion
                Toast.makeText(this, "Course deletion coming soon!", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
    
    override fun onSupportNavigateUp(): Boolean {
        onBackPressedDispatcher.onBackPressed()
        return true
    }
}
