package com.malkarlms.app

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.recyclerview.widget.RecyclerView

/**
 * Adapter for displaying course files in RecyclerView
 */
class CourseFilesAdapter(
    private val files: MutableList<CourseFile>,
    private val onFileRemove: (CourseFile) -> Unit
) : RecyclerView.Adapter<CourseFilesAdapter.FileViewHolder>() {

    class FileViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvFileName: TextView = itemView.findViewById(R.id.tvFileName)
        val tvFileSize: TextView = itemView.findViewById(R.id.tvFileSize)
        val tvFileType: TextView = itemView.findViewById(R.id.tvFileType)
        val progressBar: ProgressBar = itemView.findViewById(R.id.progressBar)
        val tvUploadStatus: TextView = itemView.findViewById(R.id.tvUploadStatus)
        val btnRemove: ImageButton = itemView.findViewById(R.id.btnRemove)
        val layoutFileItem: LinearLayout = itemView.findViewById(R.id.layoutFileItem)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FileViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_course_file, parent, false)
        return FileViewHolder(view)
    }

    override fun onBindViewHolder(holder: FileViewHolder, position: Int) {
        val file = files[position]
        
        holder.tvFileName.text = file.name
        holder.tvFileSize.text = FileUtils.formatFileSize(file.size)
        holder.tvFileType.text = "${file.type.icon} ${file.type.displayName}"
        
        // Handle upload status
        when (file.uploadStatus) {
            UploadStatus.PENDING -> {
                holder.progressBar.visibility = View.GONE
                holder.tvUploadStatus.text = "Ready to upload"
                holder.tvUploadStatus.setTextColor(holder.itemView.context.getColor(android.R.color.darker_gray))
            }
            UploadStatus.UPLOADING -> {
                holder.progressBar.visibility = View.VISIBLE
                holder.progressBar.progress = file.uploadProgress
                holder.tvUploadStatus.text = "Uploading... ${file.uploadProgress}%"
                holder.tvUploadStatus.setTextColor(holder.itemView.context.getColor(R.color.primary))
            }
            UploadStatus.COMPLETED -> {
                holder.progressBar.visibility = View.GONE
                holder.tvUploadStatus.text = "✅ Uploaded"
                holder.tvUploadStatus.setTextColor(holder.itemView.context.getColor(android.R.color.holo_green_dark))
            }
            UploadStatus.FAILED -> {
                holder.progressBar.visibility = View.GONE
                holder.tvUploadStatus.text = "❌ Failed"
                holder.tvUploadStatus.setTextColor(holder.itemView.context.getColor(android.R.color.holo_red_dark))
            }
        }
        
        // Remove button click
        holder.btnRemove.setOnClickListener {
            onFileRemove(file)
        }
        
        // Set background based on file type
        val backgroundColor = when (file.type) {
            FileType.VIDEO -> R.color.primary_light
            FileType.IMAGE -> R.color.secondary_light
            FileType.DOCUMENT -> R.color.accent_light
            FileType.AUDIO -> R.color.success_light
            FileType.OTHER -> android.R.color.background_light
        }
        
        holder.layoutFileItem.setBackgroundResource(backgroundColor)
    }

    override fun getItemCount(): Int = files.size

    fun addFile(file: CourseFile) {
        files.add(file)
        notifyItemInserted(files.size - 1)
    }

    fun removeFile(file: CourseFile) {
        val position = files.indexOf(file)
        if (position != -1) {
            files.removeAt(position)
            notifyItemRemoved(position)
        }
    }

    fun updateFileStatus(fileId: String, status: UploadStatus, progress: Int = 0) {
        val position = files.indexOfFirst { it.id == fileId }
        if (position != -1) {
            files[position] = files[position].copy(
                uploadStatus = status,
                uploadProgress = progress
            )
            notifyItemChanged(position)
        }
    }

    fun getFiles(): List<CourseFile> = files.toList()
}
