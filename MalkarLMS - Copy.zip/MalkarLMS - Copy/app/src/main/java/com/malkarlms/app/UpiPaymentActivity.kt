package com.malkarlms.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView

class UpiPaymentActivity : AppCompatActivity() {

    private lateinit var tvPaymentAmount: TextView
    private lateinit var cardGooglePay: CardView
    private lateinit var cardPhonePe: CardView
    private lateinit var cardPaytm: CardView
    private lateinit var cardBHIM: CardView
    private lateinit var cardManualUPI: CardView

    private var amount: String = "0"
    private var upiId: String = "merchant@upi" // Replace with your actual UPI ID

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_upi_payment)

        setupToolbar()
        initViews()
        loadData()
        setupClickListeners()
    }

    private fun setupToolbar() {
        val toolbar = findViewById<androidx.appcompat.widget.Toolbar>(R.id.toolbar)
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "UPI Payment"
        toolbar.setNavigationOnClickListener {
            onBackPressedDispatcher.onBackPressed()
        }
    }

    private fun initViews() {
        tvPaymentAmount = findViewById(R.id.tvPaymentAmount)
        cardGooglePay = findViewById(R.id.cardGooglePay)
        cardPhonePe = findViewById(R.id.cardPhonePe)
        cardPaytm = findViewById(R.id.cardPaytm)
        cardBHIM = findViewById(R.id.cardBHIM)
        cardManualUPI = findViewById(R.id.cardManualUPI)
    }

    private fun loadData() {
        amount = intent.getStringExtra("AMOUNT") ?: "0"
        tvPaymentAmount.text = amount
    }

    private fun setupClickListeners() {
        cardGooglePay.setOnClickListener {
            openUPIApp("com.google.android.apps.nbu.paisa.user", "Google Pay")
        }

        cardPhonePe.setOnClickListener {
            openUPIApp("com.phonepe.app", "PhonePe")
        }

        cardPaytm.setOnClickListener {
            openUPIApp("net.one97.paytm", "Paytm")
        }

        cardBHIM.setOnClickListener {
            openUPIApp("in.org.npci.upiapp", "BHIM")
        }

        cardManualUPI.setOnClickListener {
            openGenericUPI()
        }
    }

    private fun openUPIApp(packageName: String, appName: String) {
        try {
            // Extract numeric amount from string (remove ₹ and commas)
            val numericAmount = amount.replace("₹", "").replace(",", "").trim()

            // Create UPI payment URI
            val upiUri = Uri.parse("upi://pay").buildUpon()
                .appendQueryParameter("pa", upiId) // Payee address (UPI ID)
                .appendQueryParameter("pn", "MalkarLMS") // Payee name
                .appendQueryParameter("am", numericAmount) // Amount
                .appendQueryParameter("cu", "INR") // Currency
                .appendQueryParameter("tn", "Course Enrollment Payment") // Transaction note
                .build()

            val intent = Intent(Intent.ACTION_VIEW)
            intent.data = upiUri
            intent.setPackage(packageName)

            // Check if the app is installed
            if (intent.resolveActivity(packageManager) != null) {
                Toast.makeText(this, "Opening $appName...", Toast.LENGTH_SHORT).show()
                startActivityForResult(intent, UPI_PAYMENT_REQUEST_CODE)
            } else {
                Toast.makeText(this, "$appName is not installed", Toast.LENGTH_LONG).show()
                // Fallback: Try to open in Play Store
                openPlayStore(packageName)
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Error: ${e.message}", Toast.LENGTH_LONG).show()
            e.printStackTrace()
        }
    }

    private fun openGenericUPI() {
        try {
            // Extract numeric amount
            val numericAmount = amount.replace("₹", "").replace(",", "").trim()

            // Create UPI payment URI
            val upiUri = Uri.parse("upi://pay").buildUpon()
                .appendQueryParameter("pa", upiId)
                .appendQueryParameter("pn", "MalkarLMS")
                .appendQueryParameter("am", numericAmount)
                .appendQueryParameter("cu", "INR")
                .appendQueryParameter("tn", "Course Enrollment Payment")
                .build()

            val intent = Intent(Intent.ACTION_VIEW)
            intent.data = upiUri

            // This will show a chooser with all UPI apps
            val chooser = Intent.createChooser(intent, "Pay with")
            
            if (chooser.resolveActivity(packageManager) != null) {
                Toast.makeText(this, "Select your UPI app...", Toast.LENGTH_SHORT).show()
                startActivityForResult(chooser, UPI_PAYMENT_REQUEST_CODE)
            } else {
                Toast.makeText(this, "No UPI app found", Toast.LENGTH_LONG).show()
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Error: ${e.message}", Toast.LENGTH_LONG).show()
            e.printStackTrace()
        }
    }

    private fun openPlayStore(packageName: String) {
        try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$packageName"))
            startActivity(intent)
        } catch (e: Exception) {
            // If Play Store app is not installed, open in browser
            val intent = Intent(Intent.ACTION_VIEW, 
                Uri.parse("https://play.google.com/store/apps/details?id=$packageName"))
            startActivity(intent)
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == UPI_PAYMENT_REQUEST_CODE) {
            if (data != null) {
                val response = data.getStringExtra("response")
                handleUPIResponse(response)
            } else {
                Toast.makeText(this, "Transaction cancelled", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun handleUPIResponse(response: String?) {
        if (response == null) {
            Toast.makeText(this, "No response from UPI app", Toast.LENGTH_SHORT).show()
            return
        }

        // Parse UPI response
        val responseMap = parseUPIResponse(response)
        val status = responseMap["Status"]?.lowercase()

        when (status) {
            "success" -> {
                // Payment successful
                val txnId = responseMap["txnId"]
                Toast.makeText(this, "Payment Successful! TxnID: $txnId", Toast.LENGTH_LONG).show()
                
                // Return success to CheckoutActivity
                val resultIntent = Intent()
                resultIntent.putExtra("PAYMENT_STATUS", "SUCCESS")
                resultIntent.putExtra("TRANSACTION_ID", txnId)
                resultIntent.putExtra("PAYMENT_METHOD", "UPI")
                setResult(RESULT_OK, resultIntent)
                finish()
            }
            "failure" -> {
                Toast.makeText(this, "Payment Failed!", Toast.LENGTH_LONG).show()
            }
            "submitted" -> {
                Toast.makeText(this, "Payment Pending...", Toast.LENGTH_LONG).show()
            }
            else -> {
                Toast.makeText(this, "Payment status: $status", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun parseUPIResponse(response: String): Map<String, String> {
        val map = mutableMapOf<String, String>()
        try {
            val pairs = response.split("&")
            for (pair in pairs) {
                val keyValue = pair.split("=")
                if (keyValue.size >= 2) {
                    map[keyValue[0]] = keyValue[1]
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return map
    }

    companion object {
        private const val UPI_PAYMENT_REQUEST_CODE = 2001
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressedDispatcher.onBackPressed()
        return true
    }
}
