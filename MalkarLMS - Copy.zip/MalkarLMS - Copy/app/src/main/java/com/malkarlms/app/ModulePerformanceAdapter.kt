package com.malkarlms.app

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class ModulePerformanceAdapter(
    private var modules: List<DifficultyStats>
) : RecyclerView.Adapter<ModulePerformanceAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvModuleName: TextView = view.findViewById(R.id.tvModuleName)
        val tvDifficultyBadge: TextView = view.findViewById(R.id.tvDifficultyBadge)
        val tvCompletionRate: TextView = view.findViewById(R.id.tvCompletionRate)
        val tvAverageScore: TextView = view.findViewById(R.id.tvAverageScore)
        val tvStudentCount: TextView = view.findViewById(R.id.tvStudentCount)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_module_performance, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val module = modules[position]
        
        holder.tvModuleName.text = module.moduleName
        holder.tvDifficultyBadge.text = module.difficulty
        holder.tvCompletionRate.text = "${module.completionRate.toInt()}%"
        holder.tvAverageScore.text = "${module.averageScore.toInt()}%"
        holder.tvStudentCount.text = module.studentCount.toString()
        
        // Set badge background based on difficulty
        val badgeBackground = when (module.difficulty.lowercase()) {
            "easy" -> R.drawable.badge_easy
            "hard" -> R.drawable.badge_hard
            else -> R.drawable.badge_medium
        }
        holder.tvDifficultyBadge.setBackgroundResource(badgeBackground)
    }

    override fun getItemCount() = modules.size

    fun updateData(newModules: List<DifficultyStats>) {
        modules = newModules
        notifyDataSetChanged()
    }
}
