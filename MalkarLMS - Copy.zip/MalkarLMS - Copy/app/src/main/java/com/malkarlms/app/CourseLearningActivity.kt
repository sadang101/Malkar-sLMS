package com.malkarlms.app

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView

class CourseLearningActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_course_learning)

        setupToolbar()
        setupClickListeners()
    }

    private fun setupToolbar() {
        val toolbar = findViewById<androidx.appcompat.widget.Toolbar>(R.id.toolbar)
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "Complete Python Programming"
        toolbar.setNavigationOnClickListener {
            onBackPressedDispatcher.onBackPressed()
        }
    }

    private fun setupClickListeners() {
        // Module 1 - Completed
        findViewById<CardView>(R.id.cardModule1).setOnClickListener {
            Toast.makeText(this, "Opening Module 1: Python Basics", Toast.LENGTH_SHORT).show()
            // In real app, navigate to module content
        }

        // Module 2 - In Progress
        findViewById<CardView>(R.id.cardModule2).setOnClickListener {
            Toast.makeText(this, "Opening Module 2: Data Structures", Toast.LENGTH_SHORT).show()
            // In real app, navigate to module content
        }

        // Module 3 - Locked
        findViewById<CardView>(R.id.cardModule3).setOnClickListener {
            Toast.makeText(this, "Complete Module 2 to unlock this module", Toast.LENGTH_SHORT).show()
        }

        // Module 4 - Locked
        findViewById<CardView>(R.id.cardModule4).setOnClickListener {
            Toast.makeText(this, "Complete Module 3 to unlock this module", Toast.LENGTH_SHORT).show()
        }

        // Assignment 1 - Submitted
        findViewById<CardView>(R.id.cardAssignment1).setOnClickListener {
            Toast.makeText(this, "Viewing submitted assignment", Toast.LENGTH_SHORT).show()
            // In real app, show assignment details and submission
        }

        // Assignment 2 - Pending
        findViewById<CardView>(R.id.cardAssignment2).setOnClickListener {
            Toast.makeText(this, "Opening assignment submission page", Toast.LENGTH_SHORT).show()
            // In real app, navigate to assignment submission
        }

        // Test 1 - Completed
        findViewById<CardView>(R.id.cardTest1).setOnClickListener {
            Toast.makeText(this, "Viewing quiz results: 85%", Toast.LENGTH_SHORT).show()
            // In real app, show quiz results
        }

        // Test 2 - Available
        findViewById<CardView>(R.id.cardTest2).setOnClickListener {
            Toast.makeText(this, "Starting Module 2 Quiz", Toast.LENGTH_SHORT).show()
            // In real app, start quiz
        }

        // Project 1 - In Progress
        findViewById<CardView>(R.id.cardProject1).setOnClickListener {
            Toast.makeText(this, "Opening Todo App Project", Toast.LENGTH_SHORT).show()
            // In real app, navigate to project workspace
        }

        // Project 2 - Locked
        findViewById<CardView>(R.id.cardProject2).setOnClickListener {
            Toast.makeText(this, "Complete previous modules to unlock", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressedDispatcher.onBackPressed()
        return true
    }
}
