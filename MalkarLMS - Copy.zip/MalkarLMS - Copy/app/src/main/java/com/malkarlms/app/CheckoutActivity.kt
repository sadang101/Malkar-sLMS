package com.malkarlms.app

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class CheckoutActivity : AppCompatActivity() {

    private lateinit var coursesContainer: LinearLayout
    private lateinit var tvSubtotal: TextView
    private lateinit var tvPlatformFee: TextView
    private lateinit var tvGst: TextView
    private lateinit var tvTotal: TextView
    private lateinit var btnProceedPayment: Button
    private lateinit var cbTerms: CheckBox

    private val courses = mutableListOf<Course>()
    private var subtotal = 0.0
    private var platformFee = 7.0
    private var gst = 0.0
    private var total = 0.0
    
    private val paymentMethodLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            val paymentMethod = result.data?.getStringExtra("PAYMENT_METHOD") ?: "UPI"
            val paymentType = result.data?.getStringExtra("PAYMENT_TYPE") ?: "upi"
            
            // Process payment with selected method
            processPayment(paymentMethod)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_checkout)

        setupToolbar()
        initViews()
        loadCourses()
        setupClickListeners()
    }

    private fun setupToolbar() {
        val toolbar = findViewById<androidx.appcompat.widget.Toolbar>(R.id.toolbar)
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "Checkout"
        toolbar.setNavigationOnClickListener {
            onBackPressedDispatcher.onBackPressed()
        }
    }

    private fun initViews() {
        try {
            coursesContainer = findViewById(R.id.coursesContainer)
            tvSubtotal = findViewById(R.id.tvSubtotal)
            tvPlatformFee = findViewById(R.id.tvPlatformFee)
            tvGst = findViewById(R.id.tvGst)
            tvTotal = findViewById(R.id.tvTotal)
            btnProceedPayment = findViewById(R.id.btnProceedPayment)
            cbTerms = findViewById(R.id.cbTerms)
        } catch (e: Exception) {
            android.util.Log.e("CheckoutActivity", "Error initializing views: ${e.message}", e)
            Toast.makeText(this, "Error loading checkout page", Toast.LENGTH_SHORT).show()
            finish()
        }
    }

    private fun loadCourses() {
        // Check if coming from Buy Now (single course) or Cart (multiple courses)
        val isSingleCourse = intent.getBooleanExtra("IS_SINGLE_COURSE", false)

        if (isSingleCourse) {
            // Load single course from intent
            val course = Course(
                id = intent.getIntExtra("COURSE_ID", 0),
                title = intent.getStringExtra("COURSE_TITLE") ?: "Course",
                description = intent.getStringExtra("COURSE_DESCRIPTION") ?: "",
                duration = intent.getStringExtra("COURSE_DURATION") ?: "",
                price = intent.getStringExtra("COURSE_PRICE") ?: "₹0",
                instructor = intent.getStringExtra("COURSE_INSTRUCTOR") ?: "Expert Instructor",
                rating = intent.getFloatExtra("COURSE_RATING", 4.5f),
                studentsEnrolled = intent.getIntExtra("COURSE_STUDENTS", 0),
                level = intent.getStringExtra("COURSE_LEVEL") ?: "Beginner",
                category = intent.getStringExtra("COURSE_CATEGORY") ?: "General",
                language = intent.getStringExtra("COURSE_LANGUAGE") ?: "English",
                modulesCount = intent.getIntExtra("COURSE_MODULES", 0),
                lecturesCount = intent.getIntExtra("COURSE_LECTURES", 0),
                certificateAvailable = intent.getBooleanExtra("COURSE_CERTIFICATE", true),
                prerequisites = intent.getStringExtra("COURSE_PREREQUISITES") ?: "Basic computer knowledge",
                learningOutcomes = intent.getStringArrayListExtra("COURSE_OUTCOMES") ?: arrayListOf()
            )
            courses.add(course)
        } else {
            // Load courses from cart
            courses.addAll(CartManager.getCartItems())
        }

        // Display courses
        displayCourses()
        calculatePrices()
    }

    private fun displayCourses() {
        coursesContainer.removeAllViews()

        for (course in courses) {
            val courseView = LayoutInflater.from(this)
                .inflate(R.layout.item_checkout_course, coursesContainer, false)

            // Populate course details
            courseView.findViewById<TextView>(R.id.tvCourseTitle).text = course.title
            courseView.findViewById<TextView>(R.id.tvCoursePrice).text = course.price
            courseView.findViewById<TextView>(R.id.tvInstructor).text = "👨‍🏫 ${course.instructor}"
            courseView.findViewById<TextView>(R.id.tvDuration).text = "⏱️ ${course.duration}"
            courseView.findViewById<TextView>(R.id.tvModulesCount).text = "📚 ${course.modulesCount} modules"
            courseView.findViewById<TextView>(R.id.tvLecturesCount).text = "🎥 ${course.lecturesCount} lectures"
            courseView.findViewById<TextView>(R.id.tvPrerequisites).text = "• ${course.prerequisites}"

            // Setup expandable modules
            val modulesHeader = courseView.findViewById<LinearLayout>(R.id.modulesHeader)
            val modulesContainer = courseView.findViewById<LinearLayout>(R.id.modulesContainer)
            val expandIcon = courseView.findViewById<TextView>(R.id.tvExpandIcon)

            modulesHeader.setOnClickListener {
                if (modulesContainer.visibility == View.GONE) {
                    modulesContainer.visibility = View.VISIBLE
                    expandIcon.text = "▲"
                    loadModulesForCourse(course, modulesContainer)
                } else {
                    modulesContainer.visibility = View.GONE
                    expandIcon.text = "▼"
                }
            }

            // Populate learning outcomes
            val outcomesContainer = courseView.findViewById<LinearLayout>(R.id.learningOutcomesContainer)
            outcomesContainer.removeAllViews()

            if (course.learningOutcomes.isNotEmpty()) {
                for (outcome in course.learningOutcomes) {
                    val outcomeView = TextView(this).apply {
                        text = "✓ $outcome"
                        textSize = 13f
                        setTextColor(getColor(R.color.text_secondary))
                        setPadding(0, 0, 0, 12)
                    }
                    outcomesContainer.addView(outcomeView)
                }
            } else {
                // Default outcomes
                val defaultOutcomes = listOf(
                    "Master the fundamentals and advanced concepts",
                    "Build real-world projects",
                    "Get job-ready skills and certification"
                )
                for (outcome in defaultOutcomes) {
                    val outcomeView = TextView(this).apply {
                        text = "✓ $outcome"
                        textSize = 13f
                        setTextColor(getColor(R.color.text_secondary))
                        setPadding(0, 0, 0, 12)
                    }
                    outcomesContainer.addView(outcomeView)
                }
            }

            coursesContainer.addView(courseView)
        }
    }

    private fun loadModulesForCourse(course: Course, container: LinearLayout) {
        if (container.childCount > 0) return // Already loaded

        val modules = CourseDataHelper.getModulesForCourse(course.id, course.title)

        for (module in modules) {
            val moduleView = LayoutInflater.from(this)
                .inflate(R.layout.item_module_simple, container, false)

            moduleView.findViewById<TextView>(R.id.tvModuleNumber).text = module.moduleNumber.toString()
            moduleView.findViewById<TextView>(R.id.tvModuleTitle).text = module.title
            moduleView.findViewById<TextView>(R.id.tvModuleDescription).text = module.description
            moduleView.findViewById<TextView>(R.id.tvModuleDuration).text = module.duration
            moduleView.findViewById<TextView>(R.id.tvLecturesInfo).text = "🎥 ${module.lectures.size} lectures"

            container.addView(moduleView)
        }
    }

    private fun calculatePrices() {
        subtotal = 0.0

        for (course in courses) {
            val priceString = course.price.replace("₹", "").replace(",", "").trim()
            val price = priceString.toDoubleOrNull() ?: 0.0
            subtotal += price
        }

        // Calculate GST (18% on subtotal + platform fee)
        gst = (subtotal + platformFee) * 0.18
        total = subtotal + platformFee + gst

        // Update UI
        tvSubtotal.text = "₹${formatPrice(subtotal)}"
        tvPlatformFee.text = "₹${formatPrice(platformFee)}"
        tvGst.text = "₹${formatPrice(gst)}"
        tvTotal.text = "₹${formatPrice(total)}"
    }

    private fun formatPrice(price: Double): String {
        return String.format("%.0f", price)
    }

    private fun setupClickListeners() {
        btnProceedPayment.setOnClickListener {
            if (!cbTerms.isChecked) {
                Toast.makeText(this, "Please accept Terms & Conditions", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // Navigate to payment method selection
            navigateToPaymentMethod()
        }
    }
    
    private fun navigateToPaymentMethod() {
        try {
            val intent = Intent(this, PaymentMethodActivity::class.java)
            intent.putExtra("TOTAL_AMOUNT", tvTotal.text.toString())
            intent.putExtra("IS_SINGLE_COURSE", getIntent().getBooleanExtra("IS_SINGLE_COURSE", false))
            
            // Pass course IDs for tracking
            val courseIds = ArrayList<Int>()
            for (course in courses) {
                courseIds.add(course.id)
            }
            intent.putIntegerArrayListExtra("COURSE_IDS", courseIds)
            
            android.util.Log.d("CheckoutActivity", "Launching PaymentMethodActivity with amount: ${tvTotal.text}")
            paymentMethodLauncher.launch(intent)
        } catch (e: Exception) {
            android.util.Log.e("CheckoutActivity", "Error navigating to payment method: ${e.message}", e)
            Toast.makeText(this, "Error: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun processPayment(paymentMethod: String) {
        // Show loading dialog
        val progressDialog = AlertDialog.Builder(this)
            .setTitle("Processing Payment")
            .setMessage("Please wait while we process your payment...")
            .setCancelable(false)
            .create()
        progressDialog.show()

        // Simulate payment processing
        android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
            progressDialog.dismiss()

            // Enroll user in courses
            enrollInCourses()

        }, 2000)
    }

    private fun enrollInCourses() {
        val currentUser = FirebaseAuth.getInstance().currentUser
        if (currentUser == null) {
            Toast.makeText(this, "Please login to continue", Toast.LENGTH_SHORT).show()
            return
        }

        val firestore = FirebaseFirestore.getInstance()
        var enrolledCount = 0

        for (course in courses) {
            val enrollmentData = hashMapOf(
                "studentId" to currentUser.uid,
                "courseId" to course.id.toString(),
                "courseTitle" to course.title,
                "enrolledAt" to System.currentTimeMillis(),
                "progress" to 0,
                "isCompleted" to false,
                "lastAccessedAt" to System.currentTimeMillis(),
                "amountPaid" to course.price
            )

            firestore.collection("enrollments")
                .add(enrollmentData)
                .addOnSuccessListener {
                    enrolledCount++
                    if (enrolledCount == courses.size) {
                        // All courses enrolled successfully
                        CartManager.clearCart()
                        showSuccessDialog()
                    }
                }
                .addOnFailureListener { e ->
                    Toast.makeText(this, "Enrollment failed: ${e.message}", Toast.LENGTH_LONG).show()
                }
        }
    }

    private fun showSuccessDialog() {
        AlertDialog.Builder(this)
            .setTitle("🎉 Payment Successful!")
            .setMessage("You have successfully enrolled in ${courses.size} course(s). Start learning now!")
            .setPositiveButton("Go to My Courses") { _, _ ->
                // Navigate to My Courses
                val intent = android.content.Intent(this, MyCoursesActivity::class.java)
                intent.flags = android.content.Intent.FLAG_ACTIVITY_CLEAR_TOP
                startActivity(intent)
                finish()
            }
            .setNegativeButton("Continue Shopping") { _, _ ->
                finish()
            }
            .setCancelable(false)
            .show()
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressedDispatcher.onBackPressed()
        return true
    }
}
