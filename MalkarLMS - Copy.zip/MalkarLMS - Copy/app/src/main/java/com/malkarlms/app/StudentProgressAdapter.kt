package com.malkarlms.app

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ProgressBar
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit

class StudentProgressAdapter(
    private var students: List<StudentProgress>
) : RecyclerView.Adapter<StudentProgressAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvStudentName: TextView = view.findViewById(R.id.tvStudentName)
        val tvStudentEmail: TextView = view.findViewById(R.id.tvStudentEmail)
        val tvProgressPercentage: TextView = view.findViewById(R.id.tvProgressPercentage)
        val progressBar: ProgressBar = view.findViewById(R.id.progressBar)
        val tvModulesCompleted: TextView = view.findViewById(R.id.tvModulesCompleted)
        val tvLastAccessed: TextView = view.findViewById(R.id.tvLastAccessed)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_student_progress, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val student = students[position]
        
        holder.tvStudentName.text = student.studentName
        holder.tvStudentEmail.text = student.studentEmail
        holder.tvProgressPercentage.text = "${student.overallProgress.toInt()}%"
        holder.progressBar.progress = student.overallProgress.toInt()
        holder.tvModulesCompleted.text = "${student.completedModules}/${student.totalModules} modules"
        holder.tvLastAccessed.text = "Last active: ${getTimeAgo(student.lastAccessedAt)}"
    }

    override fun getItemCount() = students.size

    fun updateData(newStudents: List<StudentProgress>) {
        students = newStudents
        notifyDataSetChanged()
    }

    private fun getTimeAgo(timestamp: Long): String {
        if (timestamp == 0L) return "Never"
        
        val now = System.currentTimeMillis()
        val diff = now - timestamp
        
        return when {
            diff < TimeUnit.MINUTES.toMillis(1) -> "Just now"
            diff < TimeUnit.HOURS.toMillis(1) -> "${TimeUnit.MILLISECONDS.toMinutes(diff)} min ago"
            diff < TimeUnit.DAYS.toMillis(1) -> "${TimeUnit.MILLISECONDS.toHours(diff)} hours ago"
            diff < TimeUnit.DAYS.toMillis(7) -> "${TimeUnit.MILLISECONDS.toDays(diff)} days ago"
            else -> SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()).format(Date(timestamp))
        }
    }
}
