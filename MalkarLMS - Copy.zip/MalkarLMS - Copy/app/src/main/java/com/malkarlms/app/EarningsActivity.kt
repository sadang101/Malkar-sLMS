package com.malkarlms.app

import android.os.Bundle
import android.util.Log
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query

class EarningsActivity : AppCompatActivity() {
    
    private lateinit var toolbar: Toolbar
    private lateinit var tvTotalEarnings: TextView
    private lateinit var tvThisMonth: TextView
    private lateinit var tvLastMonth: TextView
    private lateinit var tvPendingPayouts: TextView
    private lateinit var tvCompletedPayouts: TextView
    private lateinit var recyclerViewEarnings: RecyclerView
    
    private lateinit var firestore: FirebaseFirestore
    private lateinit var auth: FirebaseAuth
    private lateinit var earningsAdapter: EarningsAdapter
    private val earningsList = mutableListOf<EarningItem>()
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_earnings)
        
        initFirebase()
        initViews()
        setupToolbar()
        setupRecyclerView()
        loadEarnings()
    }
    
    private fun initFirebase() {
        firestore = FirebaseFirestore.getInstance()
        auth = FirebaseAuth.getInstance()
    }
    
    private fun initViews() {
        toolbar = findViewById(R.id.toolbar)
        tvTotalEarnings = findViewById(R.id.tvTotalEarnings)
        tvThisMonth = findViewById(R.id.tvThisMonth)
        tvLastMonth = findViewById(R.id.tvLastMonth)
        tvPendingPayouts = findViewById(R.id.tvPendingPayouts)
        tvCompletedPayouts = findViewById(R.id.tvCompletedPayouts)
        recyclerViewEarnings = findViewById(R.id.recyclerViewEarnings)
    }
    
    private fun setupToolbar() {
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "Earnings & Payouts"
    }
    
    private fun setupRecyclerView() {
        earningsAdapter = EarningsAdapter(earningsList)
        recyclerViewEarnings.apply {
            layoutManager = LinearLayoutManager(this@EarningsActivity)
            adapter = earningsAdapter
        }
    }
    
    private fun loadEarnings() {
        val currentUser = auth.currentUser
        if (currentUser == null) {
            Log.w("Earnings", "User not logged in")
            return
        }
        
        // Load instructor's courses and calculate earnings
        firestore.collection("courses")
            .whereEqualTo("instructorId", currentUser.uid)
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .get()
            .addOnSuccessListener { documents ->
                var totalEarnings = 0.0
                var thisMonthEarnings = 0.0
                var lastMonthEarnings = 0.0
                
                earningsList.clear()
                
                val currentTime = System.currentTimeMillis()
                val thisMonthStart = getMonthStart(currentTime)
                val lastMonthStart = getMonthStart(thisMonthStart - 1)
                val lastMonthEnd = thisMonthStart - 1
                
                for (document in documents) {
                    val courseData = document.data
                    val courseEarnings = courseData["totalEarnings"] as? Double ?: 0.0
                    val enrollmentCount = (courseData["enrollmentCount"] as? Long)?.toInt() ?: 0
                    val price = parsePrice(courseData["price"] as? String ?: "₹0")
                    val createdAt = courseData["createdAt"] as? Long ?: 0L
                    
                    totalEarnings += courseEarnings
                    
                    // Calculate monthly earnings (simplified - based on course creation date)
                    if (createdAt >= thisMonthStart) {
                        thisMonthEarnings += courseEarnings
                    } else if (createdAt >= lastMonthStart && createdAt <= lastMonthEnd) {
                        lastMonthEarnings += courseEarnings
                    }
                    
                    // Add to earnings list
                    if (courseEarnings > 0 || enrollmentCount > 0) {
                        earningsList.add(
                            EarningItem(
                                courseTitle = courseData["title"] as? String ?: "Unknown Course",
                                enrollmentCount = enrollmentCount,
                                pricePerEnrollment = price,
                                totalEarnings = courseEarnings,
                                lastUpdated = createdAt
                            )
                        )
                    }
                }
                
                // Update UI with calculated earnings
                updateEarningsUI(totalEarnings, thisMonthEarnings, lastMonthEarnings)
                earningsAdapter.notifyDataSetChanged()
            }
            .addOnFailureListener { e ->
                Log.w("Earnings", "Error loading earnings", e)
            }
    }
    
    private fun updateEarningsUI(
        totalEarnings: Double,
        thisMonthEarnings: Double,
        lastMonthEarnings: Double
    ) {
        tvTotalEarnings.text = "₹${String.format("%.2f", totalEarnings)}"
        tvThisMonth.text = "₹${String.format("%.2f", thisMonthEarnings)}"
        tvLastMonth.text = "₹${String.format("%.2f", lastMonthEarnings)}"
        
        // For demo purposes, show pending and completed payouts
        val pendingPayouts = totalEarnings * 0.3 // 30% pending
        val completedPayouts = totalEarnings * 0.7 // 70% completed
        
        tvPendingPayouts.text = "₹${String.format("%.2f", pendingPayouts)}"
        tvCompletedPayouts.text = "₹${String.format("%.2f", completedPayouts)}"
    }
    
    private fun parsePrice(priceString: String): Double {
        return try {
            priceString.replace("₹", "").replace(",", "").toDouble()
        } catch (e: NumberFormatException) {
            0.0
        }
    }
    
    private fun getMonthStart(timestamp: Long): Long {
        val calendar = java.util.Calendar.getInstance()
        calendar.timeInMillis = timestamp
        calendar.set(java.util.Calendar.DAY_OF_MONTH, 1)
        calendar.set(java.util.Calendar.HOUR_OF_DAY, 0)
        calendar.set(java.util.Calendar.MINUTE, 0)
        calendar.set(java.util.Calendar.SECOND, 0)
        calendar.set(java.util.Calendar.MILLISECOND, 0)
        return calendar.timeInMillis
    }
    
    override fun onSupportNavigateUp(): Boolean {
        onBackPressedDispatcher.onBackPressed()
        return true
    }
}
