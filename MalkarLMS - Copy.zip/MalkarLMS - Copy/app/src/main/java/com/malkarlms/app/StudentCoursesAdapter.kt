package com.malkarlms.app

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ProgressBar
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import java.text.SimpleDateFormat
import java.util.*

class StudentCoursesAdapter(
    private val coursesList: List<StudentCourse>,
    private val onCourseClick: (StudentCourse) -> Unit
) : RecyclerView.Adapter<StudentCoursesAdapter.ViewHolder>() {
    
    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvCourseTitle: TextView = itemView.findViewById(R.id.tvCourseTitle)
        val tvInstructor: TextView = itemView.findViewById(R.id.tvInstructor)
        val tvCategory: TextView = itemView.findViewById(R.id.tvCategory)
        val tvDuration: TextView = itemView.findViewById(R.id.tvDuration)
        val tvProgress: TextView = itemView.findViewById(R.id.tvProgress)
        val progressBar: ProgressBar = itemView.findViewById(R.id.progressBar)
        val tvEnrolledDate: TextView = itemView.findViewById(R.id.tvEnrolledDate)
        val tvStatus: TextView = itemView.findViewById(R.id.tvStatus)
    }
    
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_student_course, parent, false)
        return ViewHolder(view)
    }
    
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val course = coursesList[position]
        
        holder.tvCourseTitle.text = course.title
        holder.tvInstructor.text = "by ${course.instructor}"
        holder.tvCategory.text = course.category
        holder.tvDuration.text = course.duration
        
        // Progress
        holder.tvProgress.text = "${course.progress}% Complete"
        holder.progressBar.progress = course.progress
        
        // Status
        holder.tvStatus.text = if (course.isCompleted) "Completed" else "In Progress"
        holder.tvStatus.setTextColor(
            if (course.isCompleted) 
                holder.itemView.context.getColor(R.color.success)
            else 
                holder.itemView.context.getColor(R.color.warning)
        )
        
        // Enrolled date
        val dateFormat = SimpleDateFormat("MMM dd, yyyy", Locale.getDefault())
        holder.tvEnrolledDate.text = "Enrolled: ${dateFormat.format(Date(course.enrolledAt))}"
        
        // Click listener
        holder.itemView.setOnClickListener {
            onCourseClick(course)
        }
    }
    
    override fun getItemCount(): Int = coursesList.size
}
