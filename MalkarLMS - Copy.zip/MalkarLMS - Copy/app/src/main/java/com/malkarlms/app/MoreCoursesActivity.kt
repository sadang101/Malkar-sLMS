package com.malkarlms.app

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query

class MoreCoursesActivity : AppCompatActivity() {
    
    private lateinit var recyclerView: RecyclerView
    private lateinit var courseAdapter: CourseAdapter
    private val courseList = mutableListOf<Course>()
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_more_courses)
        
        setupToolbar()
        initViews()
        setupRecyclerView()
        loadPublishedCourses()
    }
    
    private fun setupToolbar() {
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "More Courses"
    }
    
    private fun initViews() {
        recyclerView = findViewById(R.id.recyclerViewCourses)
    }
    
    /**
     * Load published courses from Firebase Firestore
     * Only shows courses that are published (not drafts)
     */
    private fun loadPublishedCourses() {
        Log.d("MoreCourses", "Loading hardcoded sample courses...")
        
        // Load hardcoded courses for presentation
        courseList.clear()
        courseList.addAll(getSampleCourses())
        courseAdapter.notifyDataSetChanged()
        
        Log.d("MoreCourses", "Loaded ${courseList.size} sample courses")
    }
    
    private fun getSampleCourses(): List<Course> {
        return listOf(
            Course(1, "Digital Marketing", "Learn modern digital marketing strategies", "10 weeks", "₹1000", "", "Meera Kapoor", 4.8f, 19500, 0, "Business", "Beginner"),
            Course(2, "MBA Essentials", "Master business administration fundamentals", "16 weeks", "₹1500", "", "Prof. Suresh Menon", 4.9f, 12300, 0, "Business", "Intermediate"),
            Course(3, "Python Programming", "Master Python from basics to advanced", "12 weeks", "₹2999", "", "Dr. Rajesh Kumar", 4.8f, 15420, 0, "IT", "Beginner"),
            Course(4, "Web Development", "Full stack web development bootcamp", "16 weeks", "₹4499", "", "Priya Sharma", 4.9f, 22350, 0, "IT", "Beginner"),
            Course(5, "Data Science", "Learn data analysis and machine learning", "14 weeks", "₹3999", "", "Dr. Amit Patel", 4.7f, 18900, 0, "IT", "Intermediate"),
            Course(6, "Android Development", "Build professional Android apps", "12 weeks", "₹3499", "", "Vikram Singh", 4.6f, 12450, 0, "IT", "Beginner"),
            Course(7, "AutoCAD", "Complete AutoCAD mechanical design", "10 weeks", "₹3499", "", "Er. Vijay Patil", 4.7f, 14200, 0, "Mechanical", "Beginner"),
            Course(8, "SolidWorks", "Master 3D CAD design", "12 weeks", "₹4499", "", "Er. Ravi Kumar", 4.8f, 11500, 0, "Mechanical", "Intermediate")
        )
    }
    
    /**
     * Fallback method with hardcoded courses if Firebase fails
     */
    private fun loadFallbackCourses() {
        courseList.clear()
        courseList.addAll(
            listOf(
                Course(
                    id = 1,
                    title = "Digital Marketing",
                    description = "Learn modern digital marketing strategies and techniques",
                    duration = "8 weeks",
                    price = "₹1000"
                ),
                Course(
                    id = 2,
                    title = "MBA Essentials", 
                    description = "Master business administration fundamentals",
                    duration = "12 weeks",
                    price = "₹1500"
                )
            )
        )
        courseAdapter.notifyDataSetChanged()
    }
    
    private fun setupRecyclerView() {
        courseAdapter = CourseAdapter(courseList) { course ->
            val intent = Intent(this, CourseDetailsActivity::class.java).apply {
                putExtra("COURSE_ID", course.id)
                putExtra("COURSE_TITLE", course.title)
                putExtra("COURSE_DESCRIPTION", course.description)
                putExtra("COURSE_DURATION", course.duration)
                putExtra("COURSE_PRICE", course.price)
                putExtra("COURSE_INSTRUCTOR", course.instructor)
                putExtra("COURSE_RATING", course.rating)
                putExtra("COURSE_STUDENTS", course.studentsEnrolled)
                putExtra("COURSE_LEVEL", course.level)
            }
            startActivity(intent)
        }
        
        recyclerView.apply {
            layoutManager = GridLayoutManager(this@MoreCoursesActivity, 2)
            adapter = courseAdapter
            setHasFixedSize(true)
            setItemViewCacheSize(20)
        }
    }
    
    override fun onSupportNavigateUp(): Boolean {
        onBackPressedDispatcher.onBackPressed()
        return true
    }
}
