package com.malkarlms.app

import android.content.Context
import android.content.res.Configuration
import android.os.Build
import java.util.*

object LocaleHelper {
    
    private const val SELECTED_LANGUAGE = "selected_language"
    
    fun setLocale(context: Context, languageCode: String): Context {
        persist(context, languageCode)
        return updateResources(context, languageCode)
    }
    
    fun getLanguage(context: Context): String {
        val prefs = context.getSharedPreferences("app_settings", Context.MODE_PRIVATE)
        return prefs.getString(SELECTED_LANGUAGE, "en") ?: "en"
    }
    
    private fun persist(context: Context, languageCode: String) {
        val prefs = context.getSharedPreferences("app_settings", Context.MODE_PRIVATE)
        prefs.edit().putString(SELECTED_LANGUAGE, languageCode).apply()
    }
    
    private fun updateResources(context: Context, languageCode: String): Context {
        val locale = Locale(languageCode)
        Locale.setDefault(locale)
        
        val configuration = Configuration(context.resources.configuration)
        configuration.setLocale(locale)
        
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            context.createConfigurationContext(configuration)
        } else {
            @Suppress("DEPRECATION")
            context.resources.updateConfiguration(configuration, context.resources.displayMetrics)
            context
        }
    }
    
    fun getLanguageName(languageCode: String): String {
        return when (languageCode) {
            "en" -> "English"
            "hi" -> "हिंदी (Hindi)"
            "mr" -> "मराठी (Marathi)"
            "ta" -> "தமிழ் (Tamil)"
            "te" -> "తెలుగు (Telugu)"
            else -> "English"
        }
    }
    
    fun getLanguageCode(languageName: String): String {
        return when {
            languageName.contains("Hindi") -> "hi"
            languageName.contains("Marathi") -> "mr"
            languageName.contains("Tamil") -> "ta"
            languageName.contains("Telugu") -> "te"
            else -> "en"
        }
    }
}
