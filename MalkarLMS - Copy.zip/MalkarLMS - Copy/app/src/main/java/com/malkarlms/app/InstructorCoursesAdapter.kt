package com.malkarlms.app

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class InstructorCoursesAdapter(
    private val coursesList: List<InstructorCourse>,
    private val onCourseClick: (InstructorCourse) -> Unit
) : RecyclerView.Adapter<InstructorCoursesAdapter.ViewHolder>() {
    
    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvCourseTitle: TextView = itemView.findViewById(R.id.tvCourseTitle)
        val tvCourseDescription: TextView = itemView.findViewById(R.id.tvCourseDescription)
        val tvCoursePrice: TextView = itemView.findViewById(R.id.tvCoursePrice)
        val tvCourseDuration: TextView = itemView.findViewById(R.id.tvCourseDuration)
        val tvCourseCategory: TextView = itemView.findViewById(R.id.tvCourseCategory)
        val tvStatus: TextView = itemView.findViewById(R.id.tvStatus)
        val tvEnrollmentCount: TextView = itemView.findViewById(R.id.tvEnrollmentCount)
        val tvViews: TextView = itemView.findViewById(R.id.tvViews)
        val tvRating: TextView = itemView.findViewById(R.id.tvRating)
    }
    
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_instructor_course, parent, false)
        return ViewHolder(view)
    }
    
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val course = coursesList[position]
        
        holder.tvCourseTitle.text = course.title
        holder.tvCourseDescription.text = course.description
        holder.tvCoursePrice.text = course.price
        holder.tvCourseDuration.text = course.duration
        holder.tvCourseCategory.text = course.category
        
        // Status
        holder.tvStatus.text = if (course.isDraft) "Draft" else "Published"
        holder.tvStatus.setTextColor(
            if (course.isDraft) 
                holder.itemView.context.getColor(R.color.warning)
            else 
                holder.itemView.context.getColor(R.color.success)
        )
        
        // Statistics
        holder.tvEnrollmentCount.text = "${course.enrollmentCount} enrolled"
        holder.tvViews.text = "${course.views} views"
        holder.tvRating.text = "${String.format("%.1f", course.rating)} (${course.reviewCount})"
        
        // Click listener
        holder.itemView.setOnClickListener {
            onCourseClick(course)
        }
    }
    
    override fun getItemCount(): Int = coursesList.size
}
