package com.malkarlms.app

import java.lang.ref.WeakReference

object CartManager {
    private val cartItems = mutableListOf<Course>()
    private val cartListeners = mutableListOf<WeakReference<CartListener>>()
    
    interface CartListener {
        fun onCartUpdated(itemCount: Int)
    }
    
    fun addToCart(course: Course) {
        if (!cartItems.any { it.id == course.id }) {
            cartItems.add(course)
            notifyListeners()
        }
    }
    
    fun removeFromCart(courseId: Int) {
        cartItems.removeAll { it.id == courseId }
        notifyListeners()
    }
    
    fun getCartItems(): List<Course> = cartItems.toList()
    
    fun getCartItemCount(): Int = cartItems.size
    
    fun getTotalPrice(): String {
        val subtotal = cartItems.sumOf { 
            it.price.replace("₹", "").replace(",", "").toIntOrNull() ?: 0 
        }
        val platformFee = if (subtotal > 0) 7 else 0
        val gstAmount = ((subtotal + platformFee) * 0.18).toInt()
        val total = subtotal + platformFee + gstAmount
        return "₹$total"
    }
    
    fun getSubtotal(): Int {
        return cartItems.sumOf { 
            it.price.replace("₹", "").replace(",", "").toIntOrNull() ?: 0 
        }
    }
    
    fun clearCart() {
        cartItems.clear()
        notifyListeners()
    }
    
    fun isInCart(courseId: Int): Boolean = cartItems.any { it.id == courseId }
    
    fun addCartListener(listener: CartListener) {
        cartListeners.add(WeakReference(listener))
    }
    
    fun removeCartListener(listener: CartListener) {
        cartListeners.removeAll { it.get() == listener || it.get() == null }
    }
    
    private fun notifyListeners() {
        // Clean up dead references and notify alive ones
        val iterator = cartListeners.iterator()
        while (iterator.hasNext()) {
            val weakRef = iterator.next()
            val listener = weakRef.get()
            if (listener == null) {
                iterator.remove()
            } else {
                listener.onCartUpdated(cartItems.size)
            }
        }
    }
}
