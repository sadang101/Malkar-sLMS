package com.malkarlms.app

import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class CartAdapter(
    private var cartItems: List<Course>,
    private val onRemoveClick: (Course) -> Unit
) : RecyclerView.Adapter<CartAdapter.CartViewHolder>() {

    class CartViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val titleTextView: TextView = itemView.findViewById(R.id.tvCartCourseTitle)
        val priceTextView: TextView = itemView.findViewById(R.id.tvCartCoursePrice)
        val durationTextView: TextView = itemView.findViewById(R.id.tvCartCourseDuration)
        val removeButton: Button = itemView.findViewById(R.id.btnRemoveFromCart)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CartViewHolder {
        try {
            Log.d("CartAdapter", "Creating ViewHolder")
            val view = LayoutInflater.from(parent.context)
                .inflate(R.layout.item_cart_course, parent, false)
            return CartViewHolder(view)
        } catch (e: Exception) {
            Log.e("CartAdapter", "Error creating ViewHolder: ${e.message}", e)
            throw e
        }
    }

    override fun onBindViewHolder(holder: CartViewHolder, position: Int) {
        try {
            if (position >= cartItems.size) {
                Log.e("CartAdapter", "Position $position out of bounds for ${cartItems.size} items")
                return
            }
            
            val course = cartItems[position]
            Log.d("CartAdapter", "Binding course: ${course.title} at position $position")
            
            holder.titleTextView.text = course.title ?: "Unknown Course"
            holder.priceTextView.text = course.price ?: "₹0"
            holder.durationTextView.text = course.duration ?: "Unknown Duration"
            
            holder.removeButton.setOnClickListener {
                Log.d("CartAdapter", "Remove button clicked for: ${course.title}")
                onRemoveClick(course)
            }
        } catch (e: Exception) {
            Log.e("CartAdapter", "Error binding ViewHolder at position $position: ${e.message}", e)
        }
    }

    override fun getItemCount(): Int = cartItems.size
    
    fun updateItems(newItems: List<Course>) {
        cartItems = newItems
        notifyDataSetChanged()
    }
}
