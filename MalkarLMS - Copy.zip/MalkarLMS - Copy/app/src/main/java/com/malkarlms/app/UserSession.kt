package com.malkarlms.app

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser

object UserSession {
    private const val PREF_NAME = "MalkarLMS_UserSession"
    private const val KEY_USER_NAME = "user_name"
    private const val KEY_USER_EMAIL = "user_email"
    private const val KEY_IS_LOGGED_IN = "is_logged_in"
    private const val KEY_USER_ROLE = "user_role"
    
    private fun getSharedPreferences(context: Context): SharedPreferences {
        return context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
    }
    
    fun saveUserInfo(context: Context, name: String, email: String) {
        Log.d("UserSession", "Saving user info - Name: '$name', Email: '$email'")
        val prefs = getSharedPreferences(context)
        prefs.edit().apply {
            putString(KEY_USER_NAME, name)
            putString(KEY_USER_EMAIL, email)
            putBoolean(KEY_IS_LOGGED_IN, true)
            apply()
        }
    }
    
    fun saveUserRole(context: Context, role: UserRole) {
        Log.d("UserSession", "Saving user role: ${role.name}")
        val prefs = getSharedPreferences(context)
        prefs.edit().apply {
            putString(KEY_USER_ROLE, role.name)
            apply()
        }
    }
    
    fun getUserRole(context: Context): UserRole {
        val prefs = getSharedPreferences(context)
        val roleString = prefs.getString(KEY_USER_ROLE, UserRole.STUDENT.name)
        return try {
            UserRole.valueOf(roleString ?: UserRole.STUDENT.name)
        } catch (e: IllegalArgumentException) {
            UserRole.STUDENT
        }
    }
    
    fun getUserName(context: Context): String {
        val prefs = getSharedPreferences(context)
        return prefs.getString(KEY_USER_NAME, "Student Name") ?: "Student Name"
    }
    
    fun getUserEmail(context: Context): String {
        val prefs = getSharedPreferences(context)
        return prefs.getString(KEY_USER_EMAIL, "student@example.com") ?: "student@example.com"
    }
    
    fun isLoggedIn(context: Context): Boolean {
        val prefs = getSharedPreferences(context)
        return prefs.getBoolean(KEY_IS_LOGGED_IN, false)
    }
    
    fun clearUserSession(context: Context) {
        val prefs = getSharedPreferences(context)
        prefs.edit().clear().apply()
    }
    
    fun loadUserInfoFromFirebase(context: Context) {
        val currentUser = FirebaseAuth.getInstance().currentUser
        currentUser?.let { user ->
            val email = user.email ?: "student@example.com"
            val name = user.displayName ?: extractNameFromEmail(email)
            Log.d("UserSession", "Loading from Firebase - DisplayName: '${user.displayName}', Email: '$email', Extracted Name: '$name'")
            saveUserInfo(context, name, email)
        }
    }
    
    private fun extractNameFromEmail(email: String): String {
        return if (email.contains("@")) {
            val username = email.substringBefore("@")
            
            // Handle different naming patterns
            val processedName = username
                .replace(".", " ")
                .replace("_", " ")
                .replace("-", " ")
                // Split camelCase and common patterns like "sarangvadak" -> "sarang vadak"
                .let { name ->
                    // Insert space before capital letters (for camelCase)
                    name.replace(Regex("([a-z])([A-Z])"), "$1 $2")
                        // For names like "sarangvadak", try to split at common boundaries
                        .let { processed ->
                            if (processed.contains(" ")) {
                                processed
                            } else {
                                // Try to split common name patterns
                                when {
                                    processed.length > 8 -> {
                                        // For longer names, try to split in the middle
                                        val mid = processed.length / 2
                                        "${processed.substring(0, mid)} ${processed.substring(mid)}"
                                    }
                                    else -> processed
                                }
                            }
                        }
                }
            
            // Capitalize each word
            processedName.split(" ")
                .joinToString(" ") { word ->
                    word.trim().replaceFirstChar { 
                        if (it.isLowerCase()) it.titlecase() else it.toString() 
                    }
                }
                .trim()
        } else {
            "Student Name"
        }
    }
}
