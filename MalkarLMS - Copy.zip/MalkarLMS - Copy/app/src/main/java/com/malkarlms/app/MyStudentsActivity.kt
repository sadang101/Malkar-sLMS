package com.malkarlms.app

import android.graphics.Color
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.github.mikephil.charting.charts.PieChart
import com.github.mikephil.charting.data.PieData
import com.github.mikephil.charting.data.PieDataSet
import com.github.mikephil.charting.data.PieEntry
import com.github.mikephil.charting.formatter.PercentFormatter
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import java.util.concurrent.TimeUnit

class MyStudentsActivity : AppCompatActivity() {

    private lateinit var btnBack: TextView
    private lateinit var tvTotalStudents: TextView
    private lateinit var tvActiveStudents: TextView
    private lateinit var tvAverageProgress: TextView
    private lateinit var progressBarAverage: ProgressBar
    private lateinit var pieChartDifficulty: PieChart
    private lateinit var tvEasyCount: TextView
    private lateinit var tvMediumCount: TextView
    private lateinit var tvHardCount: TextView
    private lateinit var rvModulePerformance: RecyclerView
    private lateinit var rvStudents: RecyclerView
    private lateinit var emptyState: LinearLayout

    private lateinit var studentAdapter: StudentProgressAdapter
    private lateinit var moduleAdapter: ModulePerformanceAdapter

    private val firestore = FirebaseFirestore.getInstance()
    private val auth = FirebaseAuth.getInstance()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_my_students)

        initViews()
        setupRecyclerViews()
        loadStudentData()
    }

    private fun initViews() {
        btnBack = findViewById(R.id.btnBack)
        tvTotalStudents = findViewById(R.id.tvTotalStudents)
        tvActiveStudents = findViewById(R.id.tvActiveStudents)
        tvAverageProgress = findViewById(R.id.tvAverageProgress)
        progressBarAverage = findViewById(R.id.progressBarAverage)
        pieChartDifficulty = findViewById(R.id.pieChartDifficulty)
        tvEasyCount = findViewById(R.id.tvEasyCount)
        tvMediumCount = findViewById(R.id.tvMediumCount)
        tvHardCount = findViewById(R.id.tvHardCount)
        rvModulePerformance = findViewById(R.id.rvModulePerformance)
        rvStudents = findViewById(R.id.rvStudents)
        emptyState = findViewById(R.id.emptyState)

        btnBack.setOnClickListener {
            finish()
        }

        setupPieChart()
    }

    private fun setupRecyclerViews() {
        // Student list RecyclerView
        studentAdapter = StudentProgressAdapter(emptyList())
        rvStudents.layoutManager = LinearLayoutManager(this)
        rvStudents.adapter = studentAdapter

        // Module performance RecyclerView
        moduleAdapter = ModulePerformanceAdapter(emptyList())
        rvModulePerformance.layoutManager = LinearLayoutManager(this)
        rvModulePerformance.adapter = moduleAdapter
    }

    private fun setupPieChart() {
        pieChartDifficulty.apply {
            setUsePercentValues(true)
            description.isEnabled = false
            setExtraOffsets(5f, 10f, 5f, 5f)
            dragDecelerationFrictionCoef = 0.95f
            isDrawHoleEnabled = true
            setHoleColor(Color.WHITE)
            setTransparentCircleColor(Color.WHITE)
            setTransparentCircleAlpha(110)
            holeRadius = 58f
            transparentCircleRadius = 61f
            setDrawCenterText(true)
            centerText = "Module\nDifficulty"
            rotationAngle = 0f
            isRotationEnabled = true
            isHighlightPerTapEnabled = true
            legend.isEnabled = false
            setEntryLabelColor(Color.BLACK)
            setEntryLabelTextSize(12f)
        }
    }

    private fun loadStudentData() {
        val currentUser = auth.currentUser
        if (currentUser == null) {
            Toast.makeText(this, "Please login first", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        // First, get all courses by this instructor
        firestore.collection("courses")
            .whereEqualTo("instructorId", currentUser.uid)
            .get()
            .addOnSuccessListener { courseDocuments ->
                if (courseDocuments.isEmpty) {
                    showEmptyState()
                    return@addOnSuccessListener
                }

                val courseIds = courseDocuments.documents.map { it.id }
                
                // Firestore whereIn has a limit of 10 items, so we need to batch if more courses
                if (courseIds.isEmpty()) {
                    showEmptyState()
                    return@addOnSuccessListener
                }
                
                loadEnrollmentsForCourses(courseIds)
            }
            .addOnFailureListener { e ->
                Log.e("MyStudents", "Error loading courses", e)
                Toast.makeText(this, "Error loading data", Toast.LENGTH_SHORT).show()
                showEmptyState()
            }
    }

    private fun loadEnrollmentsForCourses(courseIds: List<String>) {
        // Firestore whereIn has a limit of 10 items, so batch if needed
        if (courseIds.size > 10) {
            loadEnrollmentsInBatches(courseIds)
            return
        }
        
        // Load all enrollments for instructor's courses
        firestore.collection("enrollments")
            .whereIn("courseId", courseIds)
            .get()
            .addOnSuccessListener { enrollmentDocuments ->
                processEnrollments(enrollmentDocuments.documents)
            }
            .addOnFailureListener { e ->
                Log.e("MyStudents", "Error loading enrollments", e)
                Toast.makeText(this, "Error loading student data", Toast.LENGTH_SHORT).show()
                showEmptyState()
            }
    }
    
    private fun loadEnrollmentsInBatches(courseIds: List<String>) {
        // Split courseIds into batches of 10 (Firestore whereIn limit)
        val batches = courseIds.chunked(10)
        val allEnrollments = mutableListOf<com.google.firebase.firestore.DocumentSnapshot>()
        var completedBatches = 0
        
        for (batch in batches) {
            firestore.collection("enrollments")
                .whereIn("courseId", batch)
                .get()
                .addOnSuccessListener { documents ->
                    allEnrollments.addAll(documents.documents)
                    completedBatches++
                    
                    // When all batches are complete, process the data
                    if (completedBatches == batches.size) {
                        processEnrollments(allEnrollments)
                    }
                }
                .addOnFailureListener { e ->
                    Log.e("MyStudents", "Error loading batch", e)
                    completedBatches++
                    
                    if (completedBatches == batches.size) {
                        if (allEnrollments.isEmpty()) {
                            showEmptyState()
                        } else {
                            processEnrollments(allEnrollments)
                        }
                    }
                }
        }
    }
    
    private fun processEnrollments(enrollmentDocuments: List<com.google.firebase.firestore.DocumentSnapshot>) {
        if (enrollmentDocuments.isEmpty()) {
            showEmptyState()
            return
        }
        
        val studentProgressList = mutableListOf<StudentProgress>()
        val moduleDifficultyMap = mutableMapOf<String, MutableList<ModuleProgress>>()

        for (doc in enrollmentDocuments) {
            val studentId = doc.getString("studentId") ?: continue
            val courseId = doc.getString("courseId") ?: continue
            val enrolledAt = doc.getLong("enrolledAt") ?: 0L

            // Get student progress data
            val progress = doc.getDouble("progress")?.toFloat() ?: 0f
            val completedModules = doc.getLong("completedModules")?.toInt() ?: 0
            val totalModules = doc.getLong("totalModules")?.toInt() ?: 10
            val lastAccessedAt = doc.getLong("lastAccessedAt") ?: enrolledAt

            // Get module progress (if available)
            @Suppress("UNCHECKED_CAST")
            val moduleProgressData = doc.get("moduleProgress") as? Map<String, Map<String, Any>> ?: emptyMap()
            
            val moduleProgressMap = mutableMapOf<String, ModuleProgress>()
            for ((moduleId, moduleData) in moduleProgressData) {
                val moduleName = moduleData["moduleName"] as? String ?: "Module $moduleId"
                val difficulty = moduleData["difficulty"] as? String ?: "Medium"
                val completionPercentage = (moduleData["completionPercentage"] as? Number)?.toFloat() ?: 0f
                val isCompleted = moduleData["isCompleted"] as? Boolean ?: false
                val quizScore = (moduleData["quizScore"] as? Number)?.toFloat() ?: 0f

                val moduleProgress = ModuleProgress(
                    moduleId = moduleId,
                    moduleName = moduleName,
                    difficulty = difficulty,
                    completionPercentage = completionPercentage,
                    isCompleted = isCompleted,
                    quizScore = quizScore
                )
                
                moduleProgressMap[moduleId] = moduleProgress
                
                // Aggregate module difficulty stats
                if (!moduleDifficultyMap.containsKey(moduleName)) {
                    moduleDifficultyMap[moduleName] = mutableListOf()
                }
                moduleDifficultyMap[moduleName]?.add(moduleProgress)
            }

            // Create student progress object
            val studentProgress = StudentProgress(
                studentId = studentId,
                studentName = "Loading...",
                studentEmail = "",
                courseId = courseId,
                courseName = "",
                enrolledAt = enrolledAt,
                overallProgress = progress,
                completedModules = completedModules,
                totalModules = totalModules,
                lastAccessedAt = lastAccessedAt,
                moduleProgress = moduleProgressMap
            )
            
            studentProgressList.add(studentProgress)
        }

        // Fetch student details
        fetchStudentDetails(studentProgressList, moduleDifficultyMap)
    }

    private fun fetchStudentDetails(
        studentProgressList: List<StudentProgress>,
        moduleDifficultyMap: Map<String, List<ModuleProgress>>
    ) {
        val updatedList = mutableListOf<StudentProgress>()
        var fetchedCount = 0

        if (studentProgressList.isEmpty()) {
            showEmptyState()
            return
        }

        for (studentProgress in studentProgressList) {
            firestore.collection("users")
                .document(studentProgress.studentId)
                .get()
                .addOnSuccessListener { userDoc ->
                    val name = userDoc.getString("name") ?: "Unknown Student"
                    val email = userDoc.getString("email") ?: ""

                    updatedList.add(studentProgress.copy(
                        studentName = name,
                        studentEmail = email
                    ))

                    fetchedCount++
                    if (fetchedCount == studentProgressList.size) {
                        displayData(updatedList, moduleDifficultyMap)
                    }
                }
                .addOnFailureListener {
                    updatedList.add(studentProgress.copy(
                        studentName = "Unknown Student"
                    ))

                    fetchedCount++
                    if (fetchedCount == studentProgressList.size) {
                        displayData(updatedList, moduleDifficultyMap)
                    }
                }
        }
    }

    private fun displayData(
        studentProgressList: List<StudentProgress>,
        moduleDifficultyMap: Map<String, List<ModuleProgress>>
    ) {
        if (studentProgressList.isEmpty()) {
            showEmptyState()
            return
        }

        emptyState.visibility = View.GONE
        rvStudents.visibility = View.VISIBLE
        rvModulePerformance.visibility = View.VISIBLE

        // Update statistics
        val totalStudents = studentProgressList.size
        val sevenDaysAgo = System.currentTimeMillis() - TimeUnit.DAYS.toMillis(7)
        val activeStudents = studentProgressList.count { it.lastAccessedAt > sevenDaysAgo }
        val averageProgress = if (totalStudents > 0) {
            studentProgressList.map { it.overallProgress }.average().toFloat()
        } else 0f

        tvTotalStudents.text = totalStudents.toString()
        tvActiveStudents.text = activeStudents.toString()
        tvAverageProgress.text = "${averageProgress.toInt()}%"
        progressBarAverage.progress = averageProgress.toInt()

        // Update student list
        studentAdapter.updateData(studentProgressList)

        // Calculate module difficulty statistics
        val difficultyStatsList = mutableListOf<DifficultyStats>()
        for ((moduleName, progressList) in moduleDifficultyMap) {
            if (progressList.isEmpty()) continue

            val difficulty = progressList.first().difficulty
            val avgScore = progressList.map { it.quizScore }.average().toFloat()
            val completionRate = (progressList.count { it.isCompleted }.toFloat() / progressList.size) * 100

            difficultyStatsList.add(
                DifficultyStats(
                    moduleName = moduleName,
                    difficulty = difficulty,
                    averageScore = avgScore,
                    completionRate = completionRate,
                    studentCount = progressList.size
                )
            )
        }

        // Update module performance list
        moduleAdapter.updateData(difficultyStatsList.sortedByDescending { it.studentCount })

        // Update pie chart
        updatePieChart(difficultyStatsList)
    }

    private fun updatePieChart(difficultyStatsList: List<DifficultyStats>) {
        val easyCount = difficultyStatsList.count { it.difficulty.equals("Easy", ignoreCase = true) }
        val mediumCount = difficultyStatsList.count { it.difficulty.equals("Medium", ignoreCase = true) }
        val hardCount = difficultyStatsList.count { it.difficulty.equals("Hard", ignoreCase = true) }

        tvEasyCount.text = easyCount.toString()
        tvMediumCount.text = mediumCount.toString()
        tvHardCount.text = hardCount.toString()

        val entries = mutableListOf<PieEntry>()
        if (easyCount > 0) entries.add(PieEntry(easyCount.toFloat(), "Easy"))
        if (mediumCount > 0) entries.add(PieEntry(mediumCount.toFloat(), "Medium"))
        if (hardCount > 0) entries.add(PieEntry(hardCount.toFloat(), "Hard"))

        if (entries.isEmpty()) {
            // Show placeholder if no data
            entries.add(PieEntry(1f, "No Data"))
            val dataSet = PieDataSet(entries, "")
            dataSet.colors = listOf(Color.LTGRAY)
            val data = PieData(dataSet)
            data.setValueTextSize(0f)
            pieChartDifficulty.data = data
            pieChartDifficulty.invalidate()
            return
        }

        val dataSet = PieDataSet(entries, "Module Difficulty")
        dataSet.setDrawIcons(false)
        dataSet.sliceSpace = 3f
        dataSet.selectionShift = 5f

        val colors = mutableListOf<Int>()
        for (entry in entries) {
            when (entry.label) {
                "Easy" -> colors.add(getColor(R.color.chart_easy))
                "Medium" -> colors.add(getColor(R.color.chart_medium))
                "Hard" -> colors.add(getColor(R.color.chart_hard))
            }
        }
        dataSet.colors = colors

        val data = PieData(dataSet)
        data.setValueFormatter(PercentFormatter(pieChartDifficulty))
        data.setValueTextSize(11f)
        data.setValueTextColor(Color.WHITE)

        pieChartDifficulty.data = data
        pieChartDifficulty.highlightValues(null)
        pieChartDifficulty.invalidate()
    }

    private fun showEmptyState() {
        emptyState.visibility = View.VISIBLE
        rvStudents.visibility = View.GONE
        rvModulePerformance.visibility = View.GONE
        
        tvTotalStudents.text = "0"
        tvActiveStudents.text = "0"
        tvAverageProgress.text = "0%"
        progressBarAverage.progress = 0
        tvEasyCount.text = "0"
        tvMediumCount.text = "0"
        tvHardCount.text = "0"
    }
}
