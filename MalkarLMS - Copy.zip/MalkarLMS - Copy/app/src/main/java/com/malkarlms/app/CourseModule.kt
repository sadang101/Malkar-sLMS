package com.malkarlms.app

data class CourseModule(
    val id: Int,
    val moduleNumber: Int,
    val title: String,
    val description: String,
    val duration: String,
    val isCompleted: Boolean = false,
    val progress: Int = 0, // 0-100
    val videoUrl: String = "",
    val documentsCount: Int = 0,
    val quizScore: Int? = null, // null if not attempted, 0-100 if attempted
    val lectures: List<Lecture> = emptyList(),
    val isLocked: Boolean = false
)

data class Lecture(
    val id: Int,
    val title: String,
    val duration: String,
    val type: LectureType,
    val isCompleted: Boolean = false,
    val isFree: Boolean = false // Some lectures can be previewed for free
)

enum class LectureType {
    VIDEO,
    READING,
    QUIZ,
    ASSIGNMENT,
    RESOURCE
}

data class Assignment(
    val id: Int,
    val title: String,
    val description: String,
    val dueDate: String,
    val status: AssignmentStatus,
    val score: Int? = null, // null if not graded
    val maxScore: Int = 100,
    val submittedDate: String? = null
)

enum class AssignmentStatus {
    NOT_STARTED,
    IN_PROGRESS,
    SUBMITTED,
    GRADED,
    OVERDUE
}

data class CourseProgress(
    val courseId: Int,
    val courseTitle: String,
    val courseImage: String,
    val instructor: String,
    val overallProgress: Int, // 0-100
    val completedModules: Int,
    val totalModules: Int,
    val completedAssignments: Int,
    val totalAssignments: Int,
    val averageScore: Float,
    val timeSpent: String, // e.g., "12h 30m"
    val lastAccessed: String,
    val modules: List<CourseModule>,
    val assignments: List<Assignment>
)
