package com.malkarlms.app

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query

class InstructorCoursesActivity : AppCompatActivity() {
    
    private lateinit var toolbar: Toolbar
    private lateinit var recyclerViewCourses: RecyclerView
    private lateinit var layoutEmptyState: LinearLayout
    private lateinit var fabAddCourse: FloatingActionButton
    
    private lateinit var firestore: FirebaseFirestore
    private lateinit var auth: FirebaseAuth
    private lateinit var instructorCoursesAdapter: InstructorCoursesAdapter
    private val coursesList = mutableListOf<InstructorCourse>()
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        try {
            setContentView(R.layout.activity_instructor_courses)
            
            initFirebase()
            initViews()
            setupToolbar()
            setupRecyclerView()
            setupFab()
            loadCourses()
        } catch (e: Exception) {
            Log.e("InstructorCourses", "Error in onCreate: ${e.message}", e)
            // Show error and finish activity
            android.widget.Toast.makeText(this, "Error loading instructor courses: ${e.message}", android.widget.Toast.LENGTH_LONG).show()
            finish()
        }
    }
    
    private fun initFirebase() {
        firestore = FirebaseFirestore.getInstance()
        auth = FirebaseAuth.getInstance()
    }
    
    private fun initViews() {
        toolbar = findViewById(R.id.toolbar)
        recyclerViewCourses = findViewById(R.id.recyclerViewCourses)
        layoutEmptyState = findViewById(R.id.tvEmptyState)
        fabAddCourse = findViewById(R.id.fabAddCourse)
    }
    
    private fun setupToolbar() {
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "My Courses"
    }
    
    private fun setupRecyclerView() {
        try {
            instructorCoursesAdapter = InstructorCoursesAdapter(coursesList) { course ->
                onCourseClicked(course)
            }
            recyclerViewCourses.apply {
                layoutManager = LinearLayoutManager(this@InstructorCoursesActivity)
                adapter = instructorCoursesAdapter
            }
            Log.d("InstructorCourses", "RecyclerView setup completed")
        } catch (e: Exception) {
            Log.e("InstructorCourses", "Error setting up RecyclerView: ${e.message}", e)
            android.widget.Toast.makeText(this, "Error setting up course list", android.widget.Toast.LENGTH_SHORT).show()
        }
    }
    
    private fun setupFab() {
        fabAddCourse.setOnClickListener {
            startActivity(Intent(this, CourseCreationActivity::class.java))
        }
        
        // Add long click for debugging
        fabAddCourse.setOnLongClickListener {
            testFirebaseConnection()
            true
        }
    }
    
    private fun testFirebaseConnection() {
        val currentUser = auth.currentUser
        if (currentUser == null) {
            android.widget.Toast.makeText(this, "No user logged in", android.widget.Toast.LENGTH_SHORT).show()
            return
        }
        
        Log.d("InstructorCourses", "Testing Firebase connection for user: ${currentUser.uid}")
        
        // Test reading all courses
        firestore.collection("courses")
            .get()
            .addOnSuccessListener { documents ->
                Log.d("InstructorCourses", "Total courses in database: ${documents.size()}")
                android.widget.Toast.makeText(this, "Total courses in DB: ${documents.size()}", android.widget.Toast.LENGTH_SHORT).show()
                
                // Count courses for this instructor
                val instructorCourses = documents.filter { 
                    it.data["instructorId"] == currentUser.uid 
                }
                Log.d("InstructorCourses", "Courses for this instructor: ${instructorCourses.size}")
                android.widget.Toast.makeText(this, "Your courses: ${instructorCourses.size}", android.widget.Toast.LENGTH_SHORT).show()
            }
            .addOnFailureListener { e ->
                Log.e("InstructorCourses", "Firebase test failed: ${e.message}", e)
                android.widget.Toast.makeText(this, "Firebase error: ${e.message}", android.widget.Toast.LENGTH_LONG).show()
            }
    }
    
    private fun loadCourses() {
        val currentUser = auth.currentUser
        if (currentUser == null) {
            Log.w("InstructorCourses", "User not logged in")
            return
        }
        
        Log.d("InstructorCourses", "Loading courses for user: ${currentUser.uid}")
        
        firestore.collection("courses")
            .whereEqualTo("instructorId", currentUser.uid)
            .get()
            .addOnSuccessListener { documents ->
                coursesList.clear()
                
                Log.d("InstructorCourses", "Found ${documents.size()} courses")
                
                for (document in documents) {
                    val courseData = document.data
                    coursesList.add(
                        InstructorCourse(
                            id = document.id,
                            title = courseData["title"] as? String ?: "Unknown Course",
                            description = courseData["description"] as? String ?: "",
                            price = courseData["price"] as? String ?: "₹0",
                            duration = courseData["duration"] as? String ?: "",
                            category = courseData["category"] as? String ?: "",
                            enrollmentCount = (courseData["enrollmentCount"] as? Long)?.toInt() ?: 0,
                            views = (courseData["views"] as? Long)?.toInt() ?: 0,
                            rating = courseData["rating"] as? Double ?: 0.0,
                            reviewCount = (courseData["reviewCount"] as? Long)?.toInt() ?: 0,
                            isDraft = courseData["isDraft"] as? Boolean ?: true,
                            createdAt = courseData["createdAt"] as? Long ?: 0L
                        )
                    )
                    Log.d("InstructorCourses", "Added course: ${courseData["title"]}")
                }
                
                Log.d("InstructorCourses", "Total courses loaded: ${coursesList.size}")
                updateUI()
                instructorCoursesAdapter.notifyDataSetChanged()
            }
            .addOnFailureListener { e ->
                Log.e("InstructorCourses", "Error loading courses: ${e.message}", e)
                android.widget.Toast.makeText(this, "Error loading courses: ${e.message}", android.widget.Toast.LENGTH_LONG).show()
                updateUI()
            }
    }
    
    private fun updateUI() {
        if (coursesList.isEmpty()) {
            recyclerViewCourses.visibility = View.GONE
            layoutEmptyState.visibility = View.VISIBLE
        } else {
            recyclerViewCourses.visibility = View.VISIBLE
            layoutEmptyState.visibility = View.GONE
        }
    }
    
    private fun onCourseClicked(course: InstructorCourse) {
        // Navigate to course details or edit screen
        val intent = Intent(this, CourseDetailsActivity::class.java)
        intent.putExtra("COURSE_ID", course.id)
        intent.putExtra("COURSE_TITLE", course.title)
        intent.putExtra("COURSE_DESCRIPTION", course.description)
        intent.putExtra("COURSE_DURATION", course.duration)
        intent.putExtra("COURSE_PRICE", course.price)
        startActivity(intent)
    }
    
    override fun onResume() {
        super.onResume()
        Log.d("InstructorCourses", "onResume called - refreshing courses")
        loadCourses() // Refresh courses when returning to this activity
    }
    
    override fun onSupportNavigateUp(): Boolean {
        onBackPressedDispatcher.onBackPressed()
        return true
    }
}

// Data class for instructor course
data class InstructorCourse(
    val id: String,
    val title: String,
    val description: String,
    val price: String,
    val duration: String,
    val category: String,
    val enrollmentCount: Int,
    val views: Int,
    val rating: Double,
    val reviewCount: Int,
    val isDraft: Boolean,
    val createdAt: Long
)
