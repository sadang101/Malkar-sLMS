package com.malkarlms.app

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MyProgressActivity : AppCompatActivity() {
    
    override fun attachBaseContext(newBase: Context) {
        val languageCode = LocaleHelper.getLanguage(newBase)
        val context = LocaleHelper.setLocale(newBase, languageCode)
        super.attachBaseContext(context)
    }

    private lateinit var btnBack: TextView
    private lateinit var tvCoursesCount: TextView
    private lateinit var tvModulesCount: TextView
    private lateinit var tvAverageScore: TextView
    private lateinit var spinnerCourses: Spinner
    private lateinit var courseDetailsContainer: View
    private lateinit var emptyStateContainer: View
    private lateinit var btnBrowseCourses: Button
    
    // Course details views
    private lateinit var tvCourseTitle: TextView
    private lateinit var tvInstructor: TextView
    private lateinit var progressBar: ProgressBar
    private lateinit var tvProgressPercent: TextView
    private lateinit var tvProgressDetails: TextView
    private lateinit var tvTimeSpent: TextView
    private lateinit var tvLastAccessed: TextView
    private lateinit var rvModules: RecyclerView
    private lateinit var rvAssignments: RecyclerView
    
    private var courseProgressList = mutableListOf<CourseProgress>()
    private var selectedCourseProgress: CourseProgress? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_my_progress)
        
        initViews()
        loadSampleData()
        setupUI()
    }

    private fun initViews() {
        btnBack = findViewById(R.id.btnBack)
        tvCoursesCount = findViewById(R.id.tvCoursesCount)
        tvModulesCount = findViewById(R.id.tvModulesCount)
        tvAverageScore = findViewById(R.id.tvAverageScore)
        spinnerCourses = findViewById(R.id.spinnerCourses)
        courseDetailsContainer = findViewById(R.id.courseDetailsContainer)
        emptyStateContainer = findViewById(R.id.emptyStateContainer)
        btnBrowseCourses = findViewById(R.id.btnBrowseCourses)
        
        tvCourseTitle = findViewById(R.id.tvCourseTitle)
        tvInstructor = findViewById(R.id.tvInstructor)
        progressBar = findViewById(R.id.progressBar)
        tvProgressPercent = findViewById(R.id.tvProgressPercent)
        tvProgressDetails = findViewById(R.id.tvProgressDetails)
        tvTimeSpent = findViewById(R.id.tvTimeSpent)
        tvLastAccessed = findViewById(R.id.tvLastAccessed)
        rvModules = findViewById(R.id.rvModules)
        rvAssignments = findViewById(R.id.rvAssignments)
        
        btnBack.setOnClickListener { finish() }
        btnBrowseCourses.setOnClickListener {
            startActivity(Intent(this, MoreCoursesActivity::class.java))
            finish()
        }
    }

    private fun loadSampleData() {
        // Sample Course 1: Android Development
        val androidModules = listOf(
            CourseModule(1, 1, "Introduction to Android", "Learn Android basics and setup", "45 min", true, 100, "", 3, 92),
            CourseModule(2, 2, "Activities and Intents", "Understanding Android components", "60 min", true, 100, "", 5, 88),
            CourseModule(3, 3, "Layouts and UI Design", "Creating beautiful user interfaces", "75 min", true, 100, "", 4, 95),
            CourseModule(4, 4, "RecyclerView and Adapters", "Working with lists and grids", "50 min", false, 65, "", 2, null),
            CourseModule(5, 5, "Firebase Integration", "Backend as a Service", "90 min", false, 30, "", 6, null),
            CourseModule(6, 6, "Material Design", "Modern UI principles", "55 min", false, 0, "", 3, null),
            CourseModule(7, 7, "Networking and APIs", "REST API integration", "70 min", false, 0, "", 4, null),
            CourseModule(8, 8, "Local Database (Room)", "Data persistence", "65 min", false, 0, "", 5, null),
            CourseModule(9, 9, "Testing and Debugging", "Quality assurance", "50 min", false, 0, "", 2, null),
            CourseModule(10, 10, "Publishing Your App", "Google Play Store", "40 min", false, 0, "", 3, null)
        )
        
        val androidAssignments = listOf(
            Assignment(1, "Build a Calculator App", "Create a functional calculator with basic operations", "Dec 15, 2024", AssignmentStatus.GRADED, 92, 100, "Dec 10, 2024"),
            Assignment(2, "Todo List Application", "Implement CRUD operations with local storage", "Dec 20, 2024", AssignmentStatus.SUBMITTED, null, 100, "Dec 18, 2024"),
            Assignment(3, "Weather App with API", "Integrate weather API and display data", "Dec 25, 2024", AssignmentStatus.IN_PROGRESS, null, 100, null),
            Assignment(4, "Final Project: E-commerce App", "Build a complete shopping app", "Jan 5, 2025", AssignmentStatus.NOT_STARTED, null, 100, null)
        )
        
        courseProgressList.add(
            CourseProgress(
                1,
                "Android App Development",
                "",
                "Dr. Sarah Johnson",
                35,
                3,
                10,
                2,
                4,
                91.7f,
                "12h 30m",
                "2 hours ago",
                androidModules,
                androidAssignments
            )
        )
        
        // Sample Course 2: Web Development
        val webModules = listOf(
            CourseModule(1, 1, "HTML Fundamentals", "Structure of web pages", "40 min", true, 100, "", 2, 95),
            CourseModule(2, 2, "CSS Styling", "Making websites beautiful", "55 min", true, 100, "", 4, 90),
            CourseModule(3, 3, "JavaScript Basics", "Adding interactivity", "70 min", false, 45, "", 5, null),
            CourseModule(4, 4, "Responsive Design", "Mobile-first approach", "50 min", false, 0, "", 3, null),
            CourseModule(5, 5, "React Framework", "Modern web development", "80 min", false, 0, "", 6, null),
            CourseModule(6, 6, "Node.js Backend", "Server-side JavaScript", "75 min", false, 0, "", 4, null),
            CourseModule(7, 7, "Database Integration", "MongoDB basics", "60 min", false, 0, "", 3, null),
            CourseModule(8, 8, "Authentication", "User login systems", "65 min", false, 0, "", 5, null)
        )
        
        val webAssignments = listOf(
            Assignment(1, "Personal Portfolio Website", "Create your portfolio with HTML/CSS", "Dec 12, 2024", AssignmentStatus.GRADED, 88, 100, "Dec 8, 2024"),
            Assignment(2, "Interactive Quiz App", "Build a quiz with JavaScript", "Dec 18, 2024", AssignmentStatus.IN_PROGRESS, null, 100, null),
            Assignment(3, "Blog Platform", "Full-stack blog application", "Dec 28, 2024", AssignmentStatus.NOT_STARTED, null, 100, null)
        )
        
        courseProgressList.add(
            CourseProgress(
                2,
                "Full Stack Web Development",
                "",
                "Prof. Michael Chen",
                20,
                2,
                8,
                1,
                3,
                92.5f,
                "8h 15m",
                "1 day ago",
                webModules,
                webAssignments
            )
        )
    }

    private fun setupUI() {
        if (courseProgressList.isEmpty()) {
            // Show empty state
            emptyStateContainer.visibility = View.VISIBLE
            courseDetailsContainer.visibility = View.GONE
            spinnerCourses.visibility = View.GONE
            
            tvCoursesCount.text = "0"
            tvModulesCount.text = "0"
            tvAverageScore.text = "0%"
        } else {
            // Show course data
            emptyStateContainer.visibility = View.GONE
            spinnerCourses.visibility = View.VISIBLE
            
            // Calculate overall stats
            val totalCourses = courseProgressList.size
            val totalModulesCompleted = courseProgressList.sumOf { it.completedModules }
            val avgScore = if (courseProgressList.isNotEmpty()) {
                courseProgressList.map { it.averageScore }.average().toInt()
            } else 0
            
            tvCoursesCount.text = totalCourses.toString()
            tvModulesCount.text = totalModulesCompleted.toString()
            tvAverageScore.text = "$avgScore%"
            
            // Setup course spinner
            val courseNames = courseProgressList.map { it.courseTitle }
            val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, courseNames)
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            spinnerCourses.adapter = adapter
            
            spinnerCourses.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                    selectedCourseProgress = courseProgressList.getOrNull(position)
                    displayCourseDetails()
                }
                
                override fun onNothingSelected(parent: AdapterView<*>?) {
                    selectedCourseProgress = null
                }
            }
            
            // Select first course by default
            selectedCourseProgress = courseProgressList.firstOrNull()
            displayCourseDetails()
        }
    }

    private fun displayCourseDetails() {
        selectedCourseProgress?.let { course ->
            courseDetailsContainer.visibility = View.VISIBLE
            
            // Course info
            tvCourseTitle.text = course.courseTitle
            tvInstructor.text = "👨‍🏫 ${course.instructor}"
            
            // Progress
            progressBar.progress = course.overallProgress
            tvProgressPercent.text = "${course.overallProgress}%"
            tvProgressDetails.text = "${course.completedModules}/${course.totalModules} modules completed"
            
            // Stats
            tvTimeSpent.text = course.timeSpent
            tvLastAccessed.text = course.lastAccessed
            
            // Setup Modules RecyclerView (only once)
            if (rvModules.layoutManager == null) {
                rvModules.layoutManager = LinearLayoutManager(this)
            }
            rvModules.adapter = ModuleAdapter(course.modules) { module ->
                Toast.makeText(this, "Module: ${module.title}", Toast.LENGTH_SHORT).show()
                // TODO: Navigate to module details
            }
            
            // Setup Assignments RecyclerView (only once)
            if (rvAssignments.layoutManager == null) {
                rvAssignments.layoutManager = LinearLayoutManager(this)
            }
            rvAssignments.adapter = AssignmentAdapter(course.assignments) { assignment ->
                Toast.makeText(this, "Assignment: ${assignment.title}", Toast.LENGTH_SHORT).show()
                // TODO: Navigate to assignment details
            }
        }
    }
}
