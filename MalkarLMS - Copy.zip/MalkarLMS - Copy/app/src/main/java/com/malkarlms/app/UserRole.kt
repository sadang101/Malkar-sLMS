package com.malkarlms.app

/**
 * Enum representing different user roles in the MalkarLMS system
 */
enum class UserRole {
    STUDENT,
    INSTRUCTOR,
    ADMIN
}
