// DELETE THIS FILE - Empty placeholder file created by mistake
// All functionality is in CourseFile.kt