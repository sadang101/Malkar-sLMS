package com.malkarlms.app

/**
 * Helper class to generate sample course modules and syllabus data
 */
object CourseDataHelper {
    
    fun getModulesForCourse(courseId: Int, courseTitle: String): List<CourseModule> {
        return when {
            courseTitle.contains("Python", ignoreCase = true) -> getPythonModules()
            courseTitle.contains("Web Development", ignoreCase = true) -> getWebDevModules()
            courseTitle.contains("Data Science", ignoreCase = true) -> getDataScienceModules()
            courseTitle.contains("Android", ignoreCase = true) -> getAndroidModules()
            courseTitle.contains("Marketing", ignoreCase = true) -> getMarketingModules()
            else -> getGenericModules()
        }
    }
    
    private fun getPythonModules(): List<CourseModule> {
        return listOf(
            CourseModule(
                id = 1,
                moduleNumber = 1,
                title = "Python Fundamentals",
                description = "Learn Python basics, syntax, variables, and data types",
                duration = "2 weeks",
                lectures = listOf(
                    Lecture(1, "Introduction to Python", "15 min", LectureType.VIDEO, isFree = true),
                    Lecture(2, "Installing Python & IDE Setup", "20 min", LectureType.VIDEO, isFree = true),
                    Lecture(3, "Variables and Data Types", "25 min", LectureType.VIDEO),
                    Lecture(4, "Operators and Expressions", "30 min", LectureType.VIDEO),
                    Lecture(5, "Practice Exercise", "45 min", LectureType.ASSIGNMENT)
                )
            ),
            CourseModule(
                id = 2,
                moduleNumber = 2,
                title = "Control Flow & Functions",
                description = "Master conditional statements, loops, and function creation",
                duration = "2 weeks",
                lectures = listOf(
                    Lecture(6, "If-Else Statements", "20 min", LectureType.VIDEO),
                    Lecture(7, "Loops: For and While", "25 min", LectureType.VIDEO),
                    Lecture(8, "Functions and Parameters", "30 min", LectureType.VIDEO),
                    Lecture(9, "Lambda Functions", "20 min", LectureType.VIDEO),
                    Lecture(10, "Module Quiz", "30 min", LectureType.QUIZ)
                )
            ),
            CourseModule(
                id = 3,
                moduleNumber = 3,
                title = "Data Structures",
                description = "Work with lists, tuples, dictionaries, and sets",
                duration = "2 weeks",
                lectures = listOf(
                    Lecture(11, "Lists and List Methods", "30 min", LectureType.VIDEO),
                    Lecture(12, "Tuples and Sets", "25 min", LectureType.VIDEO),
                    Lecture(13, "Dictionaries", "30 min", LectureType.VIDEO),
                    Lecture(14, "List Comprehensions", "20 min", LectureType.VIDEO),
                    Lecture(15, "Data Structures Project", "60 min", LectureType.ASSIGNMENT)
                )
            ),
            CourseModule(
                id = 4,
                moduleNumber = 4,
                title = "Object-Oriented Programming",
                description = "Learn classes, objects, inheritance, and polymorphism",
                duration = "2 weeks",
                lectures = listOf(
                    Lecture(16, "Classes and Objects", "35 min", LectureType.VIDEO),
                    Lecture(17, "Inheritance", "30 min", LectureType.VIDEO),
                    Lecture(18, "Polymorphism", "25 min", LectureType.VIDEO),
                    Lecture(19, "Encapsulation", "20 min", LectureType.VIDEO),
                    Lecture(20, "OOP Project", "90 min", LectureType.ASSIGNMENT)
                )
            ),
            CourseModule(
                id = 5,
                moduleNumber = 5,
                title = "Django Web Framework",
                description = "Build web applications with Django",
                duration = "4 weeks",
                lectures = listOf(
                    Lecture(21, "Django Introduction", "20 min", LectureType.VIDEO),
                    Lecture(22, "Setting Up Django Project", "30 min", LectureType.VIDEO),
                    Lecture(23, "Models and Database", "40 min", LectureType.VIDEO),
                    Lecture(24, "Views and Templates", "45 min", LectureType.VIDEO),
                    Lecture(25, "Django Admin Panel", "25 min", LectureType.VIDEO),
                    Lecture(26, "Building a Blog Application", "120 min", LectureType.ASSIGNMENT)
                )
            )
        )
    }
    
    private fun getWebDevModules(): List<CourseModule> {
        return listOf(
            CourseModule(1, 1, "HTML & CSS Basics", "Learn the foundation of web development", "2 weeks",
                lectures = listOf(
                    Lecture(1, "HTML Structure", "20 min", LectureType.VIDEO, isFree = true),
                    Lecture(2, "CSS Styling", "25 min", LectureType.VIDEO, isFree = true),
                    Lecture(3, "Responsive Design", "30 min", LectureType.VIDEO),
                    Lecture(4, "Flexbox & Grid", "35 min", LectureType.VIDEO)
                )),
            CourseModule(2, 2, "JavaScript Fundamentals", "Master JavaScript programming", "3 weeks",
                lectures = listOf(
                    Lecture(5, "JS Basics", "30 min", LectureType.VIDEO),
                    Lecture(6, "DOM Manipulation", "40 min", LectureType.VIDEO),
                    Lecture(7, "Events & Async", "45 min", LectureType.VIDEO)
                )),
            CourseModule(3, 3, "React.js", "Build modern UIs with React", "4 weeks",
                lectures = listOf(
                    Lecture(8, "React Components", "35 min", LectureType.VIDEO),
                    Lecture(9, "State & Props", "40 min", LectureType.VIDEO),
                    Lecture(10, "Hooks", "45 min", LectureType.VIDEO)
                )),
            CourseModule(4, 4, "Node.js & Express", "Backend development", "3 weeks",
                lectures = listOf(
                    Lecture(11, "Node.js Basics", "30 min", LectureType.VIDEO),
                    Lecture(12, "Express Server", "40 min", LectureType.VIDEO),
                    Lecture(13, "REST APIs", "50 min", LectureType.VIDEO)
                )),
            CourseModule(5, 5, "MongoDB & Deployment", "Database and hosting", "2 weeks",
                lectures = listOf(
                    Lecture(14, "MongoDB Basics", "35 min", LectureType.VIDEO),
                    Lecture(15, "Deployment", "40 min", LectureType.VIDEO)
                ))
        )
    }
    
    private fun getDataScienceModules(): List<CourseModule> {
        return listOf(
            CourseModule(1, 1, "Python for Data Science", "Python libraries for data analysis", "2 weeks",
                lectures = listOf(
                    Lecture(1, "NumPy Basics", "30 min", LectureType.VIDEO, isFree = true),
                    Lecture(2, "Pandas DataFrames", "40 min", LectureType.VIDEO),
                    Lecture(3, "Data Cleaning", "35 min", LectureType.VIDEO)
                )),
            CourseModule(2, 2, "Data Visualization", "Create insightful visualizations", "2 weeks",
                lectures = listOf(
                    Lecture(4, "Matplotlib", "30 min", LectureType.VIDEO),
                    Lecture(5, "Seaborn", "35 min", LectureType.VIDEO)
                )),
            CourseModule(3, 3, "Statistics & Probability", "Statistical analysis fundamentals", "2 weeks",
                lectures = listOf(
                    Lecture(6, "Descriptive Statistics", "40 min", LectureType.VIDEO),
                    Lecture(7, "Probability", "45 min", LectureType.VIDEO)
                )),
            CourseModule(4, 4, "Machine Learning", "Build predictive models", "4 weeks",
                lectures = listOf(
                    Lecture(8, "Supervised Learning", "50 min", LectureType.VIDEO),
                    Lecture(9, "Unsupervised Learning", "45 min", LectureType.VIDEO),
                    Lecture(10, "Model Evaluation", "40 min", LectureType.VIDEO)
                )),
            CourseModule(5, 5, "Deep Learning", "Neural networks and AI", "4 weeks",
                lectures = listOf(
                    Lecture(11, "Neural Networks", "60 min", LectureType.VIDEO),
                    Lecture(12, "TensorFlow", "55 min", LectureType.VIDEO)
                ))
        )
    }
    
    private fun getAndroidModules(): List<CourseModule> {
        return listOf(
            CourseModule(1, 1, "Kotlin Basics", "Learn Kotlin programming", "2 weeks",
                lectures = listOf(
                    Lecture(1, "Kotlin Syntax", "25 min", LectureType.VIDEO, isFree = true),
                    Lecture(2, "Functions & Classes", "30 min", LectureType.VIDEO)
                )),
            CourseModule(2, 2, "Android UI", "Build beautiful interfaces", "3 weeks",
                lectures = listOf(
                    Lecture(3, "Layouts", "35 min", LectureType.VIDEO),
                    Lecture(4, "Material Design", "40 min", LectureType.VIDEO)
                )),
            CourseModule(3, 3, "Activities & Fragments", "App navigation", "2 weeks",
                lectures = listOf(
                    Lecture(5, "Activities", "30 min", LectureType.VIDEO),
                    Lecture(6, "Fragments", "35 min", LectureType.VIDEO)
                )),
            CourseModule(4, 4, "Firebase Integration", "Backend services", "2 weeks",
                lectures = listOf(
                    Lecture(7, "Firebase Auth", "40 min", LectureType.VIDEO),
                    Lecture(8, "Firestore Database", "45 min", LectureType.VIDEO)
                )),
            CourseModule(5, 5, "Publishing Apps", "Deploy to Play Store", "1 week",
                lectures = listOf(
                    Lecture(9, "App Signing", "30 min", LectureType.VIDEO),
                    Lecture(10, "Play Store Upload", "35 min", LectureType.VIDEO)
                ))
        )
    }
    
    private fun getMarketingModules(): List<CourseModule> {
        return listOf(
            CourseModule(1, 1, "Digital Marketing Basics", "Introduction to online marketing", "1 week",
                lectures = listOf(
                    Lecture(1, "Marketing Overview", "20 min", LectureType.VIDEO, isFree = true),
                    Lecture(2, "Digital Channels", "25 min", LectureType.VIDEO)
                )),
            CourseModule(2, 2, "SEO Mastery", "Search engine optimization", "2 weeks",
                lectures = listOf(
                    Lecture(3, "On-Page SEO", "30 min", LectureType.VIDEO),
                    Lecture(4, "Off-Page SEO", "35 min", LectureType.VIDEO)
                )),
            CourseModule(3, 3, "Social Media Marketing", "Grow on social platforms", "2 weeks",
                lectures = listOf(
                    Lecture(5, "Facebook Marketing", "30 min", LectureType.VIDEO),
                    Lecture(6, "Instagram Strategy", "35 min", LectureType.VIDEO)
                )),
            CourseModule(4, 4, "Content Marketing", "Create engaging content", "2 weeks",
                lectures = listOf(
                    Lecture(7, "Content Strategy", "40 min", LectureType.VIDEO),
                    Lecture(8, "Copywriting", "35 min", LectureType.VIDEO)
                )),
            CourseModule(5, 5, "Analytics & ROI", "Measure marketing success", "1 week",
                lectures = listOf(
                    Lecture(9, "Google Analytics", "45 min", LectureType.VIDEO),
                    Lecture(10, "ROI Calculation", "30 min", LectureType.VIDEO)
                ))
        )
    }
    
    private fun getGenericModules(): List<CourseModule> {
        return listOf(
            CourseModule(1, 1, "Introduction", "Course overview and setup", "1 week",
                lectures = listOf(
                    Lecture(1, "Welcome", "15 min", LectureType.VIDEO, isFree = true),
                    Lecture(2, "Course Overview", "20 min", LectureType.VIDEO, isFree = true)
                )),
            CourseModule(2, 2, "Fundamentals", "Core concepts", "2 weeks",
                lectures = listOf(
                    Lecture(3, "Basic Concepts", "30 min", LectureType.VIDEO),
                    Lecture(4, "Practice", "45 min", LectureType.ASSIGNMENT)
                )),
            CourseModule(3, 3, "Advanced Topics", "Deep dive into advanced concepts", "3 weeks",
                lectures = listOf(
                    Lecture(5, "Advanced Techniques", "40 min", LectureType.VIDEO),
                    Lecture(6, "Project Work", "90 min", LectureType.ASSIGNMENT)
                )),
            CourseModule(4, 4, "Final Project", "Apply your knowledge", "2 weeks",
                lectures = listOf(
                    Lecture(7, "Project Guidelines", "20 min", LectureType.READING),
                    Lecture(8, "Final Project", "120 min", LectureType.ASSIGNMENT)
                ))
        )
    }
}
