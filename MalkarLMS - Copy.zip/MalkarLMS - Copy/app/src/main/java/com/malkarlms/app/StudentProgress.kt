package com.malkarlms.app

/**
 * Data class representing a student's progress in a course
 */
data class StudentProgress(
    val studentId: String = "",
    val studentName: String = "",
    val studentEmail: String = "",
    val courseId: String = "",
    val courseName: String = "",
    val enrolledAt: Long = 0,
    val overallProgress: Float = 0f, // 0-100
    val completedModules: Int = 0,
    val totalModules: Int = 0,
    val lastAccessedAt: Long = 0,
    val moduleProgress: Map<String, ModuleProgress> = emptyMap()
)

/**
 * Data class representing progress in a specific module
 */
data class ModuleProgress(
    val moduleId: String = "",
    val moduleName: String = "",
    val difficulty: String = "Medium", // Easy, Medium, Hard
    val completionPercentage: Float = 0f, // 0-100
    val timeSpent: Long = 0, // in milliseconds
    val isCompleted: Boolean = false,
    val lastAccessedAt: Long = 0,
    val quizScore: Float = 0f // 0-100
)

/**
 * Data class for aggregated analytics
 */
data class StudentAnalytics(
    val totalStudents: Int = 0,
    val averageProgress: Float = 0f,
    val activeStudents: Int = 0, // Students who accessed in last 7 days
    val completionRate: Float = 0f,
    val moduleDifficultyStats: Map<String, DifficultyStats> = emptyMap()
)

/**
 * Data class for module difficulty statistics
 */
data class DifficultyStats(
    val moduleName: String = "",
    val difficulty: String = "Medium",
    val averageCompletionTime: Long = 0,
    val averageScore: Float = 0f,
    val completionRate: Float = 0f,
    val studentCount: Int = 0
)
