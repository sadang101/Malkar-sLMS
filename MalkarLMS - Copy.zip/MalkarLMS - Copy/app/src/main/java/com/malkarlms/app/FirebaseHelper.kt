package com.malkarlms.app

import android.util.Log
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

object FirebaseHelper {
    
    private const val TAG = "FirebaseHelper"
    
    /**
     * Check if user is authenticated
     */
    fun isUserAuthenticated(): Boolean {
        return FirebaseAuth.getInstance().currentUser != null
    }
    

    fun getCurrentUserId(): String? {
        return FirebaseAuth.getInstance().currentUser?.uid
    }
    

    fun getCurrentUserEmail(): String? {
        return FirebaseAuth.getInstance().currentUser?.email
    }
    

    fun getCurrentUserDisplayName(): String? {
        return FirebaseAuth.getInstance().currentUser?.displayName
    }
    
    /**
     * Safe Firebase operation wrapper
     */
    fun <T> safeFirebaseOperation(
        operation: () -> T,
        onError: (Exception) -> Unit = { e -> Log.e(TAG, "Firebase operation failed: ${e.message}", e) }
    ): T? {
        return try {
            operation()
        } catch (e: Exception) {
            onError(e)
            null
        }
    }
    
    /**
     * Check if Firestore is available
     */
    fun isFirestoreAvailable(): Boolean {
        return try {
            FirebaseFirestore.getInstance()
            true
        } catch (e: Exception) {
            Log.e(TAG, "Firestore not available: ${e.message}", e)
            false
        }
    }
    
    /**
     * Validate required fields for course creation
     */
    fun validateCourseData(
        title: String,
        description: String,
        duration: String,
        price: String,
        category: String,
        difficulty: String
    ): String? {
        return when {
            title.isBlank() -> "Course title is required"
            description.isBlank() -> "Course description is required"
            duration.isBlank() -> "Course duration is required"
            price.isBlank() -> "Course price is required"
            category == "Select Category" -> "Please select a category"
            difficulty == "Select Difficulty" -> "Please select difficulty level"
            else -> null
        }
    }
    
    /**
     * Validate user profile data
     */
    fun validateProfileData(
        fullName: String,
        email: String
    ): String? {
        return when {
            fullName.isBlank() -> "Full name is required"
            email.isBlank() -> "Email is required"
            !android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches() -> "Invalid email format"
            else -> null // All validations passed
        }
    }
}
