package com.malkarlms.app

import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class CartActivity : AppCompatActivity() {
    
    private lateinit var recyclerView: RecyclerView
    private lateinit var emptyCartLayout: LinearLayout
    private lateinit var tvSubtotal: TextView
    private lateinit var tvPlatformFee: TextView
    private lateinit var tvGst: TextView
    private lateinit var tvTotalPrice: TextView
    private lateinit var btnCheckout: Button
    private lateinit var cartAdapter: CartAdapter
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        try {
            setContentView(R.layout.activity_cart)
            
            setupToolbar()
            initViews()
            setupRecyclerView()
            updateUI()
        } catch (e: Exception) {
            Log.e("CartActivity", "Error in onCreate: ${e.message}", e)
            Toast.makeText(this, "Error loading cart: ${e.message}", Toast.LENGTH_LONG).show()
            finish()
        }
    }
    
    private fun setupToolbar() {
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "My Cart"
    }
    
    private fun initViews() {
        try {
            recyclerView = findViewById(R.id.recyclerViewCart)
            emptyCartLayout = findViewById(R.id.tvEmptyCart)
            tvSubtotal = findViewById(R.id.tvSubtotal)
            tvPlatformFee = findViewById(R.id.tvPlatformFee)
            tvGst = findViewById(R.id.tvGst)
            tvTotalPrice = findViewById(R.id.tvTotalPrice)
            btnCheckout = findViewById(R.id.btnCheckout)
            
            btnCheckout.setOnClickListener {
                try {
                    if (CartManager.getCartItemCount() > 0) {
                        // Navigate to checkout with cart items
                        val intent = android.content.Intent(this, CheckoutActivity::class.java)
                        intent.putExtra("IS_SINGLE_COURSE", false) // Multiple courses from cart
                        startActivity(intent)
                    } else {
                        Toast.makeText(this, "Your cart is empty", Toast.LENGTH_SHORT).show()
                    }
                } catch (e: Exception) {
                    Log.e("CartActivity", "Error in checkout click: ${e.message}", e)
                    Toast.makeText(this, "Error processing checkout", Toast.LENGTH_SHORT).show()
                }
            }
            
            Log.d("CartActivity", "Views initialized successfully")
        } catch (e: Exception) {
            Log.e("CartActivity", "Error initializing views: ${e.message}", e)
            Toast.makeText(this, "Error loading cart interface", Toast.LENGTH_SHORT).show()
            finish()
        }
    }
    
    private fun setupRecyclerView() {
        try {
            val cartItems = CartManager.getCartItems()
            Log.d("CartActivity", "Setting up RecyclerView with ${cartItems.size} items")
            
            cartAdapter = CartAdapter(cartItems) { course ->
                Log.d("CartActivity", "Removing course: ${course.title}")
                CartManager.removeFromCart(course.id)
                updateUI()
                Toast.makeText(this, "${course.title} removed from cart", Toast.LENGTH_SHORT).show()
            }
            
            recyclerView.apply {
                layoutManager = LinearLayoutManager(this@CartActivity)
                adapter = cartAdapter
            }
            
            Log.d("CartActivity", "RecyclerView setup completed")
        } catch (e: Exception) {
            Log.e("CartActivity", "Error setting up RecyclerView: ${e.message}", e)
            Toast.makeText(this, "Error setting up cart list", Toast.LENGTH_SHORT).show()
        }
    }
    
    private fun updateUI() {
        try {
            val cartItems = CartManager.getCartItems()
            Log.d("CartActivity", "Updating UI with ${cartItems.size} items")
            
            if (cartItems.isEmpty()) {
                recyclerView.visibility = android.view.View.GONE
                emptyCartLayout.visibility = android.view.View.VISIBLE
                btnCheckout.isEnabled = false
                
                // Reset all prices to 0
                tvSubtotal.text = "₹0"
                tvPlatformFee.text = "₹0"
                tvGst.text = "₹0"
                tvTotalPrice.text = "₹0"
                
                Log.d("CartActivity", "Cart is empty, showing empty state")
            } else {
                recyclerView.visibility = android.view.View.VISIBLE
                emptyCartLayout.visibility = android.view.View.GONE
                btnCheckout.isEnabled = true
                
                // Calculate price breakdown using CartManager
                val subtotal = CartManager.getSubtotal()
                val platformFee = if (subtotal > 0) 7 else 0 // ₹7 platform fee
                val gstAmount = ((subtotal + platformFee) * 0.18).toInt() // 18% GST
                val total = subtotal + platformFee + gstAmount
                
                Log.d("CartActivity", "Price calculation - Subtotal: $subtotal, Platform: $platformFee, GST: $gstAmount, Total: $total")
                
                // Update UI
                tvSubtotal.text = "₹$subtotal"
                tvPlatformFee.text = "₹$platformFee"
                tvGst.text = "₹$gstAmount"
                tvTotalPrice.text = "₹$total"
                
                // Update adapter
                if (::cartAdapter.isInitialized) {
                    cartAdapter.updateItems(cartItems)
                    Log.d("CartActivity", "Adapter updated with new items")
                } else {
                    Log.w("CartActivity", "Adapter not initialized, skipping update")
                }
            }
        } catch (e: Exception) {
            Log.e("CartActivity", "Error updating UI: ${e.message}", e)
            Toast.makeText(this, "Error updating cart display", Toast.LENGTH_SHORT).show()
        }
    }
    
    override fun onSupportNavigateUp(): Boolean {
        onBackPressedDispatcher.onBackPressed()
        return true
    }
}
