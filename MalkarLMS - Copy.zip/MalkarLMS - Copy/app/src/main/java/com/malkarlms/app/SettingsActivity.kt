package com.malkarlms.app

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat

class SettingsActivity : AppCompatActivity() {
    
    override fun attachBaseContext(newBase: Context) {
        val languageCode = LocaleHelper.getLanguage(newBase)
        val context = LocaleHelper.setLocale(newBase, languageCode)
        super.attachBaseContext(context)
    }

    private lateinit var btnBack: TextView
    private lateinit var sharedPreferences: SharedPreferences
    
    // Account Settings
    private lateinit var btnEditProfile: View
    private lateinit var btnChangePassword: View
    private lateinit var btnManageAccount: View
    
    // Notifications
    private lateinit var switchPushNotifications: SwitchCompat
    private lateinit var switchEmailNotifications: SwitchCompat
    private lateinit var switchCourseUpdates: SwitchCompat
    
    // App Preferences
    private lateinit var btnLanguage: View
    private lateinit var tvLanguage: TextView
    private lateinit var switchDarkMode: SwitchCompat
    private lateinit var switchAutoPlay: SwitchCompat
    
    // Privacy & Security
    private lateinit var btnPrivacyPolicy: View
    private lateinit var btnTermsOfService: View
    private lateinit var btnDataStorage: View
    
    // Help & Support
    private lateinit var btnHelpCenter: View
    private lateinit var btnContactSupport: View
    private lateinit var btnReportProblem: View
    
    // About
    private lateinit var btnAppVersion: View
    private lateinit var tvAppVersion: TextView
    private lateinit var btnRateApp: View
    private lateinit var btnShareApp: View

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        
        sharedPreferences = getSharedPreferences("app_settings", MODE_PRIVATE)
        
        initViews()
        loadSettings()
        setupClickListeners()
    }

    private fun initViews() {
        btnBack = findViewById(R.id.btnBack)
        
        // Account Settings
        btnEditProfile = findViewById(R.id.btnEditProfile)
        btnChangePassword = findViewById(R.id.btnChangePassword)
        btnManageAccount = findViewById(R.id.btnManageAccount)
        
        // Notifications
        switchPushNotifications = findViewById(R.id.switchPushNotifications)
        switchEmailNotifications = findViewById(R.id.switchEmailNotifications)
        switchCourseUpdates = findViewById(R.id.switchCourseUpdates)
        
        // App Preferences
        btnLanguage = findViewById(R.id.btnLanguage)
        tvLanguage = findViewById(R.id.tvLanguage)
        switchDarkMode = findViewById(R.id.switchDarkMode)
        switchAutoPlay = findViewById(R.id.switchAutoPlay)
        
        // Privacy & Security
        btnPrivacyPolicy = findViewById(R.id.btnPrivacyPolicy)
        btnTermsOfService = findViewById(R.id.btnTermsOfService)
        btnDataStorage = findViewById(R.id.btnDataStorage)
        
        // Help & Support
        btnHelpCenter = findViewById(R.id.btnHelpCenter)
        btnContactSupport = findViewById(R.id.btnContactSupport)
        btnReportProblem = findViewById(R.id.btnReportProblem)
        
        // About
        btnAppVersion = findViewById(R.id.btnAppVersion)
        tvAppVersion = findViewById(R.id.tvAppVersion)
        btnRateApp = findViewById(R.id.btnRateApp)
        btnShareApp = findViewById(R.id.btnShareApp)
    }

    private fun loadSettings() {
        // Load saved settings
        switchPushNotifications.isChecked = sharedPreferences.getBoolean("push_notifications", true)
        switchEmailNotifications.isChecked = sharedPreferences.getBoolean("email_notifications", true)
        switchCourseUpdates.isChecked = sharedPreferences.getBoolean("course_updates", true)
        switchDarkMode.isChecked = sharedPreferences.getBoolean("dark_mode", false)
        switchAutoPlay.isChecked = sharedPreferences.getBoolean("auto_play", false)
        
        // Load current language
        val currentLanguageCode = LocaleHelper.getLanguage(this)
        val currentLanguageName = LocaleHelper.getLanguageName(currentLanguageCode)
        tvLanguage.text = currentLanguageName
    }

    private fun setupClickListeners() {
        btnBack.setOnClickListener { finish() }
        
        // Account Settings
        btnEditProfile.setOnClickListener {
            startActivity(Intent(this, ProfileActivity::class.java))
        }
        
        btnChangePassword.setOnClickListener {
            Toast.makeText(this, "Password reset email will be sent", Toast.LENGTH_SHORT).show()
            // TODO: Implement password change
        }
        
        btnManageAccount.setOnClickListener {
            showManageAccountDialog()
        }
        
        // Notifications
        switchPushNotifications.setOnCheckedChangeListener { _, isChecked ->
            sharedPreferences.edit().putBoolean("push_notifications", isChecked).apply()
            Toast.makeText(this, "Push notifications ${if (isChecked) "enabled" else "disabled"}", Toast.LENGTH_SHORT).show()
        }
        
        switchEmailNotifications.setOnCheckedChangeListener { _, isChecked ->
            sharedPreferences.edit().putBoolean("email_notifications", isChecked).apply()
            Toast.makeText(this, "Email notifications ${if (isChecked) "enabled" else "disabled"}", Toast.LENGTH_SHORT).show()
        }
        
        switchCourseUpdates.setOnCheckedChangeListener { _, isChecked ->
            sharedPreferences.edit().putBoolean("course_updates", isChecked).apply()
            Toast.makeText(this, "Course updates ${if (isChecked) "enabled" else "disabled"}", Toast.LENGTH_SHORT).show()
        }
        
        // App Preferences
        btnLanguage.setOnClickListener {
            showLanguageDialog()
        }
        
        switchDarkMode.setOnCheckedChangeListener { _, isChecked ->
            sharedPreferences.edit().putBoolean("dark_mode", isChecked).apply()
            Toast.makeText(this, "Dark mode ${if (isChecked) "enabled" else "disabled"}. Restart app to apply.", Toast.LENGTH_LONG).show()
        }
        
        switchAutoPlay.setOnCheckedChangeListener { _, isChecked ->
            sharedPreferences.edit().putBoolean("auto_play", isChecked).apply()
            Toast.makeText(this, "Auto-play ${if (isChecked) "enabled" else "disabled"}", Toast.LENGTH_SHORT).show()
        }
        
        // Privacy & Security
        btnPrivacyPolicy.setOnClickListener {
            Toast.makeText(this, "Opening Privacy Policy...", Toast.LENGTH_SHORT).show()
            // TODO: Open privacy policy URL
        }
        
        btnTermsOfService.setOnClickListener {
            Toast.makeText(this, "Opening Terms of Service...", Toast.LENGTH_SHORT).show()
            // TODO: Open terms URL
        }
        
        btnDataStorage.setOnClickListener {
            showDataStorageDialog()
        }
        
        // Help & Support
        btnHelpCenter.setOnClickListener {
            Toast.makeText(this, "Opening Help Center...", Toast.LENGTH_SHORT).show()
            // TODO: Open help center
        }
        
        btnContactSupport.setOnClickListener {
            showContactSupportDialog()
        }
        
        btnReportProblem.setOnClickListener {
            showReportProblemDialog()
        }
        
        // About
        btnAppVersion.setOnClickListener {
            Toast.makeText(this, "You're on the latest version!", Toast.LENGTH_SHORT).show()
        }
        
        btnRateApp.setOnClickListener {
            Toast.makeText(this, "Opening Play Store...", Toast.LENGTH_SHORT).show()
            // TODO: Open Play Store
        }
        
        btnShareApp.setOnClickListener {
            shareApp()
        }
    }

    private fun showLanguageDialog() {
        val languages = arrayOf("English", "हिंदी (Hindi)", "मराठी (Marathi)", "தமிழ் (Tamil)", "తెలుగు (Telugu)")
        val currentLanguageCode = LocaleHelper.getLanguage(this)
        val currentLanguageName = LocaleHelper.getLanguageName(currentLanguageCode)
        val selectedIndex = languages.indexOf(currentLanguageName)
        
        AlertDialog.Builder(this)
            .setTitle("Select Language")
            .setSingleChoiceItems(languages, selectedIndex) { dialog, which ->
                val selectedLanguage = languages[which]
                val languageCode = LocaleHelper.getLanguageCode(selectedLanguage)
                
                // Save language preference
                LocaleHelper.setLocale(this, languageCode)
                sharedPreferences.edit().putString("language", selectedLanguage).apply()
                
                // Show confirmation and restart app
                Toast.makeText(this, "Language changed to $selectedLanguage. Restarting app...", Toast.LENGTH_SHORT).show()
                dialog.dismiss()
                
                // Restart the app after a short delay
                android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
                    restartApp()
                }, 500)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
    
    private fun restartApp() {
        val intent = packageManager.getLaunchIntentForPackage(packageName)
        intent?.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
        startActivity(intent)
        finish()
        Runtime.getRuntime().exit(0)
    }

    private fun showManageAccountDialog() {
        AlertDialog.Builder(this)
            .setTitle("Manage Account")
            .setMessage("Choose an option:")
            .setPositiveButton("Deactivate Account") { _, _ ->
                Toast.makeText(this, "Account deactivation requested", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Delete Account") { _, _ ->
                showDeleteAccountConfirmation()
            }
            .setNeutralButton("Cancel", null)
            .show()
    }

    private fun showDeleteAccountConfirmation() {
        AlertDialog.Builder(this)
            .setTitle("Delete Account")
            .setMessage("Are you sure? This action cannot be undone. All your data will be permanently deleted.")
            .setPositiveButton("Delete") { _, _ ->
                Toast.makeText(this, "Account deletion requested. We'll process this within 24 hours.", Toast.LENGTH_LONG).show()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showDataStorageDialog() {
        AlertDialog.Builder(this)
            .setTitle("Data & Storage")
            .setMessage("Cache Size: 45 MB\nDownloaded Content: 120 MB\n\nWould you like to clear cache?")
            .setPositiveButton("Clear Cache") { _, _ ->
                Toast.makeText(this, "Cache cleared successfully!", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showContactSupportDialog() {
        val options = arrayOf("Email Support", "Call Support", "Live Chat")
        
        AlertDialog.Builder(this)
            .setTitle("Contact Support")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> {
                        val intent = Intent(Intent.ACTION_SENDTO).apply {
                            data = Uri.parse("mailto:support@malkarlms.com")
                            putExtra(Intent.EXTRA_SUBJECT, "Support Request")
                        }
                        startActivity(intent)
                    }
                    1 -> {
                        val intent = Intent(Intent.ACTION_DIAL).apply {
                            data = Uri.parse("tel:+911234567890")
                        }
                        startActivity(intent)
                    }
                    2 -> {
                        Toast.makeText(this, "Opening Live Chat...", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showReportProblemDialog() {
        val problems = arrayOf(
            "App crashes",
            "Login issues",
            "Video playback problems",
            "Payment issues",
            "Other"
        )
        
        AlertDialog.Builder(this)
            .setTitle("Report a Problem")
            .setItems(problems) { _, which ->
                Toast.makeText(this, "Problem reported: ${problems[which]}", Toast.LENGTH_SHORT).show()
                // TODO: Send problem report
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun shareApp() {
        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, "Check out Malkar LMS!")
            putExtra(Intent.EXTRA_TEXT, "Learn anytime, anywhere with Malkar LMS!\n\nDownload now: https://play.google.com/store/apps/details?id=com.malkarlms.app")
        }
        startActivity(Intent.createChooser(shareIntent, "Share Malkar LMS via"))
    }
}
