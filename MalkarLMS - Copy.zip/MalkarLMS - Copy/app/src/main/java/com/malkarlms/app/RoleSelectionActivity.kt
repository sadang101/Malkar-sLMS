package com.malkarlms.app

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView

class RoleSelectionActivity : AppCompatActivity() {
    
    private lateinit var cardStudent: CardView
    private lateinit var cardInstructor: CardView
    private lateinit var btnStudentContinue: Button
    private lateinit var btnInstructorContinue: Button
    private lateinit var tvStudentDescription: TextView
    private lateinit var tvInstructorDescription: TextView
    private lateinit var tvDirectLogin: TextView
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_role_selection)
        
        initViews()
        setupClickListeners()
    }
    
    private fun initViews() {
        cardStudent = findViewById(R.id.cardStudent)
        cardInstructor = findViewById(R.id.cardInstructor)
        btnStudentContinue = findViewById(R.id.btnStudentContinue)
        btnInstructorContinue = findViewById(R.id.btnInstructorContinue)
        tvStudentDescription = findViewById(R.id.tvStudentDescription)
        tvInstructorDescription = findViewById(R.id.tvInstructorDescription)
        tvDirectLogin = findViewById(R.id.tvDirectLogin)
        
        // Set descriptions
        tvStudentDescription.text = "Access thousands of courses\nLearn from industry experts\nGet certificates upon completion"
        tvInstructorDescription.text = "Share your expertise\nEarn from your knowledge\nBuild your teaching brand"
    }
    
    private fun setupClickListeners() {
        // Student card selection
        cardStudent.setOnClickListener {
            selectStudentRole()
        }
        
        btnStudentContinue.setOnClickListener {
            proceedAsStudent()
        }
        
        // Instructor card selection
        cardInstructor.setOnClickListener {
            selectInstructorRole()
        }
        
        btnInstructorContinue.setOnClickListener {
            proceedAsInstructor()
        }
        
        // Direct login option
        tvDirectLogin.setOnClickListener {
            navigateToDirectLogin()
        }
    }
    
    private fun selectStudentRole() {
        // Visual feedback for selection
        cardStudent.setCardBackgroundColor(getColor(R.color.primary_light))
        cardInstructor.setCardBackgroundColor(getColor(R.color.white))
        
        btnStudentContinue.visibility = android.view.View.VISIBLE
        btnInstructorContinue.visibility = android.view.View.GONE
    }
    
    private fun selectInstructorRole() {
        // Visual feedback for selection
        cardInstructor.setCardBackgroundColor(getColor(R.color.primary_light))
        cardStudent.setCardBackgroundColor(getColor(R.color.white))
        
        btnInstructorContinue.visibility = android.view.View.VISIBLE
        btnStudentContinue.visibility = android.view.View.GONE
    }
    
    private fun proceedAsStudent() {
        // Save selected role and navigate to student login
        UserSession.saveUserRole(this, UserRole.STUDENT)
        navigateToLogin(UserRole.STUDENT)
    }
    
    private fun proceedAsInstructor() {
        // Save selected role and navigate to instructor login
        UserSession.saveUserRole(this, UserRole.INSTRUCTOR)
        navigateToLogin(UserRole.INSTRUCTOR)
    }
    
    private fun navigateToLogin(role: UserRole) {
        val intent = Intent(this, LoginActivity::class.java)
        intent.putExtra("USER_ROLE", role.name)
        startActivity(intent)
        finish()
    }
    
    private fun navigateToDirectLogin() {
        // Navigate to login without setting role (will be determined after login)
        val intent = Intent(this, LoginActivity::class.java)
        startActivity(intent)
        finish()
    }
}
