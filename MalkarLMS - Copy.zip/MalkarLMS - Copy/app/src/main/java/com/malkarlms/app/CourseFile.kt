package com.malkarlms.app

import android.net.Uri
import java.io.Serializable

/**
 * Data class representing a course file/material
 */
data class CourseFile(
    val id: String = "",
    val name: String = "",
    val type: FileType = FileType.DOCUMENT,
    val uri: Uri? = null,
    val size: Long = 0L,
    val mimeType: String = "",
    val uploadStatus: UploadStatus = UploadStatus.PENDING,
    val uploadProgress: Int = 0,
    val downloadUrl: String = "",
    val createdAt: Long = System.currentTimeMillis()
) : Serializable

/**
 * Enum representing different file types
 */
enum class FileType(val displayName: String, val icon: String) {
    VIDEO("Video", "📹"),
    DOCUMENT("Document", "📄"),
    IMAGE("Image", "🖼️"),
    AUDIO("Audio", "🎵"),
    OTHER("Other", "📎")
}

/**
 * Enum representing upload status
 */
enum class UploadStatus {
    PENDING,
    UPLOADING,
    COMPLETED,
    FAILED
}

/**
 * Utility class for file operations
 */
object FileUtils {
    
    fun getFileTypeFromMimeType(mimeType: String?): FileType {
        return when {
            mimeType?.startsWith("video/") == true -> FileType.VIDEO
            mimeType?.startsWith("image/") == true -> FileType.IMAGE
            mimeType?.startsWith("audio/") == true -> FileType.AUDIO
            mimeType?.startsWith("application/pdf") == true -> FileType.DOCUMENT
            mimeType?.startsWith("application/msword") == true -> FileType.DOCUMENT
            mimeType?.startsWith("application/vnd.openxmlformats-officedocument") == true -> FileType.DOCUMENT
            mimeType?.startsWith("text/") == true -> FileType.DOCUMENT
            else -> FileType.OTHER
        }
    }
    
    fun formatFileSize(sizeInBytes: Long): String {
        if (sizeInBytes < 1024) return "$sizeInBytes B"
        
        val units = arrayOf("KB", "MB", "GB", "TB")
        var size = sizeInBytes.toDouble()
        var unitIndex = -1
        
        while (size >= 1024 && unitIndex < units.size - 1) {
            size /= 1024
            unitIndex++
        }
        
        return String.format("%.1f %s", size, units[unitIndex])
    }
    
    fun isValidFileType(mimeType: String?): Boolean {
        val allowedTypes = setOf(
            // Videos
            "video/mp4", "video/avi", "video/mov", "video/wmv", "video/flv", "video/webm",
            // Images
            "image/jpeg", "image/jpg", "image/png", "image/gif", "image/bmp", "image/webp",
            // Documents
            "application/pdf", "application/msword", "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            "application/vnd.ms-excel", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            "application/vnd.ms-powerpoint", "application/vnd.openxmlformats-officedocument.presentationml.presentation",
            "text/plain", "text/csv",
            // Audio
            "audio/mp3", "audio/wav", "audio/aac", "audio/ogg"
        )
        
        return mimeType in allowedTypes
    }
}
