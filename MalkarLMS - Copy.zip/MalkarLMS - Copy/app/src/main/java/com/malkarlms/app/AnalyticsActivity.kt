package com.malkarlms.app

import android.os.Bundle
import android.util.Log
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query

class AnalyticsActivity : AppCompatActivity() {
    
    private lateinit var toolbar: Toolbar
    private lateinit var tvTotalCourses: TextView
    private lateinit var tvTotalStudents: TextView
    private lateinit var tvTotalViews: TextView
    private lateinit var tvTotalEarnings: TextView
    private lateinit var tvAvgRating: TextView
    private lateinit var tvTotalReviews: TextView
    private lateinit var recyclerViewCourses: RecyclerView
    
    private lateinit var firestore: FirebaseFirestore
    private lateinit var auth: FirebaseAuth
    private lateinit var courseAnalyticsAdapter: CourseAnalyticsAdapter
    private val courseAnalyticsList = mutableListOf<CourseAnalytics>()
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_analytics)
        
        initFirebase()
        initViews()
        setupToolbar()
        setupRecyclerView()
        loadAnalytics()
    }
    
    private fun initFirebase() {
        firestore = FirebaseFirestore.getInstance()
        auth = FirebaseAuth.getInstance()
    }
    
    private fun initViews() {
        toolbar = findViewById(R.id.toolbar)
        tvTotalCourses = findViewById(R.id.tvTotalCourses)
        tvTotalStudents = findViewById(R.id.tvTotalStudents)
        tvTotalViews = findViewById(R.id.tvTotalViews)
        tvTotalEarnings = findViewById(R.id.tvTotalEarnings)
        tvAvgRating = findViewById(R.id.tvAvgRating)
        tvTotalReviews = findViewById(R.id.tvTotalReviews)
        recyclerViewCourses = findViewById(R.id.recyclerViewCourses)
    }
    
    private fun setupToolbar() {
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "Analytics & Reports"
    }
    
    private fun setupRecyclerView() {
        courseAnalyticsAdapter = CourseAnalyticsAdapter(courseAnalyticsList)
        recyclerViewCourses.apply {
            layoutManager = LinearLayoutManager(this@AnalyticsActivity)
            adapter = courseAnalyticsAdapter
        }
    }
    
    private fun loadAnalytics() {
        val currentUser = auth.currentUser
        if (currentUser == null) {
            Log.w("Analytics", "User not logged in")
            return
        }
        
        // Load instructor's courses and calculate analytics
        firestore.collection("courses")
            .whereEqualTo("instructorId", currentUser.uid)
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .get()
            .addOnSuccessListener { documents ->
                var totalCourses = 0
                var totalStudents = 0
                var totalViews = 0
                var totalEarnings = 0.0
                var totalRating = 0.0
                var totalReviews = 0
                
                courseAnalyticsList.clear()
                
                for (document in documents) {
                    val courseData = document.data
                    totalCourses++
                    
                    val enrollmentCount = (courseData["enrollmentCount"] as? Long)?.toInt() ?: 0
                    val views = (courseData["views"] as? Long)?.toInt() ?: 0
                    val earnings = courseData["totalEarnings"] as? Double ?: 0.0
                    val rating = courseData["rating"] as? Double ?: 0.0
                    val reviewCount = (courseData["reviewCount"] as? Long)?.toInt() ?: 0
                    
                    totalStudents += enrollmentCount
                    totalViews += views
                    totalEarnings += earnings
                    totalRating += rating
                    totalReviews += reviewCount
                    
                    // Add to course analytics list
                    courseAnalyticsList.add(
                        CourseAnalytics(
                            id = document.id,
                            title = courseData["title"] as? String ?: "Unknown Course",
                            enrollmentCount = enrollmentCount,
                            views = views,
                            earnings = earnings,
                            rating = rating,
                            reviewCount = reviewCount,
                            isPublished = !(courseData["isDraft"] as? Boolean ?: true)
                        )
                    )
                }
                
                // Calculate average rating
                val avgRating = if (totalCourses > 0) totalRating / totalCourses else 0.0
                
                // Update UI
                updateAnalyticsUI(totalCourses, totalStudents, totalViews, totalEarnings, avgRating, totalReviews)
                courseAnalyticsAdapter.notifyDataSetChanged()
            }
            .addOnFailureListener { e ->
                Log.w("Analytics", "Error loading analytics", e)
            }
    }
    
    private fun updateAnalyticsUI(
        totalCourses: Int,
        totalStudents: Int,
        totalViews: Int,
        totalEarnings: Double,
        avgRating: Double,
        totalReviews: Int
    ) {
        tvTotalCourses.text = totalCourses.toString()
        tvTotalStudents.text = totalStudents.toString()
        tvTotalViews.text = totalViews.toString()
        tvTotalEarnings.text = "₹${String.format("%.2f", totalEarnings)}"
        tvAvgRating.text = String.format("%.1f", avgRating)
        tvTotalReviews.text = totalReviews.toString()
    }
    
    override fun onSupportNavigateUp(): Boolean {
        onBackPressedDispatcher.onBackPressed()
        return true
    }
}

// Data class for course analytics
data class CourseAnalytics(
    val id: String,
    val title: String,
    val enrollmentCount: Int,
    val views: Int,
    val earnings: Double,
    val rating: Double,
    val reviewCount: Int,
    val isPublished: Boolean
)
