package com.malkarlms.app

/**
 * Data class representing a course
 */
data class Course(
    val id: Int,
    val title: String,
    val description: String,
    val duration: String,
    val price: String,
    val imageUrl: String = "",
    val instructor: String = "",
    val rating: Float = 0.0f,
    val studentsEnrolled: Int = 0,
    val enrollmentCount: Int = 0,
    val category: String = "",
    val level: String = "Beginner",
    val difficulty: String = "",
    val isEnrolled: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    val language: String = "English",
    val modulesCount: Int = 0,
    val lecturesCount: Int = 0,
    val certificateAvailable: Boolean = true,
    val lastUpdated: String = "",
    val tags: List<String> = emptyList(),
    val prerequisites: String = "",
    val learningOutcomes: List<String> = emptyList()
)
