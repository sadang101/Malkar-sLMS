package com.malkarlms.app

/**
 * Data class representing an earning item for instructor earnings tracking
 */
data class EarningItem(
    val courseTitle: String,
    val enrollmentCount: Int,
    val pricePerEnrollment: Double,
    val totalEarnings: Double,
    val lastUpdated: Long
)
