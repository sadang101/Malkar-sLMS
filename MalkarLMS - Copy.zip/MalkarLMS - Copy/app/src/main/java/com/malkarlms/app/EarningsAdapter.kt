package com.malkarlms.app

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import java.text.SimpleDateFormat
import java.util.*

class EarningsAdapter(
    private val earningsList: List<EarningItem>
) : RecyclerView.Adapter<EarningsAdapter.ViewHolder>() {
    
    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvCourseTitle: TextView = itemView.findViewById(R.id.tvCourseTitle)
        val tvEnrollmentCount: TextView = itemView.findViewById(R.id.tvEnrollmentCount)
        val tvPricePerEnrollment: TextView = itemView.findViewById(R.id.tvPricePerEnrollment)
        val tvTotalEarnings: TextView = itemView.findViewById(R.id.tvTotalEarnings)
        val tvLastUpdated: TextView = itemView.findViewById(R.id.tvLastUpdated)
    }
    
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_earning, parent, false)
        return ViewHolder(view)
    }
    
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val earning = earningsList[position]
        
        holder.tvCourseTitle.text = earning.courseTitle
        holder.tvEnrollmentCount.text = "${earning.enrollmentCount} students"
        holder.tvPricePerEnrollment.text = "₹${String.format("%.2f", earning.pricePerEnrollment)} per student"
        holder.tvTotalEarnings.text = "₹${String.format("%.2f", earning.totalEarnings)}"
        
        // Format date
        val dateFormat = SimpleDateFormat("MMM dd, yyyy", Locale.getDefault())
        val date = Date(earning.lastUpdated)
        holder.tvLastUpdated.text = "Updated: ${dateFormat.format(date)}"
    }
    
    override fun getItemCount(): Int = earningsList.size
}
