package com.malkarlms.app

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.MenuItem
import android.widget.RelativeLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.navigation.NavigationView
import com.google.firebase.firestore.FirebaseFirestore

class DashboardActivity : AppCompatActivity(), NavigationView.OnNavigationItemSelectedListener, CartManager.CartListener {
    
    override fun attachBaseContext(newBase: Context) {
        val languageCode = LocaleHelper.getLanguage(newBase)
        val context = LocaleHelper.setLocale(newBase, languageCode)
        super.attachBaseContext(context)
    }
    
    private lateinit var drawerLayout: DrawerLayout
    private lateinit var navigationView: NavigationView
    private lateinit var toggle: ActionBarDrawerToggle
    private lateinit var cartBadge: TextView
    private lateinit var cartContainer: RelativeLayout
    private lateinit var menuIcon: TextView
    private lateinit var searchIcon: TextView
    private lateinit var tvUserName: TextView
    private lateinit var tvUserEmail: TextView
    private lateinit var tvViewAllCourses: TextView
    private lateinit var rvFeaturedCourses: RecyclerView
    private lateinit var progressLoading: android.widget.ProgressBar
    private lateinit var tvEmptyState: TextView
    private lateinit var courseAdapter: CourseAdapter
    private val courseList = mutableListOf<Course>()
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Make app work better with device notches and status bars
        window.statusBarColor = getColor(R.color.primary)
        
        setContentView(R.layout.activity_dashboard)
        
        initViews()
        setupDrawer()
        setupNavigationBasedOnRole()
        setupNavigation()
    }
    
    private fun initViews() {
        try {
            Log.d("DashboardActivity", "Starting view initialization...")
            
            drawerLayout = findViewById(R.id.drawerLayout) ?: throw Exception("drawerLayout not found")
            navigationView = findViewById(R.id.navigationView) ?: throw Exception("navigationView not found")
            cartBadge = findViewById(R.id.cartBadge) ?: throw Exception("cartBadge not found")
            cartContainer = findViewById(R.id.cartContainer) ?: throw Exception("cartContainer not found")
            menuIcon = findViewById(R.id.menuIcon) ?: throw Exception("menuIcon not found")
            searchIcon = findViewById(R.id.searchIcon) ?: throw Exception("searchIcon not found")
            tvViewAllCourses = findViewById(R.id.tvViewAllCourses) ?: throw Exception("tvViewAllCourses not found")
            rvFeaturedCourses = findViewById(R.id.rvFeaturedCourses) ?: throw Exception("rvFeaturedCourses not found")
            progressLoading = findViewById(R.id.progressLoading) ?: throw Exception("progressLoading not found")
            tvEmptyState = findViewById(R.id.tvEmptyState) ?: throw Exception("tvEmptyState not found")
            
            Log.d("DashboardActivity", "All main views initialized successfully")
            
            // Get navigation header views
            val headerView = navigationView.getHeaderView(0)
            tvUserName = headerView.findViewById(R.id.tvUserName) ?: throw Exception("tvUserName not found")
            tvUserEmail = headerView.findViewById(R.id.tvUserEmail) ?: throw Exception("tvUserEmail not found")
            
            Log.d("DashboardActivity", "Header views initialized successfully")
            
            // Setup cart listener
            CartManager.addCartListener(this)
            updateCartBadge()
            
            Log.d("DashboardActivity", "Cart setup complete")
            
            // Setup RecyclerView
            setupRecyclerView()
            
            Log.d("DashboardActivity", "RecyclerView setup complete")
            
            // Load user information
            loadUserInfo()
            
            // Load featured courses
            loadFeaturedCourses()
            
            Log.d("DashboardActivity", "Data loading initiated")
            
            // Setup modern back button handling
            setupBackPressedCallback()
            
            Log.d("DashboardActivity", "Dashboard initialization complete!")
        } catch (e: Exception) {
            Log.e("DashboardActivity", "❌ CRASH: Error initializing views", e)
            Toast.makeText(this, "Error loading dashboard: ${e.message}", Toast.LENGTH_LONG).show()
            
            // Try to finish activity gracefully
            finish()
        }
    }
    
    private fun setupDrawer() {
        // Since we're using a custom toolbar, we don't need the ActionBarDrawerToggle
        // Just set up the drawer listener for swipe gestures
        
        // No need for toolbar setup since we have custom layout
        // The drawer will work with swipe gestures by default
    }
    
    private fun setupNavigationBasedOnRole() {
        val userRole = UserSession.getUserRole(this)
        when (userRole) {
            UserRole.INSTRUCTOR -> {
                // Set instructor menu
                navigationView.menu.clear()
                navigationView.inflateMenu(R.menu.nav_menu_instructor)
            }
            UserRole.STUDENT -> {
                // Set student menu (default)
                navigationView.menu.clear()
                navigationView.inflateMenu(R.menu.nav_menu)
            }
            UserRole.ADMIN -> {
                // For now, use instructor menu for admin (can be customized later)
                navigationView.menu.clear()
                navigationView.inflateMenu(R.menu.nav_menu_instructor)
            }
        }
    }
    
    private fun setupNavigation() {
        navigationView.setNavigationItemSelectedListener(this)
        
        // Cart click listener
        cartContainer.setOnClickListener {
            startActivity(Intent(this, CartActivity::class.java))
        }
        
        // Search click listener
        searchIcon.setOnClickListener {
            startActivity(Intent(this, SearchActivity::class.java))
        }
        
        // View All Courses click listener
        tvViewAllCourses.setOnClickListener {
            startActivity(Intent(this, MoreCoursesActivity::class.java))
        }
        
        // Hamburger menu click listener
        menuIcon.setOnClickListener {
            if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
                drawerLayout.closeDrawer(GravityCompat.START)
            } else {
                drawerLayout.openDrawer(GravityCompat.START)
            }
        }
    }
    
    override fun onNavigationItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.nav_profile -> {
                startActivity(Intent(this, ProfileActivity::class.java))
            }
            R.id.nav_my_courses -> {
                startActivity(Intent(this, MyCoursesActivity::class.java))
            }
            R.id.nav_progress -> {
                startActivity(Intent(this, MyProgressActivity::class.java))
            }
            // Instructor-specific menu items
            R.id.nav_analytics -> {
                Toast.makeText(this, "Analytics clicked", Toast.LENGTH_SHORT).show()
                // TODO: Navigate to analytics activity
            }
            R.id.nav_earnings -> {
                Toast.makeText(this, "Earnings clicked", Toast.LENGTH_SHORT).show()
                // TODO: Navigate to earnings activity
            }
            R.id.nav_students -> {
                Toast.makeText(this, "My Students clicked", Toast.LENGTH_SHORT).show()
                // TODO: Navigate to students management activity
            }
            R.id.nav_settings -> {
                startActivity(Intent(this, SettingsActivity::class.java))
            }
            R.id.nav_logout -> {
                logout()
            }
        }
        
        drawerLayout.closeDrawer(GravityCompat.START)
        return true
    }
    
    
    private fun logout() {
        // Clear user session data
        UserSession.clearUserSession(this)
        
        // Sign out from Firebase
        com.google.firebase.auth.FirebaseAuth.getInstance().signOut()
        
        Toast.makeText(this, "Logged out successfully", Toast.LENGTH_SHORT).show()
        
        // Navigate back to login
        val intent = Intent(this, LoginActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(intent)
        finish()
    }
    
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        // Handle hamburger icon click with animation
        if (toggle.onOptionsItemSelected(item)) {
            return true
        }
        
        // Handle home button click manually if needed
        when (item.itemId) {
            android.R.id.home -> {
                if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
                    drawerLayout.closeDrawer(GravityCompat.START)
                } else {
                    drawerLayout.openDrawer(GravityCompat.START)
                }
                return true
            }
        }
        
        return super.onOptionsItemSelected(item)
    }
    
    private fun setupBackPressedCallback() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
                    drawerLayout.closeDrawer(GravityCompat.START)
                } else {
                    // Let the system handle the back press
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })
    }
    
    // Cart listener implementation
    override fun onCartUpdated(itemCount: Int) {
        updateCartBadge()
    }
    
    private fun updateCartBadge() {
        val itemCount = CartManager.getCartItemCount()
        if (itemCount > 0) {
            cartBadge.text = itemCount.toString()
            cartBadge.visibility = android.view.View.VISIBLE
        } else {
            cartBadge.visibility = android.view.View.GONE
        }
    }
    
    private fun loadUserInfo() {
        // First try to load from Firebase if user is logged in
        UserSession.loadUserInfoFromFirebase(this)
        
        // Then load from SharedPreferences and update UI
        val userName = UserSession.getUserName(this)
        val userEmail = UserSession.getUserEmail(this)
        
        Log.d("DashboardActivity", "Loading user info - Name: '$userName', Email: '$userEmail'")
        
        tvUserName.text = userName
        tvUserEmail.text = userEmail
        
        // Ensure the TextViews are visible
        tvUserName.visibility = android.view.View.VISIBLE
        tvUserEmail.visibility = android.view.View.VISIBLE
        
        Log.d("DashboardActivity", "User info updated in navigation header")
    }
    
    private fun setupRecyclerView() {
        courseAdapter = CourseAdapter(courseList) { course ->
            // Handle course click
            val intent = Intent(this, CourseDetailsActivity::class.java).apply {
                putExtra("COURSE_ID", course.id)
                putExtra("COURSE_TITLE", course.title)
                putExtra("COURSE_DESCRIPTION", course.description)
                putExtra("COURSE_DURATION", course.duration)
                putExtra("COURSE_PRICE", course.price)
                putExtra("COURSE_INSTRUCTOR", course.instructor)
                putExtra("COURSE_RATING", course.rating)
                putExtra("COURSE_STUDENTS", course.studentsEnrolled)
                putExtra("COURSE_LEVEL", course.level)
                putExtra("COURSE_IMAGE_URL", course.imageUrl)
                putExtra("COURSE_CATEGORY", course.category)
                putExtra("COURSE_LANGUAGE", course.language)
                putExtra("COURSE_MODULES", course.modulesCount)
                putExtra("COURSE_LECTURES", course.lecturesCount)
                putExtra("COURSE_CERTIFICATE", course.certificateAvailable)
                putExtra("COURSE_PREREQUISITES", course.prerequisites)
                putStringArrayListExtra("COURSE_OUTCOMES", ArrayList(course.learningOutcomes))
            }
            startActivity(intent)
        }
        
        // Optimize RecyclerView performance
        rvFeaturedCourses.apply {
            layoutManager = LinearLayoutManager(this@DashboardActivity)
            adapter = courseAdapter
            setHasFixedSize(true) // Performance optimization
            setItemViewCacheSize(20) // Cache more items
        }
    }
    
    private fun loadFeaturedCourses() {
        try {
            Log.d("DashboardActivity", "Loading hardcoded sample courses...")
            
            // Show loading indicator briefly
            progressLoading.visibility = android.view.View.VISIBLE
            rvFeaturedCourses.visibility = android.view.View.GONE
            tvEmptyState.visibility = android.view.View.GONE
            
            // Add hardcoded sample courses
            courseList.clear()
            courseList.addAll(getSampleCourses())
            
            // Hide loading and show courses
            progressLoading.visibility = android.view.View.GONE
            tvEmptyState.visibility = android.view.View.GONE
            rvFeaturedCourses.visibility = android.view.View.VISIBLE
            courseAdapter.notifyDataSetChanged()
            
            Log.d("DashboardActivity", "✅ Loaded ${courseList.size} sample courses")
        } catch (e: Exception) {
            Log.e("DashboardActivity", "❌ Error loading courses", e)
            progressLoading.visibility = android.view.View.GONE
            tvEmptyState.text = "Error loading courses"
            tvEmptyState.visibility = android.view.View.VISIBLE
        }
    }
    
    private fun getSampleCourses(): List<Course> {
        return listOf(
            Course(
                id = 1,
                title = "Complete Python Programming Masterclass",
                description = "Master Python from basics to advanced with Django web development",
                duration = "12 weeks",
                price = "₹2,999",
                imageUrl = "",
                instructor = "Dr. Rajesh Kumar",
                rating = 4.8f,
                studentsEnrolled = 15420,
                level = "Beginner",
                category = "Programming",
                language = "English",
                modulesCount = 8,
                lecturesCount = 120,
                certificateAvailable = true,
                lastUpdated = "Updated Nov 2024",
                tags = listOf("Python", "Django", "Web Development", "Backend"),
                prerequisites = "Basic computer knowledge",
                learningOutcomes = listOf(
                    "Master Python programming fundamentals",
                    "Build web applications with Django",
                    "Work with databases and APIs",
                    "Deploy production-ready applications"
                )
            ),
            Course(
                id = 2,
                title = "Full Stack Web Development Bootcamp",
                description = "Become a full-stack developer with MERN stack",
                duration = "16 weeks",
                price = "₹4,499",
                imageUrl = "",
                instructor = "Priya Sharma",
                rating = 4.9f,
                studentsEnrolled = 22350,
                level = "Intermediate",
                category = "Web Development",
                language = "English",
                modulesCount = 12,
                lecturesCount = 180,
                certificateAvailable = true,
                lastUpdated = "Updated Oct 2024",
                tags = listOf("React", "Node.js", "MongoDB", "Express"),
                prerequisites = "HTML, CSS, JavaScript basics",
                learningOutcomes = listOf(
                    "Build full-stack web applications",
                    "Master React and Node.js",
                    "Work with MongoDB databases",
                    "Deploy to cloud platforms"
                )
            ),
            Course(
                id = 3,
                title = "Data Science & Machine Learning",
                description = "Learn data analysis, ML algorithms, and AI",
                duration = "14 weeks",
                price = "₹3,999",
                imageUrl = "",
                instructor = "Dr. Amit Patel",
                rating = 4.7f,
                studentsEnrolled = 18900,
                level = "Advanced",
                category = "Data Science",
                language = "English",
                modulesCount = 10,
                lecturesCount = 150,
                certificateAvailable = true,
                lastUpdated = "Updated Nov 2024",
                tags = listOf("Python", "Machine Learning", "AI", "Data Analysis"),
                prerequisites = "Python programming, Statistics basics",
                learningOutcomes = listOf(
                    "Master machine learning algorithms",
                    "Build predictive models",
                    "Work with real-world datasets",
                    "Deploy ML models to production"
                )
            ),
            Course(
                id = 4,
                title = "Android App Development with Kotlin",
                description = "Build professional Android apps with Kotlin",
                duration = "12 weeks",
                price = "₹3,499",
                imageUrl = "",
                instructor = "Vikram Singh",
                rating = 4.6f,
                studentsEnrolled = 12450,
                level = "Beginner",
                category = "Mobile Development",
                language = "English",
                modulesCount = 9,
                lecturesCount = 130,
                certificateAvailable = true,
                lastUpdated = "Updated Oct 2024",
                tags = listOf("Android", "Kotlin", "Mobile Apps", "Firebase"),
                prerequisites = "Basic programming knowledge",
                learningOutcomes = listOf(
                    "Build native Android applications",
                    "Master Kotlin programming",
                    "Integrate Firebase services",
                    "Publish apps to Play Store"
                )
            ),
            Course(
                id = 5,
                title = "Digital Marketing Mastery",
                description = "Master digital marketing and grow your business online",
                duration = "10 weeks",
                price = "₹3,499",
                imageUrl = "",
                instructor = "Meera Kapoor",
                rating = 4.8f,
                studentsEnrolled = 19500,
                level = "Beginner",
                category = "Marketing",
                language = "English",
                modulesCount = 7,
                lecturesCount = 95,
                certificateAvailable = true,
                lastUpdated = "Updated Nov 2024",
                tags = listOf("SEO", "Social Media", "Content Marketing", "Analytics"),
                prerequisites = "None",
                learningOutcomes = listOf(
                    "Master SEO and content marketing",
                    "Run effective social media campaigns",
                    "Analyze marketing metrics",
                    "Grow business online presence"
                )
            )
        )
    }
    
    override fun onDestroy() {
        super.onDestroy()
        CartManager.removeCartListener(this)
    }
}

// Simple Repository for data management
class CourseRepository {
    private val firestore = FirebaseFirestore.getInstance()
    
    suspend fun getCourses(): Resource<List<Course>> {
        return try {
            // Simulate API call or Firebase fetch
            val courses = getSampleCourses()
            Resource.Success(courses)
        } catch (e: Exception) {
            Resource.Error(e.message ?: "Unknown error occurred")
        }
    }
    
    private fun getSampleCourses(): List<Course> {
        return listOf(
            Course(1, "Android Development", "Learn Android with Kotlin", "40 hours", "₹2,999"),
            Course(2, "Web Development", "Full Stack Web Development", "60 hours", "₹3,999"),
            Course(3, "Data Science", "Python for Data Science", "50 hours", "₹4,999")
        )
    }
}
