package com.malkarlms.app

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.util.Patterns
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.firestore.FirebaseFirestore
import androidx.credentials.CredentialManager
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialException
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class LoginActivity : AppCompatActivity() {
    
    private lateinit var etEmail: EditText
    private lateinit var etPassword: EditText
    private lateinit var btnLogin: Button
    private lateinit var btnGoogleSignIn: Button
    private lateinit var tvRegister: TextView
    private lateinit var tvForgotPassword: TextView
    
    // Firebase instances
    private lateinit var auth: FirebaseAuth
    private lateinit var firestore: FirebaseFirestore
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        
        // Initialize Firebase
        auth = FirebaseAuth.getInstance()
        firestore = FirebaseFirestore.getInstance()
        
        initViews()
        setupClickListeners()
        testFirebaseConnection()
    }
    
    private fun initViews() {
        etEmail = findViewById(R.id.etEmail)
        etPassword = findViewById(R.id.etPassword)
        btnLogin = findViewById(R.id.btnLogin)
        btnGoogleSignIn = findViewById(R.id.btnGoogleSignIn)
        tvRegister = findViewById(R.id.tvRegister)
        tvForgotPassword = findViewById(R.id.tvForgotPassword)
    }
    
    private fun setupClickListeners() {
        btnLogin.setOnClickListener {
            performLogin()
        }
        
        btnGoogleSignIn.setOnClickListener {
            performGoogleSignIn()
        }
        
        tvRegister.setOnClickListener {
            val registerIntent = Intent(this, RegisterActivity::class.java)
            // Pass the selected role to registration
            val userRole = intent.getStringExtra("USER_ROLE") ?: UserRole.STUDENT.name
            registerIntent.putExtra("USER_ROLE", userRole)
            startActivity(registerIntent)
        }
        
        tvForgotPassword.setOnClickListener {
            Toast.makeText(this, "Forgot password feature coming soon", Toast.LENGTH_SHORT).show()
        }
    }
    
    private fun performLogin() {
        val email = etEmail.text.toString().trim()
        val password = etPassword.text.toString().trim()
        
        // Reset errors
        etEmail.error = null
        etPassword.error = null
        
        var isValid = true
        
        // Validate email
        if (email.isEmpty()) {
            etEmail.error = "Email is required"
            isValid = false
        } else if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            etEmail.error = "Invalid email format"
            isValid = false
        }
        
        // Validate password
        if (password.isEmpty()) {
            etPassword.error = "Password is required"
            isValid = false
        } else if (password.length < 6) {
            etPassword.error = "Password must be at least 6 characters"
            isValid = false
        }
        
        if (isValid) {
            // Perform Firebase Authentication
            btnLogin.isEnabled = false
            btnLogin.text = "Logging in..."
            
            auth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(this) { task ->
                    btnLogin.isEnabled = true
                    btnLogin.text = "Login"
                    
                    if (task.isSuccessful) {
                        Log.d("LoginActivity", "signInWithEmail:success")
                        val user = auth.currentUser
                        
                        // Save user information to session
                        user?.let { firebaseUser ->
                            val userName = firebaseUser.displayName ?: extractNameFromEmail(firebaseUser.email ?: "")
                            val userEmail = firebaseUser.email ?: ""
                            UserSession.saveUserInfo(this, userName, userEmail)
                        }
                        
                        Toast.makeText(this, "Login successful! Welcome ${user?.email}", Toast.LENGTH_SHORT).show()
                        
                        // Navigate to appropriate dashboard based on role
                        navigateBasedOnRole()
                    } else {
                        Log.w("LoginActivity", "signInWithEmail:failure", task.exception)
                        Toast.makeText(this, "Authentication failed: ${task.exception?.message}", Toast.LENGTH_LONG).show()
                    }
                }
        }
    }
    
    private fun testFirebaseConnection() {
        Log.d("Firebase", "Testing Firebase connection...")
        
        // Test Firebase initialization by checking if instances are properly initialized
        try {
            // These are lateinit vars, so accessing them will throw if not initialized
            val authInitialized = ::auth.isInitialized
            val firestoreInitialized = ::firestore.isInitialized
            
            Log.d("Firebase", "Auth initialized: $authInitialized")
            Log.d("Firebase", "Firestore initialized: $firestoreInitialized")
            
            if (authInitialized && firestoreInitialized) {
                Log.d("Firebase", "✅ Firebase services initialized successfully!")
            } else {
                Log.e("Firebase", "❌ Firebase services failed to initialize")
                Toast.makeText(this, "Firebase initialization failed", Toast.LENGTH_SHORT).show()
            }
        } catch (e: Exception) {
            Log.e("Firebase", "❌ Firebase initialization error: ${e.message}")
            Toast.makeText(this, "Firebase initialization failed", Toast.LENGTH_SHORT).show()
        }
    }
    
    private fun performGoogleSignIn() {
        btnGoogleSignIn.isEnabled = false
        btnGoogleSignIn.text = "Signing in..."
        
        val googleIdOption = GetGoogleIdOption.Builder()
            .setFilterByAuthorizedAccounts(false)
            .setServerClientId("736960912915-a8aavhuk0rfs0skftdt76hhb6uqvdnal.apps.googleusercontent.com") // Web Client ID from Firebase
            .build()
        
        val request = GetCredentialRequest.Builder()
            .addCredentialOption(googleIdOption)
            .build()
        
        val credentialManager = CredentialManager.create(this)
        
        CoroutineScope(Dispatchers.Main).launch {
            try {
                val result = credentialManager.getCredential(
                    request = request,
                    context = this@LoginActivity,
                )
                
                val credential = result.credential
                val googleIdTokenCredential = GoogleIdTokenCredential.createFrom(credential.data)
                val googleIdToken = googleIdTokenCredential.idToken
                
                // Authenticate with Firebase
                val firebaseCredential = GoogleAuthProvider.getCredential(googleIdToken, null)
                auth.signInWithCredential(firebaseCredential)
                    .addOnCompleteListener(this@LoginActivity) { task ->
                        btnGoogleSignIn.isEnabled = true
                        btnGoogleSignIn.text = "Continue with Google"
                        
                        if (task.isSuccessful) {
                            Log.d("LoginActivity", "signInWithCredential:success")
                            val user = auth.currentUser
                            
                            // Save user information to session
                            user?.let { firebaseUser ->
                                val userName = firebaseUser.displayName ?: extractNameFromEmail(firebaseUser.email ?: "")
                                val userEmail = firebaseUser.email ?: ""
                                UserSession.saveUserInfo(this@LoginActivity, userName, userEmail)
                                
                                // Also save to Firestore if new user
                                saveGoogleUserToFirestore(firebaseUser.uid, userName, userEmail)
                            }
                            
                            Toast.makeText(this@LoginActivity, "Google Sign-In successful! Welcome ${user?.displayName}", Toast.LENGTH_SHORT).show()
                            
                            // Navigate to appropriate dashboard based on role
                            navigateBasedOnRole()
                        } else {
                            Log.w("LoginActivity", "signInWithCredential:failure", task.exception)
                            Toast.makeText(this@LoginActivity, "Google Sign-In failed: ${task.exception?.message}", Toast.LENGTH_LONG).show()
                        }
                    }
                    
            } catch (e: GetCredentialException) {
                Log.w("LoginActivity", "Google Sign-In failed", e)
                Log.w("LoginActivity", "Exception type: ${e.javaClass.simpleName}")
                Log.w("LoginActivity", "Exception message: ${e.message}")
                btnGoogleSignIn.isEnabled = true
                btnGoogleSignIn.text = "Continue with Google"
                
                // Provide more specific error messages
                val errorMessage = when {
                    e.message?.contains("No credentials available") == true -> 
                        "No Google accounts found. Please add a Google account to your device."
                    e.message?.contains("cancelled") == true -> 
                        "Google Sign-In was cancelled."
                    else -> "Google Sign-In failed: ${e.message}"
                }
                
                Toast.makeText(this@LoginActivity, errorMessage, Toast.LENGTH_LONG).show()
            }
        }
    }
    
    private fun saveGoogleUserToFirestore(userId: String, displayName: String, email: String) {
        // Check if user already exists
        firestore.collection("users").document(userId)
            .get()
            .addOnSuccessListener { document ->
                if (!document.exists()) {
                    // User doesn't exist, create new profile
                    val userData = hashMapOf(
                        "fullName" to displayName,
                        "email" to email,
                        "createdAt" to System.currentTimeMillis(),
                        "role" to "student",
                        "signInMethod" to "google"
                    )
                    
                    firestore.collection("users").document(userId)
                        .set(userData)
                        .addOnSuccessListener {
                            Log.d("LoginActivity", "Google user data saved to Firestore")
                        }
                        .addOnFailureListener { e ->
                            Log.w("LoginActivity", "Error saving Google user data", e)
                        }
                }
            }
    }
    
    private fun navigateBasedOnRole() {
        val userRole = UserSession.getUserRole(this)
        when (userRole) {
            UserRole.INSTRUCTOR -> {
                // Navigate to instructor dashboard
                startActivity(Intent(this, InstructorDashboardActivity::class.java))
            }
            UserRole.STUDENT -> {
                // Navigate to student dashboard
                startActivity(Intent(this, DashboardActivity::class.java))
            }
            UserRole.ADMIN -> {
                // For now, navigate to instructor dashboard (can be customized later)
                startActivity(Intent(this, InstructorDashboardActivity::class.java))
            }
        }
        finish()
    }
    
    private fun extractNameFromEmail(email: String): String {
        return if (email.contains("@")) {
            val username = email.substringBefore("@")
            // Capitalize first letter and replace dots/underscores with spaces
            username.replace(".", " ")
                .replace("_", " ")
                .split(" ")
                .joinToString(" ") { word ->
                    word.replaceFirstChar { if (it.isLowerCase()) it.titlecase() else it.toString() }
                }
        } else {
            "Student Name"
        }
    }
}
