package com.malkarlms.app

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class MyCoursesActivity : AppCompatActivity() {
    
    override fun attachBaseContext(newBase: Context) {
        val languageCode = LocaleHelper.getLanguage(newBase)
        val context = LocaleHelper.setLocale(newBase, languageCode)
        super.attachBaseContext(context)
    }

    private lateinit var btnBack: TextView
    private lateinit var rvMyCourses: RecyclerView
    private lateinit var coursesContainer: View
    private lateinit var emptyStateContainer: View
    private lateinit var btnBrowseCourses: Button
    
    private lateinit var auth: FirebaseAuth
    private lateinit var firestore: FirebaseFirestore
    private lateinit var courseAdapter: CourseAdapter
    private val enrolledCourses = mutableListOf<Course>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_my_courses)
        
        initFirebase()
        initViews()
        setupRecyclerView()
        loadEnrolledCourses()
    }
    
    private fun initFirebase() {
        auth = FirebaseAuth.getInstance()
        firestore = FirebaseFirestore.getInstance()
    }
    
    private fun initViews() {
        btnBack = findViewById(R.id.btnBack)
        rvMyCourses = findViewById(R.id.rvMyCourses)
        coursesContainer = findViewById(R.id.coursesContainer)
        emptyStateContainer = findViewById(R.id.emptyStateContainer)
        btnBrowseCourses = findViewById(R.id.btnBrowseCourses)
        
        btnBack.setOnClickListener { finish() }
        
        btnBrowseCourses.setOnClickListener {
            startActivity(Intent(this, MoreCoursesActivity::class.java))
        }
    }
    
    private fun setupRecyclerView() {
        courseAdapter = CourseAdapter(enrolledCourses) { course ->
            // Navigate to course details
            val intent = Intent(this, CourseDetailsActivity::class.java)
            intent.putExtra("courseId", course.id)
            intent.putExtra("courseTitle", course.title)
            intent.putExtra("courseDescription", course.description)
            intent.putExtra("coursePrice", course.price)
            intent.putExtra("courseInstructor", course.instructor)
            intent.putExtra("courseRating", course.rating)
            startActivity(intent)
        }
        
        rvMyCourses.apply {
            layoutManager = LinearLayoutManager(this@MyCoursesActivity)
            adapter = courseAdapter
        }
    }
    
    private fun loadEnrolledCourses() {
        val userId = auth.currentUser?.uid
        
        if (userId == null) {
            Log.e("MyCoursesActivity", "User not logged in")
            showEmptyState()
            return
        }
        
        // Load enrolled courses from Firestore
        firestore.collection("enrollments")
            .whereEqualTo("userId", userId)
            .get()
            .addOnSuccessListener { enrollmentDocs ->
                if (enrollmentDocs.isEmpty) {
                    Log.d("MyCoursesActivity", "No enrollments found")
                    showEmptyState()
                    return@addOnSuccessListener
                }
                
                val courseIds = enrollmentDocs.documents.mapNotNull { it.getString("courseId") }
                Log.d("MyCoursesActivity", "Found ${courseIds.size} enrolled courses")
                
                if (courseIds.isEmpty()) {
                    showEmptyState()
                    return@addOnSuccessListener
                }
                
                // Load course details
                loadCourseDetails(courseIds)
            }
            .addOnFailureListener { e ->
                Log.e("MyCoursesActivity", "Error loading enrollments", e)
                showEmptyState()
            }
    }
    
    private fun loadCourseDetails(courseIds: List<String>) {
        firestore.collection("courses")
            .whereIn("id", courseIds)
            .get()
            .addOnSuccessListener { courseDocs ->
                enrolledCourses.clear()
                
                for (doc in courseDocs.documents) {
                    val course = Course(
                        id = doc.getLong("id")?.toInt() ?: 0,
                        title = doc.getString("title") ?: "Untitled Course",
                        description = doc.getString("description") ?: "",
                        duration = doc.getString("duration") ?: "4 weeks",
                        price = doc.getString("price") ?: "₹0",
                        instructor = doc.getString("instructor") ?: "Unknown",
                        rating = doc.getDouble("rating")?.toFloat() ?: 0f,
                        imageUrl = doc.getString("imageUrl") ?: ""
                    )
                    enrolledCourses.add(course)
                }
                
                Log.d("MyCoursesActivity", "Loaded ${enrolledCourses.size} course details")
                
                if (enrolledCourses.isEmpty()) {
                    showEmptyState()
                } else {
                    showCourses()
                }
            }
            .addOnFailureListener { e ->
                Log.e("MyCoursesActivity", "Error loading course details", e)
                showEmptyState()
            }
    }
    
    private fun showCourses() {
        coursesContainer.visibility = View.VISIBLE
        emptyStateContainer.visibility = View.GONE
        courseAdapter.notifyDataSetChanged()
    }
    
    private fun showEmptyState() {
        coursesContainer.visibility = View.GONE
        emptyStateContainer.visibility = View.VISIBLE
    }
}
