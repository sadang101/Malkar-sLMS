package com.malkarlms.app

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.MenuItem
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import com.google.android.material.navigation.NavigationView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class InstructorDashboardActivity : AppCompatActivity(), NavigationView.OnNavigationItemSelectedListener {
    
    private lateinit var drawerLayout: DrawerLayout
    private lateinit var navigationView: NavigationView
    private lateinit var toggle: ActionBarDrawerToggle
    private lateinit var menuIcon: TextView
    private lateinit var tvUserName: TextView
    private lateinit var tvUserEmail: TextView
    private lateinit var btnCreateCourse: Button
    private lateinit var btnMyCourses: Button
    private lateinit var btnAnalytics: Button
    private lateinit var btnEarnings: Button
    private lateinit var tvCoursesCount: TextView
    private lateinit var tvStudentsCount: TextView
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Make app work better with device notches and status bars
        window.statusBarColor = getColor(R.color.primary)
        
        setContentView(R.layout.activity_instructor_dashboard)
        
        initViews()
        setupDrawer()
        setupNavigation()
        loadUserInfo()
    }
    
    private fun initViews() {
        drawerLayout = findViewById(R.id.drawerLayout)
        navigationView = findViewById(R.id.navigationView)
        menuIcon = findViewById(R.id.menuIcon)
        btnCreateCourse = findViewById(R.id.btnCreateCourse)
        btnMyCourses = findViewById(R.id.btnMyCourses)
        btnAnalytics = findViewById(R.id.btnAnalytics)
        btnEarnings = findViewById(R.id.btnEarnings)
        tvCoursesCount = findViewById(R.id.tvCoursesCount)
        tvStudentsCount = findViewById(R.id.tvStudentsCount)
        
        // Get navigation header views
        val headerView = navigationView.getHeaderView(0)
        tvUserName = headerView.findViewById(R.id.tvUserName)
        tvUserEmail = headerView.findViewById(R.id.tvUserEmail)
        
        // Setup modern back button handling
        setupBackPressedCallback()
    }
    
    private fun setupDrawer() {
        // Custom drawer setup for instructor
    }
    
    private fun setupNavigation() {
        navigationView.setNavigationItemSelectedListener(this)
        
        // Hamburger menu click listener
        menuIcon.setOnClickListener {
            if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
                drawerLayout.closeDrawer(GravityCompat.START)
            } else {
                drawerLayout.openDrawer(GravityCompat.START)
            }
        }
        
        // Button click listeners
        btnCreateCourse.setOnClickListener {
            startActivity(Intent(this, CourseCreationActivity::class.java))
        }
        
        btnMyCourses.setOnClickListener {
            startActivity(Intent(this, InstructorCoursesActivity::class.java))
        }
        
        btnAnalytics.setOnClickListener {
            startActivity(Intent(this, AnalyticsActivity::class.java))
        }
        
        btnEarnings.setOnClickListener {
            startActivity(Intent(this, EarningsActivity::class.java))
        }
    }
    
    override fun onNavigationItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.nav_profile -> {
                Toast.makeText(this, "Instructor Profile clicked", Toast.LENGTH_SHORT).show()
                // TODO: Navigate to instructor profile activity
            }
            R.id.nav_my_courses -> {
                startActivity(Intent(this, InstructorCoursesActivity::class.java))
            }
            R.id.nav_analytics -> {
                startActivity(Intent(this, AnalyticsActivity::class.java))
            }
            R.id.nav_earnings -> {
                startActivity(Intent(this, EarningsActivity::class.java))
            }
            R.id.nav_students -> {
                startActivity(Intent(this, MyStudentsActivity::class.java))
            }
            R.id.nav_logout -> {
                logout()
            }
        }
        
        drawerLayout.closeDrawer(GravityCompat.START)
        return true
    }
    
    
    private fun logout() {
        // Clear user session data
        UserSession.clearUserSession(this)
        
        // Sign out from Firebase
        FirebaseAuth.getInstance().signOut()
        
        Toast.makeText(this, "Logged out successfully", Toast.LENGTH_SHORT).show()
        
        // Navigate back to role selection
        val intent = Intent(this, RoleSelectionActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(intent)
        finish()
    }
    
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        // Handle hamburger icon click with animation
        if (toggle.onOptionsItemSelected(item)) {
            return true
        }
        
        // Handle home button click manually if needed
        when (item.itemId) {
            android.R.id.home -> {
                if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
                    drawerLayout.closeDrawer(GravityCompat.START)
                } else {
                    drawerLayout.openDrawer(GravityCompat.START)
                }
                return true
            }
        }
        
        return super.onOptionsItemSelected(item)
    }
    
    private fun setupBackPressedCallback() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
                    drawerLayout.closeDrawer(GravityCompat.START)
                } else {
                    // Let the system handle the back press
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })
    }
    
    private fun loadUserInfo() {
        // First try to load from Firebase if user is logged in
        UserSession.loadUserInfoFromFirebase(this)
        
        // Then load from SharedPreferences and update UI
        val userName = UserSession.getUserName(this)
        val userEmail = UserSession.getUserEmail(this)
        
        Log.d("InstructorDashboard", "Loading user info - Name: '$userName', Email: '$userEmail'")
        
        tvUserName.text = userName
        tvUserEmail.text = userEmail
        
        // Ensure the TextViews are visible
        tvUserName.visibility = android.view.View.VISIBLE
        tvUserEmail.visibility = android.view.View.VISIBLE
        
        Log.d("InstructorDashboard", "User info updated in navigation header")
        
        // Load instructor statistics
        loadInstructorStats()
    }
    
    private fun loadInstructorStats() {
        val currentUser = FirebaseAuth.getInstance().currentUser
        if (currentUser == null) return
        
        val firestore = FirebaseFirestore.getInstance()
        
        // Load instructor's courses and calculate basic stats
        firestore.collection("courses")
            .whereEqualTo("instructorId", currentUser.uid)
            .get()
            .addOnSuccessListener { documents ->
                var totalCourses = 0
                var totalStudents = 0
                
                for (document in documents) {
                    totalCourses++
                    val enrollmentCount = (document.data["enrollmentCount"] as? Long)?.toInt() ?: 0
                    totalStudents += enrollmentCount
                }
                
                // Update the statistics in the overview section
                updateStatsUI(totalCourses, totalStudents)
            }
            .addOnFailureListener { e ->
                Log.w("InstructorDashboard", "Error loading stats", e)
            }
    }
    
    private fun updateStatsUI(totalCourses: Int, totalStudents: Int) {
        // Update the statistics TextViews in the dashboard
        tvCoursesCount.text = totalCourses.toString()
        tvStudentsCount.text = totalStudents.toString()
    }
}
