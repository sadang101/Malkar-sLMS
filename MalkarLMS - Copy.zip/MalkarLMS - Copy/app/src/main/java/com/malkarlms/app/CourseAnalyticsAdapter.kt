package com.malkarlms.app

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class CourseAnalyticsAdapter(
    private val courseAnalyticsList: List<CourseAnalytics>
) : RecyclerView.Adapter<CourseAnalyticsAdapter.ViewHolder>() {
    
    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvCourseTitle: TextView = itemView.findViewById(R.id.tvCourseTitle)
        val tvStatus: TextView = itemView.findViewById(R.id.tvStatus)
        val tvEnrollments: TextView = itemView.findViewById(R.id.tvEnrollments)
        val tvViews: TextView = itemView.findViewById(R.id.tvViews)
        val tvEarnings: TextView = itemView.findViewById(R.id.tvEarnings)
        val tvRating: TextView = itemView.findViewById(R.id.tvRating)
    }
    
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_course_analytics, parent, false)
        return ViewHolder(view)
    }
    
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val courseAnalytics = courseAnalyticsList[position]
        
        holder.tvCourseTitle.text = courseAnalytics.title
        holder.tvStatus.text = if (courseAnalytics.isPublished) "Published" else "Draft"
        holder.tvStatus.setTextColor(
            if (courseAnalytics.isPublished) 
                holder.itemView.context.getColor(R.color.success)
            else 
                holder.itemView.context.getColor(R.color.warning)
        )
        
        holder.tvEnrollments.text = "${courseAnalytics.enrollmentCount} students"
        holder.tvViews.text = "${courseAnalytics.views} views"
        holder.tvEarnings.text = "₹${String.format("%.2f", courseAnalytics.earnings)}"
        holder.tvRating.text = "${String.format("%.1f", courseAnalytics.rating)} (${courseAnalytics.reviewCount})"
    }
    
    override fun getItemCount(): Int = courseAnalyticsList.size
}
