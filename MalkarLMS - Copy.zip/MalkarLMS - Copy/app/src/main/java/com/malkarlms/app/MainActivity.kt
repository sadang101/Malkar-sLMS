package com.malkarlms.app

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth

class MainActivity : AppCompatActivity() {
    
    private lateinit var auth: FirebaseAuth
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        
        auth = FirebaseAuth.getInstance()
        
        // Show splash for 2 seconds then check auth
        Handler(Looper.getMainLooper()).postDelayed({
            checkAuthState()
        }, 2000)
    }
    
    private fun checkAuthState() {
        val currentUser = auth.currentUser
        val intent = if (currentUser != null) {
            // User is logged in, check their role and navigate accordingly
            val userRole = UserSession.getUserRole(this)
            when (userRole) {
                UserRole.INSTRUCTOR -> Intent(this, InstructorDashboardActivity::class.java)
                UserRole.STUDENT -> Intent(this, DashboardActivity::class.java)
                UserRole.ADMIN -> Intent(this, DashboardActivity::class.java) // Admin uses student dashboard for now
            }
        } else {
            // User not logged in, go to role selection
            Intent(this, RoleSelectionActivity::class.java)
        }
        
        startActivity(intent)
        finish()
    }
}