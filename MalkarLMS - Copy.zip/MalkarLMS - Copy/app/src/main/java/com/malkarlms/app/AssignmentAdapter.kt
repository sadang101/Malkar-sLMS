package com.malkarlms.app

import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class AssignmentAdapter(
    private val assignments: List<Assignment>,
    private val onAssignmentClick: (Assignment) -> Unit
) : RecyclerView.Adapter<AssignmentAdapter.AssignmentViewHolder>() {

    class AssignmentViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvAssignmentTitle: TextView = view.findViewById(R.id.tvAssignmentTitle)
        val tvAssignmentDescription: TextView = view.findViewById(R.id.tvAssignmentDescription)
        val tvAssignmentStatus: TextView = view.findViewById(R.id.tvAssignmentStatus)
        val tvDueDate: TextView = view.findViewById(R.id.tvDueDate)
        val scoreContainer: View = view.findViewById(R.id.scoreContainer)
        val tvScore: TextView = view.findViewById(R.id.tvScore)
        val submittedDateContainer: View = view.findViewById(R.id.submittedDateContainer)
        val tvSubmittedDate: TextView = view.findViewById(R.id.tvSubmittedDate)
        val btnAssignmentAction: Button = view.findViewById(R.id.btnAssignmentAction)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AssignmentViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_assignment, parent, false)
        return AssignmentViewHolder(view)
    }

    override fun onBindViewHolder(holder: AssignmentViewHolder, position: Int) {
        val assignment = assignments[position]
        
        holder.tvAssignmentTitle.text = assignment.title
        holder.tvAssignmentDescription.text = assignment.description
        holder.tvDueDate.text = assignment.dueDate
        
        // Reset visibility for all containers
        holder.scoreContainer.visibility = View.GONE
        holder.submittedDateContainer.visibility = View.GONE
        
        // Status badge
        when (assignment.status) {
            AssignmentStatus.NOT_STARTED -> {
                holder.tvAssignmentStatus.text = "NOT STARTED"
                holder.tvAssignmentStatus.setBackgroundColor(Color.parseColor("#9E9E9E"))
                holder.btnAssignmentAction.text = "Start Assignment"
            }
            AssignmentStatus.IN_PROGRESS -> {
                holder.tvAssignmentStatus.text = "IN PROGRESS"
                holder.tvAssignmentStatus.setBackgroundColor(Color.parseColor("#FF9800"))
                holder.btnAssignmentAction.text = "Continue"
            }
            AssignmentStatus.SUBMITTED -> {
                holder.tvAssignmentStatus.text = "SUBMITTED"
                holder.tvAssignmentStatus.setBackgroundColor(Color.parseColor("#2196F3"))
                holder.btnAssignmentAction.text = "View Submission"
                
                // Show submitted date
                assignment.submittedDate?.let {
                    holder.submittedDateContainer.visibility = View.VISIBLE
                    holder.tvSubmittedDate.text = it
                }
            }
            AssignmentStatus.GRADED -> {
                holder.tvAssignmentStatus.text = "GRADED"
                holder.tvAssignmentStatus.setBackgroundColor(Color.parseColor("#4CAF50"))
                holder.btnAssignmentAction.text = "View Results"
                
                // Show score
                assignment.score?.let { score ->
                    holder.scoreContainer.visibility = View.VISIBLE
                    holder.tvScore.text = "$score/${assignment.maxScore}"
                    
                    // Color based on percentage
                    val percentage = (score.toFloat() / assignment.maxScore) * 100
                    val color = when {
                        percentage >= 80 -> Color.parseColor("#4CAF50") // Green
                        percentage >= 60 -> Color.parseColor("#FF9800") // Orange
                        else -> Color.parseColor("#F44336") // Red
                    }
                    holder.tvScore.setTextColor(color)
                }
                
                // Show submitted date
                assignment.submittedDate?.let {
                    holder.submittedDateContainer.visibility = View.VISIBLE
                    holder.tvSubmittedDate.text = it
                }
            }
            AssignmentStatus.OVERDUE -> {
                holder.tvAssignmentStatus.text = "OVERDUE"
                holder.tvAssignmentStatus.setBackgroundColor(Color.parseColor("#F44336"))
                holder.btnAssignmentAction.text = "Submit Late"
            }
        }
        
        // Click listener
        holder.btnAssignmentAction.setOnClickListener {
            onAssignmentClick(assignment)
        }
    }

    override fun getItemCount() = assignments.size
}
