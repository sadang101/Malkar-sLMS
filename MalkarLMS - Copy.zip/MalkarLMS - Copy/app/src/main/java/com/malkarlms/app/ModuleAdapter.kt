package com.malkarlms.app

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ProgressBar
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class ModuleAdapter(
    private val modules: List<CourseModule>,
    private val onModuleClick: (CourseModule) -> Unit
) : RecyclerView.Adapter<ModuleAdapter.ModuleViewHolder>() {

    class ModuleViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvModuleNumber: TextView = view.findViewById(R.id.tvModuleNumber)
        val tvModuleTitle: TextView = view.findViewById(R.id.tvModuleTitle)
        val tvModuleDescription: TextView = view.findViewById(R.id.tvModuleDescription)
        val tvDuration: TextView = view.findViewById(R.id.tvDuration)
        val tvDocuments: TextView = view.findViewById(R.id.tvDocuments)
        val tvQuizScore: TextView = view.findViewById(R.id.tvQuizScore)
        val tvCompletionStatus: TextView = view.findViewById(R.id.tvCompletionStatus)
        val progressContainer: View = view.findViewById(R.id.progressContainer)
        val moduleProgressBar: ProgressBar = view.findViewById(R.id.moduleProgressBar)
        val tvModuleProgress: TextView = view.findViewById(R.id.tvModuleProgress)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ModuleViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_module, parent, false)
        return ModuleViewHolder(view)
    }

    override fun onBindViewHolder(holder: ModuleViewHolder, position: Int) {
        val module = modules[position]
        
        holder.tvModuleNumber.text = module.moduleNumber.toString()
        holder.tvModuleTitle.text = module.title
        holder.tvModuleDescription.text = module.description
        holder.tvDuration.text = "⏱️ ${module.duration}"
        
        // Documents count
        if (module.documentsCount > 0) {
            holder.tvDocuments.text = "📄 ${module.documentsCount} docs"
            holder.tvDocuments.visibility = View.VISIBLE
        } else {
            holder.tvDocuments.visibility = View.GONE
        }
        
        // Show completion status or progress
        if (module.isCompleted) {
            holder.tvCompletionStatus.visibility = View.VISIBLE
            holder.progressContainer.visibility = View.GONE
            
            // Show quiz score if available
            module.quizScore?.let { score ->
                holder.tvQuizScore.text = "📊 $score%"
                holder.tvQuizScore.visibility = View.VISIBLE
                
                // Color based on score
                val color = when {
                    score >= 80 -> android.graphics.Color.parseColor("#4CAF50") // Green
                    score >= 60 -> android.graphics.Color.parseColor("#FF9800") // Orange
                    else -> android.graphics.Color.parseColor("#F44336") // Red
                }
                holder.tvQuizScore.setTextColor(color)
            } ?: run {
                holder.tvQuizScore.visibility = View.GONE
            }
        } else {
            holder.tvCompletionStatus.visibility = View.GONE
            holder.tvQuizScore.visibility = View.GONE
            
            // Show progress for incomplete modules
            if (module.progress > 0) {
                holder.progressContainer.visibility = View.VISIBLE
                holder.moduleProgressBar.progress = module.progress
                holder.tvModuleProgress.text = "${module.progress}%"
            } else {
                holder.progressContainer.visibility = View.GONE
            }
        }
        
        // Click listener
        holder.itemView.setOnClickListener {
            onModuleClick(module)
        }
    }

    override fun getItemCount() = modules.size
}
