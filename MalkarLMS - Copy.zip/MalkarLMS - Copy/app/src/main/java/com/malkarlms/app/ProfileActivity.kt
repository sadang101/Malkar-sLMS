package com.malkarlms.app

import android.app.DatePickerDialog
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import java.util.*

class ProfileActivity : AppCompatActivity() {
    
    override fun attachBaseContext(newBase: Context) {
        val languageCode = LocaleHelper.getLanguage(newBase)
        val context = LocaleHelper.setLocale(newBase, languageCode)
        super.attachBaseContext(context)
    }
    
    // Header views
    private lateinit var btnBack: TextView
    private lateinit var ivProfilePicture: ImageView
    private lateinit var btnEditPhoto: TextView
    private lateinit var tvUserName: TextView
    private lateinit var tvUserEmail: TextView
    private lateinit var profileCompletionBanner: View
    private lateinit var tvCompletionMessage: TextView
    private lateinit var progressBarCompletion: ProgressBar
    private lateinit var tvCompletionPercent: TextView
    private lateinit var btnEditProfile: Button
    
    // Form views
    private lateinit var profileFormCard: View
    private lateinit var etFullName: EditText
    private lateinit var spinnerCountryCode: Spinner
    private lateinit var etPhone: EditText
    private lateinit var etDateOfBirth: EditText
    private lateinit var spinnerGender: Spinner
    private lateinit var etCity: EditText
    private lateinit var spinnerState: Spinner
    private lateinit var etPincode: EditText
    private lateinit var spinnerEducation: Spinner
    private lateinit var etOccupation: EditText
    private lateinit var etBio: EditText
    private lateinit var btnSaveProfile: Button
    private lateinit var btnCancelEdit: Button
    
    // Account actions
    private lateinit var btnChangePassword: Button
    private lateinit var btnLogout: Button
    private lateinit var progressBar: ProgressBar
    
    private lateinit var auth: FirebaseAuth
    private lateinit var firestore: FirebaseFirestore
    
    private var isEditMode = false
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)
        
        initFirebase()
        initViews()
        setupSpinners()
        setupClickListeners()
        loadUserProfile()
    }
    
    private fun initFirebase() {
        auth = FirebaseAuth.getInstance()
        firestore = FirebaseFirestore.getInstance()
    }
    
    private fun initViews() {
        try {
            // Header views
            btnBack = findViewById(R.id.btnBack)
            ivProfilePicture = findViewById(R.id.ivProfilePicture)
            btnEditPhoto = findViewById(R.id.btnEditPhoto)
            tvUserName = findViewById(R.id.tvUserName)
            tvUserEmail = findViewById(R.id.tvUserEmail)
            profileCompletionBanner = findViewById(R.id.profileCompletionBanner)
            tvCompletionMessage = findViewById(R.id.tvCompletionMessage)
            progressBarCompletion = findViewById(R.id.progressBarCompletion)
            tvCompletionPercent = findViewById(R.id.tvCompletionPercent)
            btnEditProfile = findViewById(R.id.btnEditProfile)
            
            // Form views
            profileFormCard = findViewById(R.id.profileFormCard)
            etFullName = findViewById(R.id.etFullName)
            spinnerCountryCode = findViewById(R.id.spinnerCountryCode)
            etPhone = findViewById(R.id.etPhone)
            etDateOfBirth = findViewById(R.id.etDateOfBirth)
            spinnerGender = findViewById(R.id.spinnerGender)
            etCity = findViewById(R.id.etCity)
            spinnerState = findViewById(R.id.spinnerState)
            etPincode = findViewById(R.id.etPincode)
            spinnerEducation = findViewById(R.id.spinnerEducation)
            etOccupation = findViewById(R.id.etOccupation)
            etBio = findViewById(R.id.etBio)
            btnSaveProfile = findViewById(R.id.btnSaveProfile)
            btnCancelEdit = findViewById(R.id.btnCancelEdit)
            
            // Account actions
            btnChangePassword = findViewById(R.id.btnChangePassword)
            btnLogout = findViewById(R.id.btnLogout)
            progressBar = findViewById(R.id.progressBar)
            
            Log.d("Profile", "Views initialized successfully")
        } catch (e: Exception) {
            Log.e("Profile", "Error initializing views: ${e.message}", e)
            Toast.makeText(this, "Error loading profile interface", Toast.LENGTH_SHORT).show()
            finish()
        }
    }
    
    private fun setupSpinners() {
        // Country Code spinner
        val countryCodes = arrayOf(
            "🇮🇳 +91 (India)",
            "🇺🇸 +1 (USA)",
            "🇬🇧 +44 (UK)",
            "🇨🇦 +1 (Canada)",
            "🇦🇺 +61 (Australia)",
            "🇦🇪 +971 (UAE)",
            "🇸🇬 +65 (Singapore)",
            "🇩🇪 +49 (Germany)",
            "🇫🇷 +33 (France)",
            "🇯🇵 +81 (Japan)",
            "🇨🇳 +86 (China)",
            "🇧🇷 +55 (Brazil)",
            "🇿🇦 +27 (South Africa)",
            "🇳🇿 +64 (New Zealand)",
            "🇮🇹 +39 (Italy)",
            "🇪🇸 +34 (Spain)",
            "🇲🇽 +52 (Mexico)",
            "🇰🇷 +82 (South Korea)",
            "🇷🇺 +7 (Russia)",
            "🇸🇦 +966 (Saudi Arabia)"
        )
        val countryCodeAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, countryCodes)
        countryCodeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerCountryCode.adapter = countryCodeAdapter
        spinnerCountryCode.setSelection(0) // Default to India
        
        // Gender spinner
        val genders = arrayOf("Select Gender", "Male", "Female", "Other", "Prefer not to say")
        val genderAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, genders)
        genderAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerGender.adapter = genderAdapter
        
        // State spinner (Indian states)
        val states = arrayOf(
            "Select State", "Andhra Pradesh", "Arunachal Pradesh", "Assam", "Bihar", "Chhattisgarh",
            "Goa", "Gujarat", "Haryana", "Himachal Pradesh", "Jharkhand", "Karnataka", "Kerala",
            "Madhya Pradesh", "Maharashtra", "Manipur", "Meghalaya", "Mizoram", "Nagaland",
            "Odisha", "Punjab", "Rajasthan", "Sikkim", "Tamil Nadu", "Telangana", "Tripura",
            "Uttar Pradesh", "Uttarakhand", "West Bengal", "Delhi", "Puducherry"
        )
        val stateAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, states)
        stateAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerState.adapter = stateAdapter
        
        // Education spinner
        val education = arrayOf(
            "Select Education", "High School", "Diploma", "Bachelor's Degree",
            "Master's Degree", "PhD", "Other"
        )
        val educationAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, education)
        educationAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerEducation.adapter = educationAdapter
    }
    
    private fun setupClickListeners() {
        btnBack.setOnClickListener { finish() }
        
        btnEditProfile.setOnClickListener {
            toggleEditMode(true)
        }
        
        btnCancelEdit.setOnClickListener {
            toggleEditMode(false)
        }
        
        btnSaveProfile.setOnClickListener {
            saveProfile()
        }
        
        btnChangePassword.setOnClickListener {
            changePassword()
        }
        
        btnLogout.setOnClickListener {
            logout()
        }
        
        // Date picker
        etDateOfBirth.setOnClickListener {
            showDatePicker()
        }
    }
    
    private fun toggleEditMode(edit: Boolean) {
        isEditMode = edit
        profileFormCard.visibility = if (edit) View.VISIBLE else View.GONE
        
        if (edit) {
            // Scroll to form
            profileFormCard.requestFocus()
        }
    }
    
    private fun showDatePicker() {
        val calendar = Calendar.getInstance()
        val year = calendar.get(Calendar.YEAR)
        val month = calendar.get(Calendar.MONTH)
        val day = calendar.get(Calendar.DAY_OF_MONTH)
        
        val datePickerDialog = DatePickerDialog(
            this,
            { _, selectedYear, selectedMonth, selectedDay ->
                val date = String.format("%02d/%02d/%d", selectedDay, selectedMonth + 1, selectedYear)
                etDateOfBirth.setText(date)
            },
            year, month, day
        )
        
        // Set max date to 18 years ago
        calendar.add(Calendar.YEAR, -18)
        datePickerDialog.datePicker.maxDate = calendar.timeInMillis
        
        datePickerDialog.show()
    }
    
    private fun loadUserProfile() {
        val currentUser = auth.currentUser
        if (currentUser == null) {
            Toast.makeText(this, "Please login first", Toast.LENGTH_SHORT).show()
            finish()
            return
        }
        
        showLoading(true)
        
        // Load from Firebase Auth
        val displayName = currentUser.displayName ?: "User"
        val email = currentUser.email ?: ""
        
        tvUserName.text = displayName
        tvUserEmail.text = email
        etFullName.setText(displayName)
        
        // Load additional info from Firestore
        firestore.collection("users")
            .document(currentUser.uid)
            .get()
            .addOnSuccessListener { document ->
                showLoading(false)
                
                if (document.exists()) {
                    val userData = document.data ?: return@addOnSuccessListener
                    
                    // Load all fields
                    val countryCode = userData["countryCode"] as? String
                    countryCode?.let { setSpinnerSelection(spinnerCountryCode, it) }
                    
                    etPhone.setText(userData["phone"] as? String ?: "")
                    etDateOfBirth.setText(userData["dateOfBirth"] as? String ?: "")
                    etCity.setText(userData["city"] as? String ?: "")
                    etPincode.setText(userData["pincode"] as? String ?: "")
                    etOccupation.setText(userData["occupation"] as? String ?: "")
                    etBio.setText(userData["bio"] as? String ?: "")
                    
                    // Set spinner selections
                    val gender = userData["gender"] as? String
                    gender?.let { setSpinnerSelection(spinnerGender, it) }
                    
                    val state = userData["state"] as? String
                    state?.let { setSpinnerSelection(spinnerState, it) }
                    
                    val education = userData["education"] as? String
                    education?.let { setSpinnerSelection(spinnerEducation, it) }
                    
                    // Calculate and show profile completion
                    calculateProfileCompletion(userData)
                    
                    Log.d("Profile", "Profile loaded successfully")
                } else {
                    Log.d("Profile", "No additional profile data found")
                    calculateProfileCompletion(emptyMap())
                }
            }
            .addOnFailureListener { e ->
                showLoading(false)
                Log.e("Profile", "Error loading profile: ${e.message}", e)
                Toast.makeText(this, "Error loading profile: ${e.message}", Toast.LENGTH_LONG).show()
            }
    }
    
    private fun setSpinnerSelection(spinner: Spinner, value: String) {
        val adapter = spinner.adapter as ArrayAdapter<String>
        val position = adapter.getPosition(value)
        if (position >= 0) {
            spinner.setSelection(position)
        }
    }
    
    private fun calculateProfileCompletion(userData: Map<String, Any>) {
        val requiredFields = listOf(
            "fullName" to (userData["fullName"] as? String),
            "phone" to (userData["phone"] as? String),
            "dateOfBirth" to (userData["dateOfBirth"] as? String),
            "gender" to (userData["gender"] as? String),
            "city" to (userData["city"] as? String),
            "state" to (userData["state"] as? String),
            "pincode" to (userData["pincode"] as? String)
        )
        
        val completedFields = requiredFields.count { (_, value) ->
            !value.isNullOrEmpty() && value != "Select Gender" && value != "Select State"
        }
        
        val totalFields = requiredFields.size
        val completionPercent = (completedFields * 100) / totalFields
        
        progressBarCompletion.progress = completionPercent
        tvCompletionPercent.text = "$completionPercent% Complete"
        
        if (completionPercent == 100) {
            profileCompletionBanner.visibility = View.GONE
        } else {
            profileCompletionBanner.visibility = View.VISIBLE
            val remaining = totalFields - completedFields
            tvCompletionMessage.text = "Complete $remaining more field${if (remaining > 1) "s" else ""} to unlock all features"
        }
    }
    
    private fun saveProfile() {
        if (!validateInputs()) return
        
        val currentUser = auth.currentUser
        if (currentUser == null) {
            Toast.makeText(this, "Please login first", Toast.LENGTH_SHORT).show()
            return
        }
        
        showLoading(true)
        
        val profileData = hashMapOf(
            "fullName" to etFullName.text.toString().trim(),
            "email" to currentUser.email,
            "countryCode" to spinnerCountryCode.selectedItem.toString(),
            "phone" to etPhone.text.toString().trim(),
            "dateOfBirth" to etDateOfBirth.text.toString().trim(),
            "gender" to spinnerGender.selectedItem.toString(),
            "city" to etCity.text.toString().trim(),
            "state" to spinnerState.selectedItem.toString(),
            "pincode" to etPincode.text.toString().trim(),
            "education" to spinnerEducation.selectedItem.toString(),
            "occupation" to etOccupation.text.toString().trim(),
            "bio" to etBio.text.toString().trim(),
            "updatedAt" to System.currentTimeMillis()
        )
        
        // Update Firestore
        firestore.collection("users")
            .document(currentUser.uid)
            .set(profileData)
            .addOnSuccessListener {
                showLoading(false)
                
                // Update display
                tvUserName.text = etFullName.text.toString().trim()
                
                // Save to SharedPreferences
                val sharedPref = getSharedPreferences("user_session", android.content.Context.MODE_PRIVATE)
                with(sharedPref.edit()) {
                    putString("user_name", etFullName.text.toString().trim())
                    apply()
                }
                
                Toast.makeText(this, "Profile updated successfully! ✅", Toast.LENGTH_SHORT).show()
                Log.d("Profile", "Profile saved successfully")
                
                // Reload to update completion
                loadUserProfile()
                toggleEditMode(false)
            }
            .addOnFailureListener { e ->
                showLoading(false)
                Log.e("Profile", "Error saving profile: ${e.message}", e)
                Toast.makeText(this, "Failed to save profile: ${e.message}", Toast.LENGTH_LONG).show()
            }
    }
    
    private fun validateInputs(): Boolean {
        // Validate required fields
        val fullName = etFullName.text.toString().trim()
        if (fullName.isEmpty()) {
            etFullName.error = "Full name is required"
            etFullName.requestFocus()
            Toast.makeText(this, "Please enter your full name", Toast.LENGTH_SHORT).show()
            return false
        }
        
        val phone = etPhone.text.toString().trim()
        if (phone.isEmpty()) {
            etPhone.error = "Phone number is required"
            etPhone.requestFocus()
            Toast.makeText(this, "Please enter your phone number", Toast.LENGTH_SHORT).show()
            return false
        }
        if (phone.length < 10) {
            etPhone.error = "Invalid phone number"
            etPhone.requestFocus()
            Toast.makeText(this, "Please enter a valid 10-digit phone number", Toast.LENGTH_SHORT).show()
            return false
        }
        
        val dob = etDateOfBirth.text.toString().trim()
        if (dob.isEmpty()) {
            etDateOfBirth.error = "Date of birth is required"
            etDateOfBirth.requestFocus()
            Toast.makeText(this, "Please select your date of birth", Toast.LENGTH_SHORT).show()
            return false
        }
        
        if (spinnerGender.selectedItemPosition == 0) {
            Toast.makeText(this, "Please select your gender", Toast.LENGTH_SHORT).show()
            return false
        }
        
        val city = etCity.text.toString().trim()
        if (city.isEmpty()) {
            etCity.error = "City is required"
            etCity.requestFocus()
            Toast.makeText(this, "Please enter your city", Toast.LENGTH_SHORT).show()
            return false
        }
        
        if (spinnerState.selectedItemPosition == 0) {
            Toast.makeText(this, "Please select your state", Toast.LENGTH_SHORT).show()
            return false
        }
        
        val pincode = etPincode.text.toString().trim()
        if (pincode.isEmpty()) {
            etPincode.error = "Pincode is required"
            etPincode.requestFocus()
            Toast.makeText(this, "Please enter your pincode", Toast.LENGTH_SHORT).show()
            return false
        }
        if (pincode.length != 6) {
            etPincode.error = "Invalid pincode"
            etPincode.requestFocus()
            Toast.makeText(this, "Please enter a valid 6-digit pincode", Toast.LENGTH_SHORT).show()
            return false
        }
        
        return true
    }
    
    private fun changePassword() {
        val currentUser = auth.currentUser
        if (currentUser == null) {
            Toast.makeText(this, "Please login first", Toast.LENGTH_SHORT).show()
            return
        }
        
        val email = currentUser.email
        if (email.isNullOrEmpty()) {
            Toast.makeText(this, "Email not found", Toast.LENGTH_SHORT).show()
            return
        }
        
        auth.sendPasswordResetEmail(email)
            .addOnSuccessListener {
                Toast.makeText(this, "Password reset email sent to $email", Toast.LENGTH_LONG).show()
            }
            .addOnFailureListener { e ->
                Toast.makeText(this, "Failed to send reset email: ${e.message}", Toast.LENGTH_LONG).show()
            }
    }
    
    private fun logout() {
        auth.signOut()
        
        // Clear session manually
        val sharedPref = getSharedPreferences("user_session", android.content.Context.MODE_PRIVATE)
        with(sharedPref.edit()) {
            clear()
            apply()
        }
        
        Toast.makeText(this, "Logged out successfully", Toast.LENGTH_SHORT).show()
        
        val intent = Intent(this, LoginActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(intent)
        finish()
    }
    
    private fun showLoading(show: Boolean) {
        progressBar.visibility = if (show) android.view.View.VISIBLE else android.view.View.GONE
        btnSaveProfile.isEnabled = !show
        btnChangePassword.isEnabled = !show
    }
    
    override fun onSupportNavigateUp(): Boolean {
        onBackPressedDispatcher.onBackPressed()
        return true
    }
}
