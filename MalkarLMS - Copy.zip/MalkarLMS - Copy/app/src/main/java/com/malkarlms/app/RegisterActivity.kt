package com.malkarlms.app

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.util.Patterns
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class RegisterActivity : AppCompatActivity() {
    
    private lateinit var etFullName: EditText
    private lateinit var etEmail: EditText
    private lateinit var etPassword: EditText
    private lateinit var etConfirmPassword: EditText
    private lateinit var btnRegister: Button
    private lateinit var tvLogin: TextView
    
    // Firebase instances
    private lateinit var auth: FirebaseAuth
    private lateinit var firestore: FirebaseFirestore
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)
        
        // Display the selected role
        val selectedRole = intent.getStringExtra("USER_ROLE") ?: UserRole.STUDENT.name
        val roleText = when (selectedRole) {
            UserRole.INSTRUCTOR.name -> "Instructor Registration"
            UserRole.STUDENT.name -> "Student Registration"
            else -> "Create Account"
        }
        title = roleText
        
        // Initialize Firebase with comprehensive error checking
        try {
            // Check Firebase configuration first
            val configResult = FirebaseConfigChecker.checkConfiguration(this)
            if (!configResult.isValid) {
                Log.e("RegisterActivity", "❌ Firebase configuration issues found:")
                configResult.issues.forEach { issue ->
                    Log.e("RegisterActivity", issue)
                }
                Toast.makeText(this, "Firebase configuration error. Check logs for details.", Toast.LENGTH_LONG).show()
            }
            
            auth = FirebaseAuth.getInstance()
            firestore = FirebaseFirestore.getInstance()
            Log.d("RegisterActivity", "✅ Firebase initialized successfully")
            
            // Test Firebase connectivity
            testFirebaseConnection()
        } catch (e: Exception) {
            Log.e("RegisterActivity", "❌ Firebase initialization failed", e)
            Toast.makeText(this, "Firebase setup error: ${e.message}", Toast.LENGTH_LONG).show()
        }
        
        initViews()
        setupClickListeners()
    }
    
    private fun testFirebaseConnection() {
        try {
            // Test Firebase Auth connectivity
            auth.addAuthStateListener { firebaseAuth ->
                Log.d("RegisterActivity", "Firebase Auth state: ${firebaseAuth.currentUser?.email ?: "No user"}")
            }
            
            // Test Firestore connectivity (simple read operation)
            firestore.collection("test").limit(1).get()
                .addOnSuccessListener {
                    Log.d("RegisterActivity", "✅ Firestore connection successful")
                }
                .addOnFailureListener { e ->
                    Log.w("RegisterActivity", "⚠️ Firestore connection issue: ${e.message}")
                }
        } catch (e: Exception) {
            Log.e("RegisterActivity", "❌ Firebase connection test failed", e)
        }
    }
    
    private fun initViews() {
        etFullName = findViewById(R.id.etFullName)
        etEmail = findViewById(R.id.etEmail)
        etPassword = findViewById(R.id.etPassword)
        etConfirmPassword = findViewById(R.id.etConfirmPassword)
        btnRegister = findViewById(R.id.btnRegister)
        tvLogin = findViewById(R.id.tvLogin)
    }
    
    private fun setupClickListeners() {
        btnRegister.setOnClickListener {
            performRegistration()
        }
        
        tvLogin.setOnClickListener {
            finish() // Go back to login activity
        }
    }
    
    private fun performRegistration() {
        val fullName = etFullName.text.toString().trim()
        val email = etEmail.text.toString().trim()
        val password = etPassword.text.toString().trim()
        val confirmPassword = etConfirmPassword.text.toString().trim()
        
        // Reset errors
        etFullName.error = null
        etEmail.error = null
        etPassword.error = null
        etConfirmPassword.error = null
        
        var isValid = true
        
        // Validate full name
        if (fullName.isEmpty()) {
            etFullName.error = "Full name is required"
            isValid = false
        } else if (fullName.length < 2) {
            etFullName.error = "Full name must be at least 2 characters"
            isValid = false
        }
        
        // Validate email
        if (email.isEmpty()) {
            etEmail.error = "Email is required"
            isValid = false
        } else if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            etEmail.error = "Invalid email format"
            isValid = false
        }
        
        // Validate password
        if (password.isEmpty()) {
            etPassword.error = "Password is required"
            isValid = false
        } else if (password.length < 6) {
            etPassword.error = "Password must be at least 6 characters"
            isValid = false
        }
        
        // Validate confirm password
        if (confirmPassword.isEmpty()) {
            etConfirmPassword.error = "Confirm password is required"
            isValid = false
        } else if (password != confirmPassword) {
            etConfirmPassword.error = "Passwords do not match"
            isValid = false
        }
        
        if (isValid) {
            // Check network connectivity first
            if (!isNetworkAvailable()) {
                Toast.makeText(this, "No internet connection. Please check your network and try again.", Toast.LENGTH_LONG).show()
                return
            }
            
            // Perform Firebase Registration with enhanced error handling
            registerWithRetry(email, password, fullName, 0)
        }
    }
    
    private fun registerWithRetry(email: String, password: String, fullName: String, retryCount: Int) {
        val maxRetries = 3
        
        btnRegister.isEnabled = false
        btnRegister.text = if (retryCount > 0) "Retrying... (${retryCount + 1}/$maxRetries)" else "Creating Account..."
        
        auth.createUserWithEmailAndPassword(email, password)
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {
                    Log.d("RegisterActivity", "createUserWithEmail:success")
                    val user = auth.currentUser
                    
                    // Save user data to Firestore
                    saveUserToFirestore(user?.uid ?: "", fullName, email)
                    
                } else {
                    val exception = task.exception
                    Log.w("RegisterActivity", "createUserWithEmail:failure", exception)
                    
                    // Log detailed error information for debugging
                    Log.e("RegisterActivity", "Firebase Auth Error Details:")
                    Log.e("RegisterActivity", "- Exception type: ${exception?.javaClass?.simpleName}")
                    Log.e("RegisterActivity", "- Error message: ${exception?.message}")
                    Log.e("RegisterActivity", "- Error code: ${(exception as? com.google.firebase.auth.FirebaseAuthException)?.errorCode}")
                    Log.e("RegisterActivity", "- Email: $email")
                    Log.e("RegisterActivity", "- Retry count: $retryCount")
                    
                    // Enhanced error handling with specific error messages
                    val errorMessage = when {
                        exception?.message?.contains("network", true) == true -> {
                            if (retryCount < maxRetries) {
                                // Retry for network errors
                                android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
                                    registerWithRetry(email, password, fullName, retryCount + 1)
                                }, 2000) // Wait 2 seconds before retry
                                return@addOnCompleteListener
                            } else {
                                "Network error: Please check your internet connection and try again."
                            }
                        }
                        exception?.message?.contains("timeout", true) == true -> {
                            if (retryCount < maxRetries) {
                                // Retry for timeout errors
                                android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
                                    registerWithRetry(email, password, fullName, retryCount + 1)
                                }, 3000) // Wait 3 seconds before retry
                                return@addOnCompleteListener
                            } else {
                                "Connection timeout: Please try again later."
                            }
                        }
                        exception?.message?.contains("email-already-in-use", true) == true -> 
                            "This email is already registered. Please use a different email or try logging in."
                        exception?.message?.contains("weak-password", true) == true -> 
                            "Password is too weak. Please use a stronger password."
                        exception?.message?.contains("invalid-email", true) == true -> 
                            "Invalid email format. Please check your email address."
                        exception?.message?.contains("too-many-requests", true) == true -> 
                            "Too many attempts. Please wait a few minutes before trying again."
                        exception?.message?.contains("internal", true) == true -> 
                            "Firebase internal error. Please check your Firebase configuration and try again."
                        (exception as? com.google.firebase.auth.FirebaseAuthException)?.errorCode == "ERROR_INTERNAL" ->
                            "Firebase configuration error. Please check your google-services.json file."
                        else -> {
                            val detailedMessage = "Registration failed: ${exception?.message ?: "Unknown error occurred"}"
                            Log.e("RegisterActivity", "Unhandled error: $detailedMessage")
                            detailedMessage
                        }
                    }
                    
                    btnRegister.isEnabled = true
                    btnRegister.text = "Register"
                    Toast.makeText(this, errorMessage, Toast.LENGTH_LONG).show()
                }
            }
    }
    
    private fun isNetworkAvailable(): Boolean {
        return try {
            val connectivityManager = getSystemService(android.content.Context.CONNECTIVITY_SERVICE) as android.net.ConnectivityManager
            val activeNetwork = connectivityManager.activeNetworkInfo
            activeNetwork?.isConnectedOrConnecting == true
        } catch (e: Exception) {
            Log.e("RegisterActivity", "Error checking network connectivity", e)
            true // Assume network is available if we can't check
        }
    }
    
    private fun saveUserToFirestore(userId: String, fullName: String, email: String) {
        // Get role from intent or default to student
        val userRole = intent.getStringExtra("USER_ROLE") ?: UserRole.STUDENT.name
        
        val userData = hashMapOf(
            "fullName" to fullName,
            "email" to email,
            "createdAt" to System.currentTimeMillis(),
            "role" to userRole.lowercase()
        )
        
        firestore.collection("users").document(userId)
            .set(userData)
            .addOnSuccessListener {
                Log.d("RegisterActivity", "User data saved to Firestore")
                
                // Save user information and role to session
                UserSession.saveUserInfo(this, fullName, email)
                val role = try {
                    UserRole.valueOf(userRole)
                } catch (e: IllegalArgumentException) {
                    UserRole.STUDENT
                }
                UserSession.saveUserRole(this, role)
                
                btnRegister.isEnabled = true
                btnRegister.text = "Register"
                Toast.makeText(this, "Registration successful! Welcome $fullName", Toast.LENGTH_SHORT).show()
                
                // Navigate to appropriate dashboard based on role
                val dashboardIntent = when (role) {
                    UserRole.INSTRUCTOR -> Intent(this, InstructorDashboardActivity::class.java)
                    UserRole.STUDENT -> Intent(this, DashboardActivity::class.java)
                    UserRole.ADMIN -> Intent(this, DashboardActivity::class.java)
                }
                startActivity(dashboardIntent)
                finish()
            }
            .addOnFailureListener { e ->
                Log.w("RegisterActivity", "Error saving user data", e)
                
                // Still save user information and role to session even if Firestore fails
                UserSession.saveUserInfo(this, fullName, email)
                val role = try {
                    UserRole.valueOf(userRole)
                } catch (e: IllegalArgumentException) {
                    UserRole.STUDENT
                }
                UserSession.saveUserRole(this, role)
                
                btnRegister.isEnabled = true
                btnRegister.text = "Register"
                Toast.makeText(this, "Registration completed but failed to save profile: ${e.message}", Toast.LENGTH_LONG).show()
                
                // Still navigate to appropriate dashboard since auth was successful
                val dashboardIntent = when (role) {
                    UserRole.INSTRUCTOR -> Intent(this, InstructorDashboardActivity::class.java)
                    UserRole.STUDENT -> Intent(this, DashboardActivity::class.java)
                    UserRole.ADMIN -> Intent(this, DashboardActivity::class.java)
                }
                startActivity(dashboardIntent)
                finish()
            }
    }
}
