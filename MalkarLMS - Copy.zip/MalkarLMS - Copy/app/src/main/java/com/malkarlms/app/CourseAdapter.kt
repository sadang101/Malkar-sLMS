package com.malkarlms.app

import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class CourseAdapter(
    private val courses: List<Course>,
    private val onCourseClick: (Course) -> Unit
) : RecyclerView.Adapter<CourseAdapter.CourseViewHolder>() {
    
    init {
        setHasStableIds(true)
    }

    class CourseViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val titleTextView: TextView = itemView.findViewById(R.id.tvCourseTitle)
        val descriptionTextView: TextView = itemView.findViewById(R.id.tvCourseDescription)
        val instructorTextView: TextView = itemView.findViewById(R.id.tvInstructor)
        val ratingTextView: TextView = itemView.findViewById(R.id.tvRating)
        val studentsTextView: TextView = itemView.findViewById(R.id.tvStudents)
        val durationTextView: TextView = itemView.findViewById(R.id.tvCourseDuration)
        val priceTextView: TextView = itemView.findViewById(R.id.tvCoursePrice)
        val levelTextView: TextView = itemView.findViewById(R.id.tvLevel)
        val categoryTextView: TextView = itemView.findViewById(R.id.tvCategory)
        val levelInfoTextView: TextView = itemView.findViewById(R.id.tvLevelInfo)
        val languageTextView: TextView = itemView.findViewById(R.id.tvLanguage)
        val modulesLecturesTextView: TextView = itemView.findViewById(R.id.tvModulesLectures)
        val certificateTextView: TextView = itemView.findViewById(R.id.tvCertificate)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CourseViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_course_card, parent, false)
        return CourseViewHolder(view)
    }

    override fun onBindViewHolder(holder: CourseViewHolder, position: Int) {
        try {
            if (position < 0 || position >= courses.size) {
                Log.e("CourseAdapter", "Invalid position: $position, size: ${courses.size}")
                return
            }
            
            val course = courses[position]
            
            // Basic info
            holder.titleTextView.text = course.title ?: "Unknown Course"
            holder.descriptionTextView.text = course.description ?: ""
            holder.instructorTextView.text = course.instructor ?: "Expert Instructor"
            holder.ratingTextView.text = course.rating.toString()
            holder.studentsTextView.text = formatStudentCount(course.studentsEnrolled)
            holder.durationTextView.text = course.duration ?: ""
            holder.priceTextView.text = course.price ?: "₹0"
            
            // Level badge with dynamic styling
            val level = course.level.ifEmpty { "Beginner" }
            holder.levelTextView.text = level
            setLevelBadgeStyle(holder.levelTextView, level)
            
            // Category
            holder.categoryTextView.text = course.category.ifEmpty { "General" }
            
            // Level info (for the grid section)
            holder.levelInfoTextView.text = when (level.lowercase()) {
                "beginner" -> "Beginner to Advanced"
                "intermediate" -> "Intermediate"
                "advanced" -> "Advanced"
                else -> level
            }
            
            // Language
            holder.languageTextView.text = course.language.ifEmpty { "English" }
            
            // Modules and lectures
            val modulesText = if (course.modulesCount > 0) {
                "${course.modulesCount} modules"
            } else {
                "Multiple modules"
            }
            val lecturesText = if (course.lecturesCount > 0) {
                "${course.lecturesCount} lectures"
            } else {
                "Multiple lectures"
            }
            holder.modulesLecturesTextView.text = "📚 $modulesText • $lecturesText"
            
            // Certificate
            if (course.certificateAvailable) {
                holder.certificateTextView.text = "🏆 Certificate included"
                holder.certificateTextView.visibility = View.VISIBLE
            } else {
                holder.certificateTextView.visibility = View.GONE
            }
            
            holder.itemView.setOnClickListener {
                try {
                    onCourseClick(course)
                } catch (e: Exception) {
                    Log.e("CourseAdapter", "Error in course click: ${e.message}", e)
                }
            }
        } catch (e: Exception) {
            Log.e("CourseAdapter", "Error binding view holder at position $position: ${e.message}", e)
        }
    }
    
    private fun setLevelBadgeStyle(textView: TextView, level: String) {
        val context = textView.context
        when (level.lowercase()) {
            "beginner" -> {
                textView.setBackgroundResource(R.drawable.level_badge_beginner)
                textView.setTextColor(context.getColor(R.color.success))
            }
            "intermediate" -> {
                textView.setBackgroundResource(R.drawable.level_badge_intermediate)
                textView.setTextColor(context.getColor(R.color.warning))
            }
            "advanced" -> {
                textView.setBackgroundResource(R.drawable.level_badge_advanced)
                textView.setTextColor(context.getColor(R.color.error))
            }
            else -> {
                textView.setBackgroundResource(R.drawable.level_badge_beginner)
                textView.setTextColor(context.getColor(R.color.success))
            }
        }
    }

    override fun getItemCount(): Int = courses.size
    
    override fun getItemId(position: Int): Long {
        return courses[position].id.toLong()
    }
    
    private fun formatStudentCount(count: Int): String {
        return when {
            count >= 1000 -> "${String.format("%.1f", count / 1000.0).replace(".0", "")}k students"
            count > 0 -> "$count students"
            else -> "0 students"
        }
    }
}
