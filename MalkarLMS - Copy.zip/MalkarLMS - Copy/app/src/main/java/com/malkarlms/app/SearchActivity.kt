package com.malkarlms.app

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.View
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.chip.Chip
import com.google.firebase.firestore.FirebaseFirestore

class SearchActivity : AppCompatActivity() {
    
    override fun attachBaseContext(newBase: Context) {
        val languageCode = LocaleHelper.getLanguage(newBase)
        val context = LocaleHelper.setLocale(newBase, languageCode)
        super.attachBaseContext(context)
    }

    private lateinit var btnBack: TextView
    private lateinit var etSearch: EditText
    private lateinit var btnClearSearch: TextView
    private lateinit var searchSuggestionsContainer: View
    private lateinit var resultsHeader: View
    private lateinit var tvResultsCount: TextView
    private lateinit var rvSearchResults: RecyclerView
    private lateinit var emptyStateNoResults: View
    private lateinit var initialStateContainer: View
    private lateinit var tvSearchQuery: TextView
    
    // Chips
    private lateinit var chipPython: Chip
    private lateinit var chipWebDev: Chip
    private lateinit var chipDataScience: Chip
    private lateinit var chipMobile: Chip
    private lateinit var chipAI: Chip
    
    private lateinit var firestore: FirebaseFirestore
    private lateinit var courseAdapter: CourseAdapter
    private val searchResults = mutableListOf<Course>()
    private val allCourses = mutableListOf<Course>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_search)
        
        initFirebase()
        initViews()
        setupSearchFunctionality()
        setupChips()
        loadAllCourses()
        
        // Auto-focus search input
        etSearch.requestFocus()
    }
    
    private fun initFirebase() {
        firestore = FirebaseFirestore.getInstance()
    }
    
    private fun initViews() {
        btnBack = findViewById(R.id.btnBack)
        etSearch = findViewById(R.id.etSearch)
        btnClearSearch = findViewById(R.id.btnClearSearch)
        searchSuggestionsContainer = findViewById(R.id.searchSuggestionsContainer)
        resultsHeader = findViewById(R.id.resultsHeader)
        tvResultsCount = findViewById(R.id.tvResultsCount)
        rvSearchResults = findViewById(R.id.rvSearchResults)
        emptyStateNoResults = findViewById(R.id.emptyStateNoResults)
        initialStateContainer = findViewById(R.id.initialStateContainer)
        tvSearchQuery = findViewById(R.id.tvSearchQuery)
        
        chipPython = findViewById(R.id.chipPython)
        chipWebDev = findViewById(R.id.chipWebDev)
        chipDataScience = findViewById(R.id.chipDataScience)
        chipMobile = findViewById(R.id.chipMobile)
        chipAI = findViewById(R.id.chipAI)
        
        btnBack.setOnClickListener { finish() }
        
        btnClearSearch.setOnClickListener {
            etSearch.text.clear()
            showInitialState()
        }
        
        // Setup RecyclerView with optimizations
        courseAdapter = CourseAdapter(searchResults) { course ->
            val intent = Intent(this, CourseDetailsActivity::class.java).apply {
                putExtra("COURSE_ID", course.id)
                putExtra("COURSE_TITLE", course.title)
                putExtra("COURSE_DESCRIPTION", course.description)
                putExtra("COURSE_DURATION", course.duration)
                putExtra("COURSE_PRICE", course.price)
                putExtra("COURSE_INSTRUCTOR", course.instructor)
                putExtra("COURSE_RATING", course.rating)
                putExtra("COURSE_STUDENTS", course.studentsEnrolled)
                putExtra("COURSE_LEVEL", course.level)
            }
            startActivity(intent)
        }
        
        rvSearchResults.apply {
            layoutManager = LinearLayoutManager(this@SearchActivity)
            adapter = courseAdapter
            setHasFixedSize(true)
            setItemViewCacheSize(20)
        }
    }
    
    private fun setupSearchFunctionality() {
        etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                val query = s.toString().trim()
                
                // Show/hide clear button
                btnClearSearch.visibility = if (query.isEmpty()) View.GONE else View.VISIBLE
                
                if (query.isEmpty()) {
                    showInitialState()
                } else {
                    performSearch(query)
                }
            }
            
            override fun afterTextChanged(s: Editable?) {}
        })
    }
    
    private fun setupChips() {
        chipPython.setOnClickListener { searchFromChip("Python") }
        chipWebDev.setOnClickListener { searchFromChip("Web Development") }
        chipDataScience.setOnClickListener { searchFromChip("Data Science") }
        chipMobile.setOnClickListener { searchFromChip("Mobile") }
        chipAI.setOnClickListener { searchFromChip("AI") }
    }
    
    private fun searchFromChip(query: String) {
        etSearch.setText(query)
        etSearch.setSelection(query.length)
    }
    
    private fun loadAllCourses() {
        // Load hardcoded sample courses
        allCourses.clear()
        allCourses.addAll(getAllSampleCourses())
        Log.d("SearchActivity", "Loaded ${allCourses.size} sample courses")
    }
    
    private fun getAllSampleCourses(): List<Course> {
        return listOf(
            Course(1, "Complete Python Programming Masterclass", "Master Python from basics to advanced", "12 weeks", "₹2,999", "", "Dr. Rajesh Kumar", 4.8f, 15420, 0, "IT", "Beginner"),
            Course(2, "Full Stack Web Development Bootcamp", "Become a full-stack developer with MERN stack", "16 weeks", "₹4,499", "", "Priya Sharma", 4.9f, 22350, 0, "IT", "Beginner"),
            Course(3, "Data Science & Machine Learning", "Learn data analysis, ML algorithms, and AI", "14 weeks", "₹3,999", "", "Dr. Amit Patel", 4.7f, 18900, 0, "IT", "Intermediate"),
            Course(4, "Android App Development with Kotlin", "Build professional Android apps", "12 weeks", "₹3,499", "", "Vikram Singh", 4.6f, 12450, 0, "IT", "Beginner"),
            Course(5, "Cloud Computing with AWS", "Master AWS and deploy scalable applications", "10 weeks", "₹4,999", "", "Neha Gupta", 4.8f, 9800, 0, "IT", "Intermediate"),
            Course(6, "Cybersecurity & Ethical Hacking", "Learn ethical hacking and cybersecurity", "14 weeks", "₹5,499", "", "Arjun Mehta", 4.9f, 8500, 0, "IT", "Advanced"),
            Course(7, "DevOps Engineering Complete", "Master DevOps tools and automation", "12 weeks", "₹4,499", "", "Sanjay Reddy", 4.7f, 11200, 0, "IT", "Intermediate"),
            Course(8, "Artificial Intelligence & Deep Learning", "Build cutting-edge AI applications", "16 weeks", "₹5,999", "", "Dr. Kavita Iyer", 4.9f, 7600, 0, "IT", "Advanced"),
            Course(11, "Digital Marketing Mastery", "Master digital marketing strategies", "10 weeks", "₹3,499", "", "Meera Kapoor", 4.8f, 19500, 0, "Business", "Beginner"),
            Course(12, "MBA Essentials", "Learn MBA concepts without the MBA price", "16 weeks", "₹5,999", "", "Prof. Suresh Menon", 4.9f, 12300, 0, "Business", "Intermediate"),
            Course(21, "AutoCAD for Engineers", "Complete AutoCAD mechanical design", "10 weeks", "₹3,499", "", "Er. Vijay Patil", 4.7f, 14200, 0, "Mechanical", "Beginner"),
            Course(22, "SolidWorks Mastery", "Master 3D CAD design with SolidWorks", "12 weeks", "₹4,499", "", "Er. Ravi Kumar", 4.8f, 11500, 0, "Mechanical", "Intermediate")
        )
    }
    
    private fun performSearch(query: String) {
        val lowerQuery = query.lowercase()
        
        // Filter courses based on query
        searchResults.clear()
        searchResults.addAll(
            allCourses.filter { course ->
                course.title.lowercase().contains(lowerQuery) ||
                course.description.lowercase().contains(lowerQuery) ||
                course.instructor.lowercase().contains(lowerQuery) ||
                course.category.lowercase().contains(lowerQuery)
            }
        )
        
        Log.d("SearchActivity", "Search for '$query' found ${searchResults.size} results")
        
        // Update UI
        if (searchResults.isEmpty()) {
            showNoResults(query)
        } else {
            showResults()
        }
    }
    
    private fun showInitialState() {
        searchSuggestionsContainer.visibility = View.VISIBLE
        initialStateContainer.visibility = View.VISIBLE
        resultsHeader.visibility = View.GONE
        rvSearchResults.visibility = View.GONE
        emptyStateNoResults.visibility = View.GONE
    }
    
    private fun showResults() {
        searchSuggestionsContainer.visibility = View.GONE
        initialStateContainer.visibility = View.GONE
        resultsHeader.visibility = View.VISIBLE
        rvSearchResults.visibility = View.VISIBLE
        emptyStateNoResults.visibility = View.GONE
        
        tvResultsCount.text = "Found ${searchResults.size} course${if (searchResults.size != 1) "s" else ""}"
        courseAdapter.notifyDataSetChanged()
    }
    
    private fun showNoResults(query: String) {
        searchSuggestionsContainer.visibility = View.GONE
        initialStateContainer.visibility = View.GONE
        resultsHeader.visibility = View.GONE
        rvSearchResults.visibility = View.GONE
        emptyStateNoResults.visibility = View.VISIBLE
        
        tvSearchQuery.text = "No results for \"$query\"\nTry different keywords"
    }
}
