package com.malkarlms.app

import android.content.Intent
import android.os.Bundle
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView

class PaymentMethodActivity : AppCompatActivity() {

    private lateinit var tvTotalAmount: TextView
    private lateinit var cardGPay: CardView
    private lateinit var cardPhonePe: CardView
    private lateinit var cardPaytm: CardView
    private lateinit var cardFamPay: CardView
    private lateinit var cardOtherUPI: CardView
    private lateinit var layoutCard: LinearLayout
    private lateinit var layoutNetBanking: LinearLayout
    private lateinit var layoutWallet: LinearLayout

    private var totalAmount: String = "₹0"
    private var courseIds: ArrayList<Int> = arrayListOf()
    private var isSingleCourse: Boolean = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            setContentView(R.layout.activity_payment_method)

            setupToolbar()
            initViews()
            loadData()
            setupClickListeners()
        } catch (e: Exception) {
            android.util.Log.e("PaymentMethodActivity", "Error in onCreate: ${e.message}", e)
            Toast.makeText(this, "Error loading payment methods: ${e.message}", Toast.LENGTH_LONG).show()
            finish()
        }
    }

    private fun setupToolbar() {
        val toolbar = findViewById<androidx.appcompat.widget.Toolbar>(R.id.toolbar)
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "Select Payment Method"
        toolbar.setNavigationOnClickListener {
            onBackPressedDispatcher.onBackPressed()
        }
    }

    private fun initViews() {
        try {
            tvTotalAmount = findViewById(R.id.tvTotalAmount)
            cardGPay = findViewById(R.id.cardGPay)
            cardPhonePe = findViewById(R.id.cardPhonePe)
            cardPaytm = findViewById(R.id.cardPaytm)
            cardFamPay = findViewById(R.id.cardFamPay)
            cardOtherUPI = findViewById(R.id.cardOtherUPI)
            layoutCard = findViewById(R.id.layoutCard)
            layoutNetBanking = findViewById(R.id.layoutNetBanking)
            layoutWallet = findViewById(R.id.layoutWallet)
            
            android.util.Log.d("PaymentMethodActivity", "All views initialized successfully")
        } catch (e: Exception) {
            android.util.Log.e("PaymentMethodActivity", "Error initializing views: ${e.message}", e)
            throw e
        }
    }

    private fun loadData() {
        totalAmount = intent.getStringExtra("TOTAL_AMOUNT") ?: "₹0"
        isSingleCourse = intent.getBooleanExtra("IS_SINGLE_COURSE", false)
        courseIds = intent.getIntegerArrayListExtra("COURSE_IDS") ?: arrayListOf()

        tvTotalAmount.text = totalAmount
    }

    private fun setupClickListeners() {
        // UPI Payment - Navigate to UPI selection page
        cardGPay.setOnClickListener {
            navigateToUPIPayment()
        }

        cardPhonePe.setOnClickListener {
            navigateToUPIPayment()
        }

        cardPaytm.setOnClickListener {
            navigateToUPIPayment()
        }

        cardFamPay.setOnClickListener {
            navigateToUPIPayment()
        }

        cardOtherUPI.setOnClickListener {
            navigateToUPIPayment()
        }

        // Other Methods
        layoutCard.setOnClickListener {
            selectPaymentMethod("Card", "card")
        }

        layoutNetBanking.setOnClickListener {
            selectPaymentMethod("Net Banking", "netbanking")
        }

        layoutWallet.setOnClickListener {
            selectPaymentMethod("Wallet", "wallet")
        }
    }
    
    private fun navigateToUPIPayment() {
        val intent = Intent(this, UpiPaymentActivity::class.java)
        intent.putExtra("AMOUNT", totalAmount)
        startActivityForResult(intent, UPI_PAYMENT_REQUEST_CODE)
    }
    
    companion object {
        private const val UPI_PAYMENT_REQUEST_CODE = 3001
    }
    
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        
        if (requestCode == UPI_PAYMENT_REQUEST_CODE && resultCode == RESULT_OK) {
            // UPI payment successful, pass result back to CheckoutActivity
            setResult(RESULT_OK, data)
            finish()
        }
    }

    private fun selectPaymentMethod(methodName: String, methodType: String) {
        // Show selection feedback
        Toast.makeText(this, "Selected: $methodName", Toast.LENGTH_SHORT).show()

        // Navigate to payment processing
        when (methodType) {
            "gpay", "phonepe", "paytm", "fampay", "upi" -> {
                processUPIPayment(methodName, methodType)
            }
            "card" -> {
                showCardPaymentForm()
            }
            "netbanking" -> {
                showNetBankingOptions()
            }
            "wallet" -> {
                showWalletOptions()
            }
        }
    }

    private fun processUPIPayment(methodName: String, methodType: String) {
        // Create intent to pass back to CheckoutActivity
        val resultIntent = Intent()
        resultIntent.putExtra("PAYMENT_METHOD", methodName)
        resultIntent.putExtra("PAYMENT_TYPE", methodType)
        resultIntent.putExtra("TOTAL_AMOUNT", totalAmount)
        
        // In a real app, this would open the UPI app
        // For now, we'll simulate the payment
        Toast.makeText(this, "Opening $methodName...", Toast.LENGTH_SHORT).show()
        
        // Simulate payment processing
        android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
            setResult(RESULT_OK, resultIntent)
            finish()
        }, 1500)
    }

    private fun showCardPaymentForm() {
        Toast.makeText(this, "Card payment form will open here", Toast.LENGTH_SHORT).show()
        // TODO: Navigate to card details form
        val resultIntent = Intent()
        resultIntent.putExtra("PAYMENT_METHOD", "Credit/Debit Card")
        resultIntent.putExtra("PAYMENT_TYPE", "card")
        setResult(RESULT_OK, resultIntent)
        finish()
    }

    private fun showNetBankingOptions() {
        Toast.makeText(this, "Net banking options will open here", Toast.LENGTH_SHORT).show()
        // TODO: Show bank selection dialog
        val resultIntent = Intent()
        resultIntent.putExtra("PAYMENT_METHOD", "Net Banking")
        resultIntent.putExtra("PAYMENT_TYPE", "netbanking")
        setResult(RESULT_OK, resultIntent)
        finish()
    }

    private fun showWalletOptions() {
        Toast.makeText(this, "Wallet options will open here", Toast.LENGTH_SHORT).show()
        // TODO: Show wallet selection dialog
        val resultIntent = Intent()
        resultIntent.putExtra("PAYMENT_METHOD", "Wallet")
        resultIntent.putExtra("PAYMENT_TYPE", "wallet")
        setResult(RESULT_OK, resultIntent)
        finish()
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressedDispatcher.onBackPressed()
        return true
    }
}
